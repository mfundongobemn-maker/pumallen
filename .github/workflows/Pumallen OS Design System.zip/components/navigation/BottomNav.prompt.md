Fixed 64px bottom tab bar, five primary destinations plus a "More" overflow sheet. Icons are emoji, not an icon font.

```jsx
<BottomNav active="analysis" onSelect={setTab} />
```
