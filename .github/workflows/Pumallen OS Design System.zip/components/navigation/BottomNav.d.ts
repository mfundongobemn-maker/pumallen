export interface BottomNavItem { id: string; icon: string; label: string; }
export interface BottomNavProps {
  items?: BottomNavItem[];
  active?: string;
  onSelect?: (id: string) => void;
  static?: boolean;
}
/**
 * @startingPoint section="Components" subtitle="Fixed bottom tab bar with emoji icons" viewport="700x64"
 */
export function BottomNav(props: BottomNavProps): JSX.Element;
