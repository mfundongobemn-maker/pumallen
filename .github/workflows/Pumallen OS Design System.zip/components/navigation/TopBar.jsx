import React from 'react';
export function TopBar(props) {
  var style = {
    position: props.static ? 'static' : 'fixed', top: 0, left: 0, right: 0, zIndex: 100,
    background: 'rgba(10,8,0,0.97)', borderBottom: '1px solid var(--border-default)',
    padding: 'var(--topbar-pad)', display: 'flex', alignItems: 'center', justifyContent: 'space-between'
  };
  return React.createElement('div', { style: style },
    React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 9 } },
      React.createElement('div', null,
        React.createElement('div', { style: { fontSize: 'var(--text-xl)', fontWeight: 800, color: 'var(--accent-primary)', letterSpacing: 'var(--tracking-wider)' } }, props.title || 'PUMALLEN OS'),
        React.createElement('div', { style: { fontSize: 'var(--text-2xs)', color: 'var(--text-muted)', letterSpacing: 'var(--tracking-wide)' } }, props.subtitle)
      )
    ),
    props.children
  );
}
