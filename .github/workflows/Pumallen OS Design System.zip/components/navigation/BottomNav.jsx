import React from 'react';
var ITEMS = [
  { id: 'chat', icon: '💬', label: 'AI Chat' },
  { id: 'analysis', icon: '🔬', label: 'Analysis' },
  { id: 'checklist', icon: '✅', label: 'Checks' },
  { id: 'calc', icon: '🧮', label: 'Calc' },
  { id: 'journal', icon: '📒', label: 'Journal' },
  { id: 'more', icon: '⋯', label: 'More' }
];
export function BottomNav(props) {
  var active = props.active || 'analysis';
  var style = {
    position: props.static ? 'static' : 'fixed', bottom: 0, left: 0, right: 0, height: 'var(--nav-height)',
    background: 'var(--bg-surface)', borderTop: '1px solid var(--border-default)', display: 'flex', alignItems: 'center', zIndex: 9999
  };
  return React.createElement('div', { style: style },
    (props.items || ITEMS).map(function (it) {
      var isAct = it.id === active;
      return React.createElement('div', {
        key: it.id, onClick: function () { props.onSelect && props.onSelect(it.id); },
        style: { flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 3, fontSize: 'var(--text-2xs)', fontWeight: 600, color: isAct ? 'var(--accent-primary)' : 'var(--text-muted)', cursor: 'pointer', userSelect: 'none', minHeight: 'var(--nav-height)' }
      },
        React.createElement('div', { style: { fontSize: 20, lineHeight: 1 } }, it.icon),
        it.label
      );
    })
  );
}
