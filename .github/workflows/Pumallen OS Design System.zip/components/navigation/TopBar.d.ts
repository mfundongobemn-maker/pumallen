export interface TopBarProps {
  title?: string;
  subtitle?: string;
  static?: boolean;
  /** Trailing content, e.g. a day Chip */
  children?: React.ReactNode;
}
/**
 * @startingPoint section="Components" subtitle="Fixed header: brand wordmark + trailing status chip" viewport="700x64"
 */
export function TopBar(props: TopBarProps): JSX.Element;
