Fixed top header with brand wordmark + subtitle on the left, a trailing slot (typically a day-status Chip) on the right.

```jsx
<TopBar title="PUMALLEN OS" subtitle="Master Trading System · EURUSD"><Chip tone="exec">TUE · EXECUTE</Chip></TopBar>
```
