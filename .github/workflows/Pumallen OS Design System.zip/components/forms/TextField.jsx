import React from 'react';
var baseInput = {
  width: '100%', padding: '10px 12px', background: 'var(--bg-page)', border: '1.5px solid var(--border-gold)',
  borderRadius: 'var(--radius-md)', color: 'var(--text-hi)', fontFamily: 'var(--font-mono)', fontSize: 'var(--text-md)', boxSizing: 'border-box'
};
export function TextField(props) {
  var type = props.type || 'text';
  var rest = { placeholder: props.placeholder, value: props.value, onChange: props.onChange, onKeyDown: props.onKeyDown };
  return React.createElement('div', null,
    props.label && React.createElement('label', { style: { color: 'var(--text-hi)', fontSize: 'var(--text-base)', fontWeight: 700, fontFamily: 'var(--font-body)' } }, props.label),
    type === 'textarea'
      ? React.createElement('textarea', Object.assign({}, rest, { style: Object.assign({}, baseInput, { minHeight: 60, marginTop: props.label ? 6 : 0, fontFamily: 'var(--font-body)' }) }))
      : React.createElement('input', Object.assign({}, rest, { type: type, style: Object.assign({}, baseInput, { marginTop: props.label ? 6 : 0 }) }))
  );
}
export function Select(props) {
  return React.createElement('select', { value: props.value, onChange: props.onChange, style: Object.assign({}, baseInput, { fontFamily: 'var(--font-body)' }) },
    (props.options || []).map(function (o) { return React.createElement('option', { key: o, value: o }, o); })
  );
}
