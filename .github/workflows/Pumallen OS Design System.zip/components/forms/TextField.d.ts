export interface TextFieldProps {
  label?: string;
  type?: 'text' | 'number' | 'password' | 'textarea';
  placeholder?: string;
}
export interface SelectProps {
  options: string[];
}
/**
 * @startingPoint section="Components" subtitle="Labeled text/number/textarea input" viewport="700x140"
 */
export function TextField(props: TextFieldProps): JSX.Element;
export function Select(props: SelectProps): JSX.Element;
