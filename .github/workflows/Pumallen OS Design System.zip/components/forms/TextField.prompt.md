Form controls used in the calculator, journal and settings screens — dark input on black, thin gold-tinted border, mono type for numeric fields.

```jsx
<TextField label="Account Balance ($)" type="number" placeholder="1000" />
<TextField label="Notes" type="textarea" />
<Select options={['Long','Short']} />
```
