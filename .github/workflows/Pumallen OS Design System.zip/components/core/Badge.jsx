import React from 'react';
export function Badge(props) {
  var tone = props.tone || 'muted';
  var colors = {
    green: { color: 'var(--accent-success)', background: 'var(--surface-green-tint)' },
    red: { color: 'var(--accent-danger)', background: 'var(--surface-red-tint)' },
    amber: { color: 'var(--accent-primary)', background: 'var(--surface-gold-tint)' },
    muted: { color: 'var(--text-lo)', background: 'var(--bg-surface-alt)', borderColor: 'var(--border-default)' }
  };
  var c = colors[tone] || colors.muted;
  var style = {
    display: 'inline-flex', alignItems: 'center', padding: '3px 9px', borderRadius: 'var(--radius-pill)',
    fontSize: 'var(--text-2xs)', fontWeight: 700, fontFamily: 'var(--font-mono)', letterSpacing: 'var(--tracking-wider)',
    border: '1px solid ' + (c.borderColor || 'currentColor'), color: c.color, background: c.background,
    whiteSpace: 'nowrap', flexShrink: 0
  };
  return React.createElement('span', { style: style }, props.children);
}
