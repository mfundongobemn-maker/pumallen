export interface ChipProps {
  /** default = day/session neutral, exec/open = active-green, warn = no-trade-red, obs = observed session (gold outline) */
  tone?: 'default' | 'exec' | 'warn' | 'open' | 'obs';
  dense?: boolean;
  /** Show the leading status dot (default true) */
  dot?: boolean;
  children?: React.ReactNode;
}
/**
 * @startingPoint section="Components" subtitle="Day/session pills with status dot" viewport="700x120"
 */
export function Chip(props: ChipProps): JSX.Element;
