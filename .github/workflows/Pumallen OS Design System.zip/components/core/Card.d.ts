export interface CardProps {
  padded?: boolean;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
/**
 * @startingPoint section="Components" subtitle="Generic dark surface panel" viewport="700x160"
 */
export function Card(props: CardProps): JSX.Element;
