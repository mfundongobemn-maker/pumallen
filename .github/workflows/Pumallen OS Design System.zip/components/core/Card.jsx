import React from 'react';
export function Card(props) {
  var style = Object.assign({
    background: 'var(--bg-surface)', border: '1px solid var(--border-default)',
    borderRadius: 'var(--radius-xl)', padding: props.padded === false ? 0 : 16
  }, props.style || {});
  return React.createElement('div', { style: style }, props.children);
}
