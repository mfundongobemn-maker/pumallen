import React from 'react';
export function Chip(props) {
  var tone = props.tone || 'default';
  var tones = {
    default: { color: 'var(--text-lo)', border: 'var(--border-default)', background: 'var(--bg-surface-alt)' },
    exec: { color: 'var(--accent-success)', border: 'var(--border-green)', background: 'var(--surface-green-tint)' },
    warn: { color: 'var(--accent-danger)', border: 'var(--border-red)', background: 'var(--surface-red-tint)' },
    open: { color: 'var(--accent-success)', border: 'var(--border-green)', background: 'var(--surface-green-tint)' },
    obs: { color: 'var(--accent-primary)', border: 'rgba(212,160,23,.3)', background: 'transparent' }
  };
  var t = tones[tone] || tones.default;
  var style = {
    display: 'inline-flex', alignItems: 'center', gap: 4, padding: props.dense ? '3px 7px' : '4px 10px',
    borderRadius: 'var(--radius-pill)', fontSize: props.dense ? 'var(--text-2xs)' : 'var(--text-2xs)',
    fontWeight: 700, fontFamily: 'var(--font-mono)', whiteSpace: 'nowrap',
    color: t.color, border: '1px solid ' + t.border, background: t.background
  };
  return React.createElement('div', { style: style },
    props.dot !== false && React.createElement('div', { style: { width: 4, height: 4, borderRadius: '50%', background: 'currentColor', flexShrink: 0 } }),
    props.children
  );
}
