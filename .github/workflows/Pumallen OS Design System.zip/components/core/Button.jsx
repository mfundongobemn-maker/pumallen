import React from 'react';
export function Button(props) {
  var variant = props.variant || 'gold';
  var size = props.size || 'md';
  var disabled = !!props.disabled;
  var [pressed, setPressed] = React.useState(false);
  var base = {
    fontFamily: 'var(--font-body)', fontWeight: 800, cursor: disabled ? 'default' : 'pointer',
    border: 'none', borderRadius: 'var(--radius-lg)', touchAction: 'manipulation',
    padding: size === 'sm' ? '9px 13px' : '12px 14px', fontSize: size === 'sm' ? 'var(--text-md)' : 'var(--text-lg)',
    opacity: disabled ? .4 : (pressed ? .7 : 1), transition: 'opacity .15s',
    display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 8
  };
  var variants = {
    gold: { background: 'linear-gradient(135deg,var(--gold-deep),var(--gold))', color: '#000' },
    ghost: { background: 'var(--bg-surface-alt)', border: '1px solid var(--border-default)', color: 'var(--text-mid)', fontWeight: 700 },
    outline: { background: 'transparent', border: '1.5px solid var(--border-gold)', color: 'var(--accent-primary)' },
    success: { background: 'var(--surface-green-tint)', border: '1.5px solid var(--border-green)', color: 'var(--accent-success)' },
    danger: { background: 'var(--surface-red-tint)', border: '1.5px solid var(--border-red)', color: 'var(--accent-danger)' },
    warn: { background: 'var(--surface-gold-tint)', border: '1.5px solid var(--border-gold)', color: 'var(--accent-primary)' }
  };
  var style = Object.assign({}, base, variants[variant] || variants.gold, props.style || {});
  return React.createElement('button', {
    style: style, disabled: disabled, onClick: props.onClick,
    onMouseDown: function () { setPressed(true); }, onMouseUp: function () { setPressed(false); },
    onMouseLeave: function () { setPressed(false); }, onTouchStart: function () { setPressed(true); }, onTouchEnd: function () { setPressed(false); }
  }, props.children);
}
