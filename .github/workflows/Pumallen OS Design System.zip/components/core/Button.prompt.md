Primary action button used across PMTS — gold gradient for the main CTA, ghost/outline for secondary actions, and success/danger/warn for permission-gate decisions (grant/deny/defer).

```jsx
<Button variant="gold">EXECUTE</Button>
<Button variant="ghost">↺ Reset</Button>
<Button variant="success">✅ Confirmed — Unlock Weekly</Button>
<Button variant="danger">🚫 Stand Down</Button>
```

Variants: `gold` (default, gradient fill, black text), `ghost` (muted, bordered), `outline` (gold outline, transparent), `success`/`danger`/`warn` (tinted permission buttons). `size="sm"` for compact toolbar use.
