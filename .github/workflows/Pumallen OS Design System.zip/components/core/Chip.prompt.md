Pill used for the day-of-week status chip in the topbar and the scrolling session row (London/New York/Asian + live clock).

```jsx
<Chip tone="exec">TUE · EXECUTE</Chip>
<Chip tone="open">London OPEN</Chip>
<Chip tone="obs" dot={false}>SAST 14:32:07</Chip>
```
