Small status pill used on timeframe cards and headers — mono uppercase text in a tinted, bordered capsule.

```jsx
<Badge tone="green">CONFIRMED</Badge>
<Badge tone="red">CONFLICT</Badge>
<Badge tone="amber">UPLOAD</Badge>
<Badge tone="muted">🔒 LOCKED</Badge>
```
