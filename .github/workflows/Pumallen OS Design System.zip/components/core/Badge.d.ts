export interface BadgeProps {
  /** Semantic tone: green = confirmed/aligned, red = rejected/conflict, amber = pending/upload, muted = locked/inactive */
  tone?: 'green' | 'red' | 'amber' | 'muted';
  children?: React.ReactNode;
}
/**
 * @startingPoint section="Components" subtitle="Status pills: confirmed, locked, conflict" viewport="700x120"
 */
export function Badge(props: BadgeProps): JSX.Element;
