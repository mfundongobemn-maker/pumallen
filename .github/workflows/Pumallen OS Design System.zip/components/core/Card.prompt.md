Generic dark surface panel used for form groups (calculator, journal, settings). Flat, 1px border, 14px radius, no shadow.

```jsx
<Card><label>Account Balance ($)</label><input /></Card>
```
