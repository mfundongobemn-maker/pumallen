export interface ButtonProps {
  /** Visual treatment. gold = primary CTA (gradient fill); ghost = neutral action; outline = secondary gold outline; success/danger/warn = permission decision buttons */
  variant?: 'gold' | 'ghost' | 'outline' | 'success' | 'danger' | 'warn';
  size?: 'sm' | 'md';
  disabled?: boolean;
  onClick?: () => void;
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
/**
 * @startingPoint section="Components" subtitle="Primary, ghost and permission-decision buttons" viewport="700x220"
 */
export function Button(props: ButtonProps): JSX.Element;
