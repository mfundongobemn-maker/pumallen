import React from 'react';
export function VerdictBanner(props) {
  var verdict = props.verdict || 'execute';
  var isExec = verdict === 'execute';
  var style = {
    borderRadius: 'var(--radius-xl)', padding: 20, textAlign: 'center',
    background: isExec ? 'var(--surface-green-tint)' : 'var(--surface-red-tint)',
    border: '1.5px solid ' + (isExec ? 'var(--border-green)' : 'var(--border-red)')
  };
  var titleColor = isExec ? 'var(--accent-success)' : 'var(--accent-danger)';
  return React.createElement('div', { style: style },
    React.createElement('span', { style: { fontSize: 36, display: 'block', marginBottom: 8 } }, props.icon || (isExec ? '🎯' : '🚫')),
    React.createElement('div', { style: { fontSize: 'var(--text-3xl)', fontWeight: 800, letterSpacing: 'var(--tracking-widest)', textTransform: 'uppercase', marginBottom: 7, color: titleColor } }, props.title || (isExec ? 'Execute' : 'Stand Down')),
    React.createElement('div', { style: { fontSize: 'var(--text-base)', color: 'var(--text-lo)', lineHeight: 'var(--leading-relaxed)' } }, props.subtitle),
    props.children
  );
}
