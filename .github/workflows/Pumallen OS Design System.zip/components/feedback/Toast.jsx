import React from 'react';
export function Toast(props) {
  var show = !!props.show;
  var style = {
    position: props.static ? 'static' : 'fixed', bottom: 74, left: '50%',
    transform: show ? 'translateX(-50%) translateY(0)' : 'translateX(-50%) translateY(10px)',
    background: 'var(--bg-surface-alt)', border: '1px solid var(--accent-primary)', color: 'var(--text-hi)',
    fontSize: 'var(--text-md)', fontWeight: 600, padding: '8px 18px', borderRadius: 'var(--radius-pill)',
    opacity: show ? 1 : 0, transition: 'all .3s', pointerEvents: 'none', whiteSpace: 'nowrap', display: 'inline-block'
  };
  return React.createElement('div', { style: style }, props.children);
}
