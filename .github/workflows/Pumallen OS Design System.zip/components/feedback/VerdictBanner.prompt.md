Large end-of-chain verdict card shown after the timeframe analysis completes — the payoff moment of the whole PMTS flow.

```jsx
<VerdictBanner verdict="execute" title="Execute" subtitle="All 9 conditions met." />
<VerdictBanner verdict="stand-down" title="Stand Down" subtitle="Daily permission denied." />
```
