export interface VerdictBannerProps {
  verdict?: 'execute' | 'stand-down';
  icon?: string;
  title?: string;
  subtitle?: string;
  children?: React.ReactNode;
}
/**
 * @startingPoint section="Components" subtitle="Final execute / stand-down verdict panel" viewport="700x220"
 */
export function VerdictBanner(props: VerdictBannerProps): JSX.Element;
