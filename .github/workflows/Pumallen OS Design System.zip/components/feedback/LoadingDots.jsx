import React from 'react';
export function LoadingDots(props) {
  var style = { display: 'flex', alignItems: 'center', gap: 9, fontSize: 'var(--text-sm)', color: 'var(--text-lo)', fontFamily: 'var(--font-mono)' };
  var dotBase = { width: 6, height: 6, borderRadius: '50%', background: 'var(--accent-primary)', boxShadow: '0 0 6px rgba(212,160,23,.5)', animation: 'pmDotBounce 1.2s infinite' };
  return React.createElement('div', { style: style },
    React.createElement('div', { style: { display: 'flex', gap: 4 } },
      [0, .2, .4].map(function (d, i) { return React.createElement('span', { key: i, style: Object.assign({}, dotBase, { animationDelay: d + 's' }) }); })
    ),
    props.children
  );
}
