Bottom-center pill toast for lightweight confirmations (tab switches, saves). Auto-dismisses after ~2s in the app.

```jsx
<Toast show={true}>chat ✓</Toast>
```
