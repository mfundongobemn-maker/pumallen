Staggered bouncing 3-dot indicator shown while an AI chart analysis is in flight. Requires the `pmDotBounce` keyframes (declared once globally, see `.prompt.md` note) — `@keyframes pmDotBounce{0%,80%,100%{transform:translateY(0);opacity:.3}40%{transform:translateY(-5px);opacity:1}}`.

```jsx
<LoadingDots>Analyzing Monthly...</LoadingDots>
```
