export interface ToastProps {
  show?: boolean;
  /** Render inline instead of fixed-positioned (for specimen/preview use) */
  static?: boolean;
  children?: React.ReactNode;
}
/**
 * @startingPoint section="Components" subtitle="Bottom-center confirmation toast" viewport="700x100"
 */
export function Toast(props: ToastProps): JSX.Element;
