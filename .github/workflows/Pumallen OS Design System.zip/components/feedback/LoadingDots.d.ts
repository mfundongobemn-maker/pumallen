export interface LoadingDotsProps {
  children?: React.ReactNode;
}
/**
 * @startingPoint section="Components" subtitle="Bouncing 3-dot analysis indicator" viewport="700x80"
 */
export function LoadingDots(props: LoadingDotsProps): JSX.Element;
