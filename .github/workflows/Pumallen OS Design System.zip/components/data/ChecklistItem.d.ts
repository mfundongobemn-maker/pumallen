export interface ChecklistItemProps {
  label: string;
  checked?: boolean;
  onToggle?: () => void;
}
/**
 * @startingPoint section="Components" subtitle="Tappable pre-trade gate condition row" viewport="700x60"
 */
export function ChecklistItem(props: ChecklistItemProps): JSX.Element;
