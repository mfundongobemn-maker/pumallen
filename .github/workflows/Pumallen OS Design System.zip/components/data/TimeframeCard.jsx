import React from 'react';
import { Badge } from '../core/Badge.jsx';
import { Button } from '../core/Button.jsx';
export function TimeframeCard(props) {
  var state = props.state || 'active';
  var locked = state === 'locked';
  var glow = state === 'aligned' ? { borderColor: 'var(--border-green)', boxShadow: '0 0 20px rgba(0,232,122,.07)' } :
    state === 'rejected' ? { borderColor: 'var(--border-red)' } : {};
  var style = Object.assign({
    background: 'var(--bg-surface)', border: '1px solid var(--border-default)', borderRadius: 'var(--radius-xl)',
    overflow: 'hidden', opacity: locked ? .4 : 1, transition: 'border-color .3s, box-shadow .3s, opacity .3s'
  }, glow);
  var numStyle = {
    width: 40, height: 40, borderRadius: 'var(--radius-md)', background: 'var(--bg-surface-alt)', border: '1px solid var(--border-default)',
    display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 'var(--text-md)', fontWeight: 800, color: 'var(--text-muted)', fontFamily: 'var(--font-mono)', flexShrink: 0, transition: 'all .3s'
  };
  if (state === 'aligned') Object.assign(numStyle, { background: 'var(--surface-green-tint)', borderColor: 'var(--border-green)', color: 'var(--accent-success)' });
  if (state === 'rejected') Object.assign(numStyle, { background: 'var(--surface-red-tint)', borderColor: 'var(--border-red)', color: 'var(--accent-danger)' });
  var badge = locked ? React.createElement(Badge, { tone: 'muted' }, '🔒 LOCKED') :
    state === 'aligned' ? React.createElement(Badge, { tone: 'green' }, 'ALIGNED') :
    state === 'rejected' ? React.createElement(Badge, { tone: 'red' }, 'REJECTED') :
    React.createElement(Badge, { tone: 'amber' }, 'UPLOAD');
  return React.createElement('div', { style: style },
    React.createElement('div', { style: { display: 'flex', alignItems: 'center', justifyContent: 'space-between', padding: '12px 14px', gap: 8 } },
      React.createElement('div', { style: { display: 'flex', alignItems: 'center', gap: 11 } },
        React.createElement('div', { style: numStyle }, props.code),
        React.createElement('div', null,
          React.createElement('div', { style: { fontSize: 'var(--text-lg)', fontWeight: 700, color: 'var(--text-hi)' } }, props.label),
          React.createElement('div', { style: { fontSize: 'var(--text-xs)', color: 'var(--text-muted)', marginTop: 1 } }, props.role)
        )
      ),
      badge
    ),
    !locked && React.createElement('div', { style: { padding: '0 13px 13px', display: 'flex', flexDirection: 'column', gap: 8 } },
      props.showUpload !== false && React.createElement('div', { style: { display: 'flex', gap: 7 } },
        React.createElement(Button, { variant: 'ghost', size: 'sm', style: { flex: 1, border: '1.5px dashed rgba(212,160,23,.25)', textAlign: 'left', justifyContent: 'flex-start' } }, '📷 Upload ' + props.label + ' Chart'),
        React.createElement(Button, { variant: 'outline', size: 'sm' }, 'Analyze')
      ),
      props.children
    )
  );
}
