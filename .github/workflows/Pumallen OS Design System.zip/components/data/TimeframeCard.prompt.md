The core PMTS primitive — one card per timeframe in the Monthly→Weekly→Daily→H4→H1→M15 chain of authority. Locked/dimmed until the prior timeframe grants permission; glows green when aligned, red border when rejected.

```jsx
<TimeframeCard code="MO" label="Monthly" role="Mission Timeframe · Supreme Authority" state="active" />
<TimeframeCard code="W" label="Weekly" role="Strategic Planning" state="locked" />
```
