Single tappable row in the 9-condition pre-trade gate. Filled green check when satisfied, dim gold outline when not.

```jsx
<ChecklistItem label="Tuesday–Thursday only" checked={true} onToggle={toggle} />
```
