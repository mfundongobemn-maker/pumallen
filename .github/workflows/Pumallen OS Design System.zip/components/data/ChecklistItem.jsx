import React from 'react';
export function ChecklistItem(props) {
  var checked = !!props.checked;
  var style = {
    display: 'flex', alignItems: 'center', gap: 12, padding: '13px 14px', background: 'var(--bg-surface-alt)',
    border: '1px solid var(--border-default)', borderRadius: 'var(--radius-lg)', cursor: 'pointer'
  };
  var boxStyle = {
    width: 22, height: 22, borderRadius: 'var(--radius-sm)', flexShrink: 0, display: 'flex', alignItems: 'center', justifyContent: 'center',
    fontSize: 14, background: checked ? 'var(--accent-success)' : 'var(--bg-page)', color: checked ? 'var(--bg-page)' : 'transparent',
    border: checked ? 'none' : '1.5px solid var(--border-gold)'
  };
  return React.createElement('div', { style: style, onClick: props.onToggle },
    React.createElement('div', { style: boxStyle }, checked ? '✓' : ''),
    React.createElement('div', { style: { fontSize: 'var(--text-md)', color: checked ? 'var(--text-hi)' : 'var(--text-dim)' } }, props.label)
  );
}
