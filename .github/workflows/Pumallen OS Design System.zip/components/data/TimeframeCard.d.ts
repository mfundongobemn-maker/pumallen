export interface TimeframeCardProps {
  /** e.g. "MO", "W", "D", "H4", "H1", "M15" */
  code: string;
  label: string;
  role: string;
  state?: 'locked' | 'active' | 'aligned' | 'rejected';
  /** Show the built-in "Upload Chart" + "Analyze" row (default true). Set false when the consumer supplies its own wired-up upload/action controls via children. */
  showUpload?: boolean;
  children?: React.ReactNode;
}
/**
 * @startingPoint section="Components" subtitle="Chain-of-authority analysis card (Monthly→M15)" viewport="700x180"
 */
export function TimeframeCard(props: TimeframeCardProps): JSX.Element;
