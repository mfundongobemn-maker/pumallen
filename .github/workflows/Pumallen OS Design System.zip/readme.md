# Pumallen OS Design System

**Company:** Pumallen (PMTS — Pumallen Market Trading System)

Pumallen OS is a single-purpose mobile web app that operationalizes the Pumallen Master Trading System (PMTS) — a rules-based EURUSD price-action methodology built on a strict "chain of authority" across timeframes (Monthly → Weekly → Daily → H4 → H1 → M15). The app is a disciplined trading co-pilot: it walks a trader through uploading a chart for each timeframe, running an AI (Claude) chart analysis, and gating permission to move to the next timeframe — culminating in an EXECUTE or STAND DOWN verdict. It also bundles a position-size calculator, a 9-condition pre-trade checklist, a trade journal, a funding-progress planner, and an AI chat assistant.

There is one product surface: **Pumallen OS**, a mobile-first PWA (installable, dark, single index.html).

## Sources
- GitHub repo: [mfundongobemn-maker/pumallen](https://github.com/mfundongobemn-maker/pumallen) (branch `main`) — a single-file PWA (`index.html`, `manifest.json`, app icons). This design system was built directly from that source. Explore the repo further for the full interactive logic (Claude API chat, checklist/journal/calculator state, localStorage persistence) which is not reproduced verbatim here.

No Figma file or additional codebase was provided.

## Components
Built from the app's actual UI, grouped by concern:
- **core/**: `Button`, `Badge`, `Chip`, `Card`
- **feedback/**: `Toast`, `VerdictBanner`
- **navigation/**: `BottomNav`, `TopBar`
- **data/**: `TimeframeCard`, `ChecklistItem`
- **forms/**: `TextField`, `Select`

### Intentional additions
None in the component library — every component above has a direct counterpart in the source app.

The UI kit has intentional additions beyond the source: a **Currency Pair selector** (Settings) since the source is EURUSD-only, and an **Economic Ranking & Pair Selection engine** (`ui_kits/pumallen-os/EconomyScreen.jsx`) modeled directly on the user's own PMTS Economic Ranking workbook (`uploads/PMTS_Economic_Ranking_Pair_Selection.xlsx`) — 8 currencies × 6 economic chains (Business Activity, Labour Market, Inflation, Consumer Activity, Economic Growth, Central Bank), each scored Strong/Mixed/Weak with a Not Started/Collecting Evidence/Thesis Complete status; live eligibility, ranking, and strongest-vs-weakest pair/gap-filter logic replicated from the workbook's Decision Engine and Pair Selection tabs. Flagged in-app with a small disclaimer.

## Content fundamentals
- **Voice:** direct, disciplined, military/systems-ops register. Copy reads like standing orders, not friendly assistance: *"AUTHORITY FLOWS DOWNWARD, EVIDENCE FLOWS UPWARD"*, *"ONE fails = STAND DOWN"*.
- **Person:** mostly imperative / second-person implied ("Upload Monthly Chart", "Analyze"), occasional direct "you" in settings copy ("Your key is stored only on this device").
- **Casing:** ALL CAPS for verdicts and gate states (EXECUTE, STAND DOWN, ALIGNED, LOCKED, CONFIRMED); sentence case for descriptive subtext and helper copy.
- **Vocabulary:** trading/military hybrid — "mission", "permission", "authority", "engineering", "execution", "precision", "sweep", "BOS/CHoCH", "stand down". Every timeframe is framed as a role in a chain of command (Monthly = Supreme Authority, Weekly = Strategic Planning, Daily = Permission, H4 = Engineering, H1 = Execution Engine, M15 = Precision Entry).
- **Emoji:** used functionally as tab/section icons and status markers (🔬 💬 ✅ 🧮 📒 🔒 ✅ 🚫 📷 ⚠️), not decoratively in prose. Treat emoji as icon replacements, not tone.
- **Tagline** (from the app icon): "OPERATE WITH DISCIPLINE. EXECUTE WITH PRECISION."

## Visual foundations
- **Palette:** near-black warm base (`#0a0800`) with a metallic gold accent (`#d4a017` → `#f0c040` gradient) and a cool silver secondary (`#c7cdd6`, seen in the logo mark). Semantic greens (`#00e87a`, "aligned"/"execute") and reds (`#ff3355`, "conflict"/"stand down") gate every decision point. No blues, no purples.
- **Type:** Outfit (sans, 400–900) for all UI text and headings; JetBrains Mono for anything numeric or state-like — timestamps, session clocks, badges, timeframe codes. This mono/sans split is a core signal: mono = data/system, sans = human copy.
- **Backgrounds:** flat, no gradients except the single gold CTA gradient and the logo's metallic sheen. No photography, no illustration, no texture/grain. Pure dark mode, near-black surfaces layered by border color, not by shadow.
- **Depth:** no drop shadows anywhere. Elevation is communicated by border color/opacity and by a soft colored glow (`box-shadow: 0 0 20px rgba(0,232,122,.07)`) on "aligned" cards — never gray shadows.
- **Borders:** 1–1.5px hairlines in translucent gold or state color are the primary structuring device (`rgba(212,160,23,.25–.45)`, `rgba(0,232,122,.4)`, `rgba(255,51,85,.3)`). Borders carry meaning (locked = dim gray, active = gold, aligned = green, rejected = red).
- **Corner radii:** 6px (small controls) → 9–10px (buttons, inputs) → 14px (cards) → 20px/pill (chips, toasts, CTAs). No sharp corners, nothing fully square.
- **Cards:** flat surface fill, 1px border, 14px radius, no shadow. State is shown via border color/glow, not elevation.
- **Buttons:** gold gradient fill for primary CTA (black text, 800 weight); ghost/outline for secondary; tinted-and-bordered (no fill) for the three-way permission decision (grant/deny/defer).
- **Hover/press states:** the app is mobile-first (touch, no hover). Press state is a straight opacity dip to ~0.7 on `:active` — no color shift, no scale/shrink.
- **Animation:** minimal. A 3-dot loading indicator bounces during AI analysis (`translateY` + opacity, staggered 0.2s, ease default). Toasts fade/slide in over 0.3s. No page transitions, no bounce/spring easing anywhere.
- **Layout:** fixed top bar + fixed bottom tab bar, scrollable content between them (mobile app shell, not a responsive website). A horizontally-scrolling session-status row sits just under the top bar.
- **Transparency/blur:** topbar uses a near-opaque tint (`rgba(10,8,0,.97)`) for a subtle glass feel while staying fixed above scrolling content; no backdrop-blur is used anywhere.
- **Imagery color vibe:** none in the UI itself (chart uploads are the only imagery, user-supplied). The one brand asset — the app icon — is a dark, moody, metallic gold/silver render with a faint crosshair/reticle motif behind the mark.

## Iconography
- **No icon font or SVG icon set.** All icons in the source app are **emoji**, used as direct tab/button glyphs (🔬 💬 ✅ 🧮 📒 ⋯ 📷 🔒 ✅ 🚫 ⚙️ 📊 📅 📝 🗂 💾 🗑️). Follow this convention for any new screens — do not introduce a different icon system (e.g. Lucide/Heroicons) or hand-drawn SVG icons; use emoji at UI-icon sizes (~18–22px) to stay consistent with the source.
- **Logo:** a single metallic gold/silver "P" monogram shield mark (`assets/logo/icon-512.png`, `icon-192.png`), set against a black background with a faint crosshair/reticle circle motif. Used as the PWA app icon; the in-app topbar in the source only shows a text wordmark, no inline logo image — treat the mark as an app-icon/splash asset, not a persistent in-UI header logo.

## Index
- `styles.css` — root stylesheet, imports all tokens below.
- `tokens/colors.css`, `tokens/fonts.css`, `tokens/typography.css`, `tokens/spacing.css`
- `assets/logo/` — `icon-192.png`, `icon-512.png`
- `components/core/` — Button, Badge, Chip, Card
- `components/feedback/` — Toast, VerdictBanner, LoadingDots
- `components/navigation/` — BottomNav, TopBar
- `components/data/` — TimeframeCard, ChecklistItem
- `components/forms/` — TextField, Select
- `guidelines/` — foundation specimen cards (Colors, Type, Spacing, Brand)
- `ui_kits/pumallen-os/` — click-through recreation of the app with persisted, shared cross-screen state (localStorage-backed) — Analysis chain with live drag-drop chart upload analyzed by real Claude vision, gated by the Checklist screen; AI Chat with real Claude replies; Calculator with input validation; Journal, Stats, Funding Planner, Market Narrative, Analysis History, Settings with a real "reset all data" action
- `templates/pumallen-os/`, `templates/pumallen-os-chat/`, `templates/pumallen-os-checklist/`, `templates/pumallen-os-calculator/` — starting-point templates for the mobile shell, chat, checklist, and calculator screens
- `SKILL.md` — portable skill definition for use in Claude Code / other agents
- `github.md` — source repo sync record

## Caveats
- Only one source (a single-file GitHub repo) was provided — no Figma, no separate marketing site, no formal component library. All component boundaries were inferred directly from the app's actual CSS classes and markup.
- The app's animated loading dots and live session clock are simplified/static in the UI kit recreation (no live Claude API calls, no real countdown).
