/* @ds-bundle: {"format":4,"namespace":"PumallenOSDesignSystem_ac653c","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"ChecklistItem","sourcePath":"components/data/ChecklistItem.jsx"},{"name":"TimeframeCard","sourcePath":"components/data/TimeframeCard.jsx"},{"name":"LoadingDots","sourcePath":"components/feedback/LoadingDots.jsx"},{"name":"Toast","sourcePath":"components/feedback/Toast.jsx"},{"name":"VerdictBanner","sourcePath":"components/feedback/VerdictBanner.jsx"},{"name":"TextField","sourcePath":"components/forms/TextField.jsx"},{"name":"Select","sourcePath":"components/forms/TextField.jsx"},{"name":"BottomNav","sourcePath":"components/navigation/BottomNav.jsx"},{"name":"TopBar","sourcePath":"components/navigation/TopBar.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"9af4ebd70c0e","components/core/Button.jsx":"379d48f5f663","components/core/Card.jsx":"fa5f2a6a218b","components/core/Chip.jsx":"3713e9222eec","components/data/ChecklistItem.jsx":"abd9aefedd48","components/data/TimeframeCard.jsx":"17a2f4616008","components/feedback/LoadingDots.jsx":"88760d92f43b","components/feedback/Toast.jsx":"5d38e66d51f7","components/feedback/VerdictBanner.jsx":"fb266728b2cb","components/forms/TextField.jsx":"e9ae15dc4f90","components/navigation/BottomNav.jsx":"59b2da6c03de","components/navigation/TopBar.jsx":"2da5eb0d829a","design_handoff_pumallen_os/ui_kit/image-slot.js":"fff26d081c8d","ui_kits/pumallen-os/AnalysisScreen.jsx":"c9ade6064e7a","ui_kits/pumallen-os/App.jsx":"81316020418b","ui_kits/pumallen-os/BriefScreen.jsx":"4352083e4038","ui_kits/pumallen-os/CalcScreen.jsx":"cc3b9307be45","ui_kits/pumallen-os/ChatScreen.jsx":"cec16b3ba1cb","ui_kits/pumallen-os/ChecklistScreen.jsx":"046f84ab214a","ui_kits/pumallen-os/EconomyScreen.jsx":"87f776f60f09","ui_kits/pumallen-os/HistoryScreen.jsx":"6722657d6480","ui_kits/pumallen-os/JournalScreen.jsx":"94b5445d22d6","ui_kits/pumallen-os/NarrativeScreen.jsx":"bfab489c6324","ui_kits/pumallen-os/PlannerScreen.jsx":"4a120223f394","ui_kits/pumallen-os/SettingsScreen.jsx":"fd8080b5d7dd","ui_kits/pumallen-os/StatsScreen.jsx":"a07cb003c8e9","ui_kits/pumallen-os/image-slot.js":"fff26d081c8d"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.PumallenOSDesignSystem_ac653c = window.PumallenOSDesignSystem_ac653c || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function Badge(props) {
  var tone = props.tone || 'muted';
  var colors = {
    green: {
      color: 'var(--accent-success)',
      background: 'var(--surface-green-tint)'
    },
    red: {
      color: 'var(--accent-danger)',
      background: 'var(--surface-red-tint)'
    },
    amber: {
      color: 'var(--accent-primary)',
      background: 'var(--surface-gold-tint)'
    },
    muted: {
      color: 'var(--text-lo)',
      background: 'var(--bg-surface-alt)',
      borderColor: 'var(--border-default)'
    }
  };
  var c = colors[tone] || colors.muted;
  var style = {
    display: 'inline-flex',
    alignItems: 'center',
    padding: '3px 9px',
    borderRadius: 'var(--radius-pill)',
    fontSize: 'var(--text-2xs)',
    fontWeight: 700,
    fontFamily: 'var(--font-mono)',
    letterSpacing: 'var(--tracking-wider)',
    border: '1px solid ' + (c.borderColor || 'currentColor'),
    color: c.color,
    background: c.background,
    whiteSpace: 'nowrap',
    flexShrink: 0
  };
  return React.createElement('span', {
    style: style
  }, props.children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function Button(props) {
  var variant = props.variant || 'gold';
  var size = props.size || 'md';
  var disabled = !!props.disabled;
  var [pressed, setPressed] = React.useState(false);
  var base = {
    fontFamily: 'var(--font-body)',
    fontWeight: 800,
    cursor: disabled ? 'default' : 'pointer',
    border: 'none',
    borderRadius: 'var(--radius-lg)',
    touchAction: 'manipulation',
    padding: size === 'sm' ? '9px 13px' : '12px 14px',
    fontSize: size === 'sm' ? 'var(--text-md)' : 'var(--text-lg)',
    opacity: disabled ? .4 : pressed ? .7 : 1,
    transition: 'opacity .15s',
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8
  };
  var variants = {
    gold: {
      background: 'linear-gradient(135deg,var(--gold-deep),var(--gold))',
      color: '#000'
    },
    ghost: {
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      color: 'var(--text-mid)',
      fontWeight: 700
    },
    outline: {
      background: 'transparent',
      border: '1.5px solid var(--border-gold)',
      color: 'var(--accent-primary)'
    },
    success: {
      background: 'var(--surface-green-tint)',
      border: '1.5px solid var(--border-green)',
      color: 'var(--accent-success)'
    },
    danger: {
      background: 'var(--surface-red-tint)',
      border: '1.5px solid var(--border-red)',
      color: 'var(--accent-danger)'
    },
    warn: {
      background: 'var(--surface-gold-tint)',
      border: '1.5px solid var(--border-gold)',
      color: 'var(--accent-primary)'
    }
  };
  var style = Object.assign({}, base, variants[variant] || variants.gold, props.style || {});
  return React.createElement('button', {
    style: style,
    disabled: disabled,
    onClick: props.onClick,
    onMouseDown: function () {
      setPressed(true);
    },
    onMouseUp: function () {
      setPressed(false);
    },
    onMouseLeave: function () {
      setPressed(false);
    },
    onTouchStart: function () {
      setPressed(true);
    },
    onTouchEnd: function () {
      setPressed(false);
    }
  }, props.children);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function Card(props) {
  var style = Object.assign({
    background: 'var(--bg-surface)',
    border: '1px solid var(--border-default)',
    borderRadius: 'var(--radius-xl)',
    padding: props.padded === false ? 0 : 16
  }, props.style || {});
  return React.createElement('div', {
    style: style
  }, props.children);
}
Object.assign(__ds_scope, { Card });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function Chip(props) {
  var tone = props.tone || 'default';
  var tones = {
    default: {
      color: 'var(--text-lo)',
      border: 'var(--border-default)',
      background: 'var(--bg-surface-alt)'
    },
    exec: {
      color: 'var(--accent-success)',
      border: 'var(--border-green)',
      background: 'var(--surface-green-tint)'
    },
    warn: {
      color: 'var(--accent-danger)',
      border: 'var(--border-red)',
      background: 'var(--surface-red-tint)'
    },
    open: {
      color: 'var(--accent-success)',
      border: 'var(--border-green)',
      background: 'var(--surface-green-tint)'
    },
    obs: {
      color: 'var(--accent-primary)',
      border: 'rgba(212,160,23,.3)',
      background: 'transparent'
    }
  };
  var t = tones[tone] || tones.default;
  var style = {
    display: 'inline-flex',
    alignItems: 'center',
    gap: 4,
    padding: props.dense ? '3px 7px' : '4px 10px',
    borderRadius: 'var(--radius-pill)',
    fontSize: props.dense ? 'var(--text-2xs)' : 'var(--text-2xs)',
    fontWeight: 700,
    fontFamily: 'var(--font-mono)',
    whiteSpace: 'nowrap',
    color: t.color,
    border: '1px solid ' + t.border,
    background: t.background
  };
  return React.createElement('div', {
    style: style
  }, props.dot !== false && React.createElement('div', {
    style: {
      width: 4,
      height: 4,
      borderRadius: '50%',
      background: 'currentColor',
      flexShrink: 0
    }
  }), props.children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/data/ChecklistItem.jsx
try { (() => {
function ChecklistItem(props) {
  var checked = !!props.checked;
  var style = {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    padding: '13px 14px',
    background: 'var(--bg-surface-alt)',
    border: '1px solid var(--border-default)',
    borderRadius: 'var(--radius-lg)',
    cursor: 'pointer'
  };
  var boxStyle = {
    width: 22,
    height: 22,
    borderRadius: 'var(--radius-sm)',
    flexShrink: 0,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 14,
    background: checked ? 'var(--accent-success)' : 'var(--bg-page)',
    color: checked ? 'var(--bg-page)' : 'transparent',
    border: checked ? 'none' : '1.5px solid var(--border-gold)'
  };
  return React.createElement('div', {
    style: style,
    onClick: props.onToggle
  }, React.createElement('div', {
    style: boxStyle
  }, checked ? '✓' : ''), React.createElement('div', {
    style: {
      fontSize: 'var(--text-md)',
      color: checked ? 'var(--text-hi)' : 'var(--text-dim)'
    }
  }, props.label));
}
Object.assign(__ds_scope, { ChecklistItem });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ChecklistItem.jsx", error: String((e && e.message) || e) }); }

// components/data/TimeframeCard.jsx
try { (() => {
function TimeframeCard(props) {
  var state = props.state || 'active';
  var locked = state === 'locked';
  var glow = state === 'aligned' ? {
    borderColor: 'var(--border-green)',
    boxShadow: '0 0 20px rgba(0,232,122,.07)'
  } : state === 'rejected' ? {
    borderColor: 'var(--border-red)'
  } : {};
  var style = Object.assign({
    background: 'var(--bg-surface)',
    border: '1px solid var(--border-default)',
    borderRadius: 'var(--radius-xl)',
    overflow: 'hidden',
    opacity: locked ? .4 : 1,
    transition: 'border-color .3s, box-shadow .3s, opacity .3s'
  }, glow);
  var numStyle = {
    width: 40,
    height: 40,
    borderRadius: 'var(--radius-md)',
    background: 'var(--bg-surface-alt)',
    border: '1px solid var(--border-default)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 'var(--text-md)',
    fontWeight: 800,
    color: 'var(--text-muted)',
    fontFamily: 'var(--font-mono)',
    flexShrink: 0,
    transition: 'all .3s'
  };
  if (state === 'aligned') Object.assign(numStyle, {
    background: 'var(--surface-green-tint)',
    borderColor: 'var(--border-green)',
    color: 'var(--accent-success)'
  });
  if (state === 'rejected') Object.assign(numStyle, {
    background: 'var(--surface-red-tint)',
    borderColor: 'var(--border-red)',
    color: 'var(--accent-danger)'
  });
  var badge = locked ? React.createElement(__ds_scope.Badge, {
    tone: 'muted'
  }, '🔒 LOCKED') : state === 'aligned' ? React.createElement(__ds_scope.Badge, {
    tone: 'green'
  }, 'ALIGNED') : state === 'rejected' ? React.createElement(__ds_scope.Badge, {
    tone: 'red'
  }, 'REJECTED') : React.createElement(__ds_scope.Badge, {
    tone: 'amber'
  }, 'UPLOAD');
  return React.createElement('div', {
    style: style
  }, React.createElement('div', {
    style: {
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'space-between',
      padding: '12px 14px',
      gap: 8
    }
  }, React.createElement('div', {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 11
    }
  }, React.createElement('div', {
    style: numStyle
  }, props.code), React.createElement('div', null, React.createElement('div', {
    style: {
      fontSize: 'var(--text-lg)',
      fontWeight: 700,
      color: 'var(--text-hi)'
    }
  }, props.label), React.createElement('div', {
    style: {
      fontSize: 'var(--text-xs)',
      color: 'var(--text-muted)',
      marginTop: 1
    }
  }, props.role))), badge), !locked && React.createElement('div', {
    style: {
      padding: '0 13px 13px',
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, props.showUpload !== false && React.createElement('div', {
    style: {
      display: 'flex',
      gap: 7
    }
  }, React.createElement(__ds_scope.Button, {
    variant: 'ghost',
    size: 'sm',
    style: {
      flex: 1,
      border: '1.5px dashed rgba(212,160,23,.25)',
      textAlign: 'left',
      justifyContent: 'flex-start'
    }
  }, '📷 Upload ' + props.label + ' Chart'), React.createElement(__ds_scope.Button, {
    variant: 'outline',
    size: 'sm'
  }, 'Analyze')), props.children));
}
Object.assign(__ds_scope, { TimeframeCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/TimeframeCard.jsx", error: String((e && e.message) || e) }); }

// components/feedback/LoadingDots.jsx
try { (() => {
function LoadingDots(props) {
  var style = {
    display: 'flex',
    alignItems: 'center',
    gap: 9,
    fontSize: 'var(--text-sm)',
    color: 'var(--text-lo)',
    fontFamily: 'var(--font-mono)'
  };
  var dotBase = {
    width: 6,
    height: 6,
    borderRadius: '50%',
    background: 'var(--accent-primary)',
    boxShadow: '0 0 6px rgba(212,160,23,.5)',
    animation: 'pmDotBounce 1.2s infinite'
  };
  return React.createElement('div', {
    style: style
  }, React.createElement('div', {
    style: {
      display: 'flex',
      gap: 4
    }
  }, [0, .2, .4].map(function (d, i) {
    return React.createElement('span', {
      key: i,
      style: Object.assign({}, dotBase, {
        animationDelay: d + 's'
      })
    });
  })), props.children);
}
Object.assign(__ds_scope, { LoadingDots });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/LoadingDots.jsx", error: String((e && e.message) || e) }); }

// components/feedback/Toast.jsx
try { (() => {
function Toast(props) {
  var show = !!props.show;
  var style = {
    position: props.static ? 'static' : 'fixed',
    bottom: 74,
    left: '50%',
    transform: show ? 'translateX(-50%) translateY(0)' : 'translateX(-50%) translateY(10px)',
    background: 'var(--bg-surface-alt)',
    border: '1px solid var(--accent-primary)',
    color: 'var(--text-hi)',
    fontSize: 'var(--text-md)',
    fontWeight: 600,
    padding: '8px 18px',
    borderRadius: 'var(--radius-pill)',
    opacity: show ? 1 : 0,
    transition: 'all .3s',
    pointerEvents: 'none',
    whiteSpace: 'nowrap',
    display: 'inline-block'
  };
  return React.createElement('div', {
    style: style
  }, props.children);
}
Object.assign(__ds_scope, { Toast });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/Toast.jsx", error: String((e && e.message) || e) }); }

// components/feedback/VerdictBanner.jsx
try { (() => {
function VerdictBanner(props) {
  var verdict = props.verdict || 'execute';
  var isExec = verdict === 'execute';
  var style = {
    borderRadius: 'var(--radius-xl)',
    padding: 20,
    textAlign: 'center',
    background: isExec ? 'var(--surface-green-tint)' : 'var(--surface-red-tint)',
    border: '1.5px solid ' + (isExec ? 'var(--border-green)' : 'var(--border-red)')
  };
  var titleColor = isExec ? 'var(--accent-success)' : 'var(--accent-danger)';
  return React.createElement('div', {
    style: style
  }, React.createElement('span', {
    style: {
      fontSize: 36,
      display: 'block',
      marginBottom: 8
    }
  }, props.icon || (isExec ? '🎯' : '🚫')), React.createElement('div', {
    style: {
      fontSize: 'var(--text-3xl)',
      fontWeight: 800,
      letterSpacing: 'var(--tracking-widest)',
      textTransform: 'uppercase',
      marginBottom: 7,
      color: titleColor
    }
  }, props.title || (isExec ? 'Execute' : 'Stand Down')), React.createElement('div', {
    style: {
      fontSize: 'var(--text-base)',
      color: 'var(--text-lo)',
      lineHeight: 'var(--leading-relaxed)'
    }
  }, props.subtitle), props.children);
}
Object.assign(__ds_scope, { VerdictBanner });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/feedback/VerdictBanner.jsx", error: String((e && e.message) || e) }); }

// components/forms/TextField.jsx
try { (() => {
var baseInput = {
  width: '100%',
  padding: '10px 12px',
  background: 'var(--bg-page)',
  border: '1.5px solid var(--border-gold)',
  borderRadius: 'var(--radius-md)',
  color: 'var(--text-hi)',
  fontFamily: 'var(--font-mono)',
  fontSize: 'var(--text-md)',
  boxSizing: 'border-box'
};
function TextField(props) {
  var type = props.type || 'text';
  var rest = {
    placeholder: props.placeholder,
    value: props.value,
    onChange: props.onChange,
    onKeyDown: props.onKeyDown
  };
  return React.createElement('div', null, props.label && React.createElement('label', {
    style: {
      color: 'var(--text-hi)',
      fontSize: 'var(--text-base)',
      fontWeight: 700,
      fontFamily: 'var(--font-body)'
    }
  }, props.label), type === 'textarea' ? React.createElement('textarea', Object.assign({}, rest, {
    style: Object.assign({}, baseInput, {
      minHeight: 60,
      marginTop: props.label ? 6 : 0,
      fontFamily: 'var(--font-body)'
    })
  })) : React.createElement('input', Object.assign({}, rest, {
    type: type,
    style: Object.assign({}, baseInput, {
      marginTop: props.label ? 6 : 0
    })
  })));
}
function Select(props) {
  return React.createElement('select', {
    value: props.value,
    onChange: props.onChange,
    style: Object.assign({}, baseInput, {
      fontFamily: 'var(--font-body)'
    })
  }, (props.options || []).map(function (o) {
    return React.createElement('option', {
      key: o,
      value: o
    }, o);
  }));
}
Object.assign(__ds_scope, { TextField, Select });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/TextField.jsx", error: String((e && e.message) || e) }); }

// components/navigation/BottomNav.jsx
try { (() => {
var ITEMS = [{
  id: 'chat',
  icon: '💬',
  label: 'AI Chat'
}, {
  id: 'analysis',
  icon: '🔬',
  label: 'Analysis'
}, {
  id: 'checklist',
  icon: '✅',
  label: 'Checks'
}, {
  id: 'calc',
  icon: '🧮',
  label: 'Calc'
}, {
  id: 'journal',
  icon: '📒',
  label: 'Journal'
}, {
  id: 'more',
  icon: '⋯',
  label: 'More'
}];
function BottomNav(props) {
  var active = props.active || 'analysis';
  var style = {
    position: props.static ? 'static' : 'fixed',
    bottom: 0,
    left: 0,
    right: 0,
    height: 'var(--nav-height)',
    background: 'var(--bg-surface)',
    borderTop: '1px solid var(--border-default)',
    display: 'flex',
    alignItems: 'center',
    zIndex: 9999
  };
  return React.createElement('div', {
    style: style
  }, (props.items || ITEMS).map(function (it) {
    var isAct = it.id === active;
    return React.createElement('div', {
      key: it.id,
      onClick: function () {
        props.onSelect && props.onSelect(it.id);
      },
      style: {
        flex: 1,
        display: 'flex',
        flexDirection: 'column',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 3,
        fontSize: 'var(--text-2xs)',
        fontWeight: 600,
        color: isAct ? 'var(--accent-primary)' : 'var(--text-muted)',
        cursor: 'pointer',
        userSelect: 'none',
        minHeight: 'var(--nav-height)'
      }
    }, React.createElement('div', {
      style: {
        fontSize: 20,
        lineHeight: 1
      }
    }, it.icon), it.label);
  }));
}
Object.assign(__ds_scope, { BottomNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/BottomNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/TopBar.jsx
try { (() => {
function TopBar(props) {
  var style = {
    position: props.static ? 'static' : 'fixed',
    top: 0,
    left: 0,
    right: 0,
    zIndex: 100,
    background: 'rgba(10,8,0,0.97)',
    borderBottom: '1px solid var(--border-default)',
    padding: 'var(--topbar-pad)',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between'
  };
  return React.createElement('div', {
    style: style
  }, React.createElement('div', {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 9
    }
  }, React.createElement('div', null, React.createElement('div', {
    style: {
      fontSize: 'var(--text-xl)',
      fontWeight: 800,
      color: 'var(--accent-primary)',
      letterSpacing: 'var(--tracking-wider)'
    }
  }, props.title || 'PUMALLEN OS'), React.createElement('div', {
    style: {
      fontSize: 'var(--text-2xs)',
      color: 'var(--text-muted)',
      letterSpacing: 'var(--tracking-wide)'
    }
  }, props.subtitle))), props.children);
}
Object.assign(__ds_scope, { TopBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/TopBar.jsx", error: String((e && e.message) || e) }); }

// design_handoff_pumallen_os/ui_kit/image-slot.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <image-slot> — user-fillable image placeholder.
 *
 * Drop this into a deck, mockup, or page wherever a design needs an image.
 * You control the slot's shape; it sizes to its container by default. When the search_stock_photos tool
 * is available, prefill the slot by default — write the photo's URL into
 * src (with credit/credit-href); the user can still fill or replace it
 * by dragging an image file onto it (or clicking to browse). The dropped
 * image persists across reloads via a .image-slots.state.json sidecar —
 * same read-via-fetch / write-via-window.omelette pattern as
 * design_canvas.jsx, so the filled slot shows on share links, downloaded
 * zips, and PPTX export. Outside the omelette runtime the slot is read-only.
 *
 * The sidecar is a SIBLING of the HTML file that uses this component: the
 * read is a document-relative fetch, and the host resolves the bridge's
 * sidecar writes into the previewed file's directory to match (same
 * contract as design_canvas.jsx). Pages in the same directory share one
 * sidecar; keep slot ids distinct across them.
 *
 * Attributes:
 *   id           Persistence key. REQUIRED for the drop to survive reload —
 *                every slot on the page needs a distinct id.
 *   shape        'rect' | 'rounded' | 'circle' | 'pill'   (default 'rounded')
 *                'circle' applies 50% border-radius; on a non-square slot
 *                that's an ellipse — set equal width and height for a true
 *                circle.
 *   radius       Corner radius in px for 'rounded'.       (default 12)
 *   mask         Any CSS clip-path value. Overrides `shape` — use this for
 *                hexagons, blobs, arbitrary polygons.
 *   fit          Initial framing baseline: cover | contain.   (default 'cover')
 *                cover starts the image filling the frame (overflow cropped);
 *                contain starts it fully visible (letterboxed). Either way the
 *                user can always pan/scale from there — double-click, or the
 *                Edit control, enters reframe mode (drag to move, scroll or
 *                corner-handles to scale; Escape / click-out commits). The
 *                crop persists alongside the image in the sidecar.
 *   placeholder  Empty-state caption.                      (default 'Drop an image')
 *   src          Optional initial/fallback image URL. Prefill it with a real
 *                photo via search_stock_photos when that tool is available
 *                (set credit/credit-href from the result). A user drop
 *                overrides it; clearing the drop reveals src again.
 *   credit       Attribution text shown as a small overlay at the
 *                bottom-left of the filled slot. REQUIRED whenever src
 *                points at any Unsplash host (images.unsplash.com,
 *                plus.unsplash.com, …): an Unsplash src with no credit
 *                renders an error tile INSTEAD of the photo (Unsplash
 *                terms forbid showing their photos unattributed). Use the
 *                exact form 'Photo by {photographer name} on Unsplash' —
 *                the overlay then links the name to credit-href and
 *                'Unsplash' to the Unsplash homepage, and links back to
 *                unsplash.com automatically get the required utm referral
 *                params appended at render time. The credit belongs to
 *                the src image, so it only shows while src is what's
 *                displayed — a user-dropped image hides it.
 *   credit-href  Link for the photographer's name in the credit overlay
 *                (their Unsplash profile URL from the stock-photo search
 *                results). http(s) URLs only — anything else renders the
 *                name as plain text.
 *
 * Sizing: the slot fills its container by default (width/height 100%).
 * Put it in a sized wrapper — absolutely positioned, a grid cell, a fixed
 * frame — and it takes exactly that box. When the parent's height is
 * indefinite (ordinary flow), it falls back to full width at a 3:2 aspect
 * ratio instead of collapsing. In a shrink-to-fit parent (a float,
 * width:max-content, an unsized absolute wrapper), percentages have
 * nothing to resolve against — size the slot or its wrapper explicitly
 * there. For a fixed-size slot, set
 * width/height on the element itself (inline style), which overrides the
 * default. When
 * layering content above a slot (full-bleed layouts), make the overlay
 * click-through — pointer-events: none on scrims/text plates, re-enabled
 * on interactive children — so the slot's hover controls stay reachable.
 * Keep the slot's bottom-left corner visually clear as well: the credit
 * overlay renders there, and a dark fade or text plate covering it hides
 * the attribution Unsplash's terms require — end the fade above that
 * corner, or keep it nearly transparent where the credit sits.
 *
 * Usage:
 *   <div style="position:relative;width:100%;height:100%">      <!-- full-bleed: -->
 *     <image-slot id="bg" shape="rect"></image-slot>            <!-- fills the wrapper -->
 *   </div>
 *   <image-slot id="hero"   style="width:800px;height:450px" shape="rounded" radius="20"
 *               placeholder="Drop a hero image"></image-slot>
 *   <image-slot id="avatar" style="width:120px;height:120px" shape="circle"></image-slot>
 *   <image-slot id="kite"   style="width:300px;height:300px"
 *               mask="polygon(50% 0, 100% 50%, 50% 100%, 0 50%)"></image-slot>
 */
/* END USAGE */

(() => {
  const STATE_FILE = '.image-slots.state.json';

  // Unsplash terms require visible attribution wherever their photos
  // display, and every link back to unsplash.com must carry utm referral
  // params. Two render-time rules enforce that here:
  //  - an Unsplash-src slot with NO credit attribute renders an error
  //    tile INSTEAD of the photo (an uncredited Unsplash photo on screen
  //    is itself the terms violation, so it never renders bare);
  //  - rendered credit links pointing at unsplash.com get the referral
  //    params appended when absent (credit-href values live in page
  //    content that can't be edited after the fact).
  // Keep the utm_source value in sync with UTM_SOURCE in
  // platform/web-agent/unsplash.ts — this file is a project-local
  // artifact and cannot import it (equality is pinned by tests).
  const UNSPLASH_HOMEPAGE_HREF = 'https://unsplash.com/?utm_source=claude_design&utm_medium=referral';
  // Host rule mirrors the hotlink validator that admits Unsplash srcs into
  // pages in the first place (cdn$ in unsplash.ts: apex or any subdomain)
  // — Unsplash+ results serve from plus.unsplash.com, not just images.*,
  // and an admitted-but-uncredited photo must error whatever unsplash
  // host it rides on.
  // Trailing-dot FQDNs (images.unsplash.com.) are the same host to the
  // browser but would miss the regex — strip one dot so the check fails
  // CLOSED (unrecognized-but-real Unsplash srcs must error, not render).
  const isUnsplashHost = u => {
    try {
      return /(^|\.)unsplash\.com$/.test(new URL(u, document.baseURI).hostname.replace(/\.$/, ''));
    } catch {
      return false;
    }
  };
  // Render-time referral normalization for links back to Unsplash:
  // appends utm_source/utm_medium when absent, preserves every existing
  // query param, never overwrites an existing utm_source, and passes
  // non-Unsplash URLs through untouched. Input is an ABSOLUTE validated
  // http(s) URL (the credit render funnel resolves + validates first).
  const withReferral = href => {
    try {
      const u = new URL(href);
      if (!/(^|\.)unsplash\.com$/.test(u.hostname.replace(/\.$/, ''))) {
        return href;
      }
      if (!u.searchParams.has('utm_source')) {
        u.searchParams.set('utm_source', 'claude_design');
      }
      if (!u.searchParams.has('utm_medium')) {
        u.searchParams.set('utm_medium', 'referral');
      }
      return u.toString();
    } catch (e) {
      return href;
    }
  };
  // 2× a ~600px slot in a 1920-wide deck — retina-sharp without making the
  // sidecar enormous. A 1200px WebP at q=0.85 is ~150-300KB.
  const MAX_DIM = 1200;
  // Raster formats only. SVG is excluded (can carry script; createImageBitmap
  // on SVG blobs is inconsistent). GIF is excluded because the canvas
  // re-encode keeps only the first frame, so an animated GIF would silently
  // go still — better to reject than surprise.
  const ACCEPT = ['image/png', 'image/jpeg', 'image/webp', 'image/avif'];

  // ── Shared sidecar store ────────────────────────────────────────────────
  // One fetch + immediate write-on-change for every <image-slot> on the
  // page. Reads via fetch() so viewing works anywhere the HTML and sidecar
  // are served together; writes go through window.omelette.writeFile, which
  // the host allowlists to *.state.json basenames only.
  const subs = new Set();
  let slots = {};
  // ids explicitly cleared before the sidecar fetch resolved — otherwise
  // the merge below can't tell "never set" from "just deleted" and would
  // resurrect the sidecar's stale value.
  const tombstones = new Set();
  let loaded = false;
  let loadP = null;
  function load() {
    if (loadP) return loadP;
    loadP = fetch(STATE_FILE).then(r => r.ok ? r.json() : null).then(j => {
      // Merge: sidecar loses to any in-memory change that raced ahead of
      // the fetch (drop or clear) so neither is clobbered by hydration.
      if (j && typeof j === 'object') {
        const merged = Object.assign({}, j, slots);
        // A framing-only write that raced ahead of hydration must not
        // drop a user image that's only on disk — inherit u from the
        // sidecar for any in-memory entry that lacks one.
        for (const k in slots) {
          if (merged[k] && !merged[k].u && j[k]) {
            merged[k].u = typeof j[k] === 'string' ? j[k] : j[k].u;
          }
        }
        for (const id of tombstones) delete merged[id];
        slots = merged;
      }
      tombstones.clear();
    }).catch(() => {}).then(() => {
      loaded = true;
      subs.forEach(fn => fn());
    });
    return loadP;
  }

  // Serialize writes so two near-simultaneous drops on different slots
  // can't reorder at the backend and leave the sidecar with only the
  // first. A save requested mid-flight just marks dirty and re-fires on
  // completion with the then-current slots.
  let saving = false;
  let saveDirty = false;
  // Unload-time flush: save()'s serialization defers a mid-RTT re-fire to a
  // .then that never runs in an unloading document, silently dropping a
  // pagehide commit. Post the current slots immediately instead — content
  // is a superset snapshot of any in-flight save's, the write is a
  // whole-file last-writer-wins replace, and postMessage FIFO delivers it
  // to the host after the in-flight one, so a backend-side reorder at
  // worst reproduces the dropped-commit outcome this flush improves on.
  // Guarded on the initial sidecar read: pre-hydration slots can miss
  // other slots' persisted entries, and flushing it would clobber them —
  // that narrow case stays best-effort (the in-memory merge in load()
  // cannot happen in an unloading document anyway).
  function flushNow() {
    if (!loaded) return;
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    try {
      Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {});
    } catch (e) {}
  }
  function save() {
    if (saving) {
      saveDirty = true;
      return;
    }
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    saving = true;
    Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {}).then(() => {
      saving = false;
      if (saveDirty) {
        saveDirty = false;
        save();
      }
    });
  }
  const S_MAX = 5;
  const clampS = s => Math.max(1, Math.min(S_MAX, s));

  // Normalize a stored slot value. Pre-reframe sidecars stored a bare
  // data-URL string; newer ones store {u, s, x, y}. Either shape is valid.
  function getSlot(id) {
    const v = slots[id];
    if (!v) return null;
    return typeof v === 'string' ? {
      u: v,
      s: 1,
      x: 0,
      y: 0
    } : v;
  }
  function setSlot(id, val) {
    if (!id) return;
    if (val) {
      slots[id] = val;
      tombstones.delete(id);
    } else {
      delete slots[id];
      if (!loaded) tombstones.add(id);
    }
    subs.forEach(fn => fn());
    // A drop is rare + high-value — write immediately so nav-away can't lose
    // it. Gate on the initial read so we don't overwrite a sidecar we haven't
    // merged yet; the merge in load() keeps this change once the read lands.
    if (loaded) save();else load().then(save);
  }

  // ── Image downscale ─────────────────────────────────────────────────────
  // Encode through a canvas so the sidecar carries resized bytes, not the
  // raw upload. Longest side is capped at 2× the slot's rendered width
  // (retina) and at MAX_DIM. WebP keeps alpha and is ~10× smaller than PNG
  // for photos, so there's no need for per-image format picking.
  async function toDataUrl(file, targetW) {
    const bitmap = await createImageBitmap(file);
    try {
      const cap = Math.min(MAX_DIM, Math.max(1, Math.round(targetW * 2)) || MAX_DIM);
      const scale = Math.min(1, cap / Math.max(bitmap.width, bitmap.height));
      const w = Math.max(1, Math.round(bitmap.width * scale));
      const h = Math.max(1, Math.round(bitmap.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
      return canvas.toDataURL('image/webp', 0.85);
    } finally {
      bitmap.close && bitmap.close();
    }
  }

  // ── Custom element ──────────────────────────────────────────────────────
  const stylesheet =
  // Fill the container by default: slots are usually placed inside a
  // sized wrapper (a hero frame, a grid cell, an inset:0 layer) and are
  // expected to take that box — a fixed intrinsic size would render as
  // a small tile in the corner of a full-bleed wrapper instead.
  // aspect-ratio is the companion fallback that keeps a bare slot
  // visible when the parent's height is indefinite: height:100%
  // resolves to auto there, and the ratio then derives height from
  // width instead of letting the slot collapse to zero height.
  // Explicit width/height on the element override all of this.
  // color:inherit (not a fixed near-black): the placeholder chrome —
  // empty-state icon/caption (currentColor) and the dashed ring — must
  // read on dark decks too, and the slide's own text color is the one
  // color guaranteed to contrast with the slide background. The soft
  // look comes from opacity on those parts, not from a baked-in alpha.
  ':host{display:block;position:relative;' + '  font:13px/1.3 system-ui,-apple-system,sans-serif;' + '  width:100%;height:100%;aspect-ratio:3/2}' + '.empty .cap,.empty .sub{opacity:.75}' + '.frame{position:absolute;inset:0;overflow:hidden;background:rgba(127,127,127,.08)}' +
  // .frame img (clipped) and .spill (unclipped ghost + handles) share the
  // same left/top/width/height in frame-%, computed by _applyView(), so the
  // inside-mask crop and the outside-mask spill stay pixel-aligned.
  '.frame img{position:absolute;max-width:none;transform:translate(-50%,-50%);' + '  -webkit-user-drag:none;user-select:none;touch-action:none}' +
  // Reframe mode (double-click): the full image spills past the mask. The
  // spill layer is sized to the IMAGE bounds so its corners are where the
  // resize handles belong. The ghost <img> inside is translucent; the real
  // clipped <img> underneath shows the opaque in-mask crop.
  // popover=manual promotes the spill to the top layer on reframe, so it is
  // not clipped by any overflow:hidden / clip-path / scroll-container
  // ancestor (a plain z-index can't escape overflow clipping). UA popover
  // defaults (inset:0;margin:auto) are reset; _applyView sets viewport px.
  '.spill{position:fixed;margin:0;inset:auto;border:0;padding:0;background:transparent;' + '  overflow:visible;transform:translate(-50%,-50%);z-index:1;cursor:grab;touch-action:none}' + ':host([data-panning]) .spill{cursor:grabbing}' + '.spill .ghost{position:absolute;inset:0;width:100%;height:100%;opacity:.35;' + '  pointer-events:none;-webkit-user-drag:none;user-select:none;' + '  box-shadow:0 0 0 1px rgba(0,0,0,.2),0 12px 32px rgba(0,0,0,.2)}' + '.spill .handle{position:absolute;width:12px;height:12px;border-radius:50%;' + '  background:#fff;box-shadow:0 0 0 1.5px #c96442,0 1px 3px rgba(0,0,0,.3);' + '  transform:translate(-50%,-50%)}' + '.spill .handle[data-c=nw]{left:0;top:0;cursor:nwse-resize}' + '.spill .handle[data-c=ne]{left:100%;top:0;cursor:nesw-resize}' + '.spill .handle[data-c=sw]{left:0;top:100%;cursor:nesw-resize}' + '.spill .handle[data-c=se]{left:100%;top:100%;cursor:nwse-resize}' + ':host([data-reframe]){z-index:10}' + ':host([data-reframe]) .frame{box-shadow:0 0 0 2px #c96442}' + '.empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  cursor:pointer;user-select:none}' + '.empty svg{opacity:.45}' + '.empty .cap{max-width:90%;font-weight:500;letter-spacing:.01em}' + '.empty .sub{font-size:11px}' + '.empty .sub u{text-underline-offset:2px}' + '.empty:hover .sub{opacity:1}' + ':host([data-over]) .frame{outline:2px solid #c96442;outline-offset:-2px;' + '  background:rgba(201,100,66,.10)}' + '.ring{position:absolute;inset:0;pointer-events:none;border:1.5px dashed currentColor;' + '  opacity:.35;transition:border-color .12s,opacity .12s}' + ':host([data-over]) .ring{border-color:#c96442;opacity:1}' + ':host([data-filled]) .ring{display:none}' +
  // Controls overlay INSIDE the frame, pinned to the top-right corner, so
  // a full-bleed slot in an overflow:hidden container still shows them
  // (the old below-mask placement got clipped). Credit sits bottom-left,
  // so top-right avoids collision. The blurred pill background keeps them
  // legible over the image.
  // The UA [popover] base rule styles the element in EVERY state (only
  // display:none is gated on :not(:popover-open), and the display:flex
  // below overrides that) — so the UA resets live HERE, like .spill's,
  // or the ordinary hover-state strip renders as a bordered Canvas box
  // centered by margin:auto. inset:auto precedes top/right (shorthand).
  '.ctl{position:absolute;inset:auto;top:8px;right:8px;margin:0;border:0;padding:0;' + '  background:transparent;overflow:visible;' + '  display:flex;gap:6px;opacity:0;pointer-events:none;transition:opacity .12s;z-index:2;' + '  white-space:nowrap}' +
  // While reframing, the spill owns the top layer and would swallow every
  // click on the in-frame controls. Promoting .ctl into the top layer
  // ABOVE the spill (shown after it — later popovers stack higher) keeps
  // Edit-as-toggle and Replace clickable mid-reframe. _applyView pins it
  // to the frame's top-right in viewport px (translateX(-100%)
  // right-aligns against the computed left edge); inset:auto clears the
  // base rule's top/right so the inline left/top position it alone.
  '.ctl:popover-open{position:fixed;inset:auto;transform:translateX(-100%)}' + ':host([data-filled][data-editable]:hover) .ctl,:host([data-reframe]) .ctl' + '  {opacity:1;pointer-events:auto}' + '.ctl button{appearance:none;border:0;border-radius:6px;padding:5px 10px;cursor:pointer;' + '  background:rgba(0,0,0,.65);color:#fff;font:11px/1 system-ui,-apple-system,sans-serif;' + '  backdrop-filter:blur(6px)}' + '.ctl button:hover{background:rgba(0,0,0,.8)}' + '.err{position:absolute;left:8px;bottom:8px;right:8px;color:#b3261e;font-size:11px;' + '  background:rgba(255,255,255,.85);padding:4px 6px;border-radius:5px;pointer-events:none}' +
  // Replacement in flight: after a src swap the browser keeps painting
  // the PREVIOUS image until the new one decodes, so a Replace would
  // flash the old photo and then pop. Hide the stale frame (visibility,
  // not display — _applyView geometry still applies) and spin until the
  // new image reports in (load/error clears data-swapping).
  ':host([data-swapping]) .frame img{visibility:hidden}' + '.loading{position:absolute;inset:0;display:none;align-items:center;' + '  justify-content:center;pointer-events:none}' + ':host([data-swapping]) .loading{display:flex}' + '.loading::after{content:"";width:22px;height:22px;border-radius:50%;' + '  border:2px solid rgba(127,127,127,.25);border-top-color:currentColor;' + '  animation:om-slot-spin .7s linear infinite}' + '@keyframes om-slot-spin{to{transform:rotate(360deg)}}' +
  // Reduced motion: the static two-tone ring still reads as "working".
  '@media (prefers-reduced-motion:reduce){.loading::after{animation:none}}' + '.credit{position:absolute;left:6px;bottom:6px;max-width:calc(100% - 12px);display:none;' + '  padding:3px 7px;border-radius:5px;background:rgba(0,0,0,.55);color:#fff;' + '  font:10px/1.2 system-ui,-apple-system,sans-serif;text-decoration:none;' + '  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;backdrop-filter:blur(6px)}' +
  // The credit is a SPAN holding one or two <a>s (Unsplash's prescribed
  // form links the photographer AND Unsplash) — anchors style inline so
  // the overlay reads as one line of text.
  '.credit a{color:inherit;text-decoration:none}' + '.credit a:hover,.credit a:focus-visible{text-decoration:underline}' + ':host([data-filled][data-credit]) .credit{display:block}' +
  // Exports must ship JUST the image — no hover controls, no credit chip
  // (the host marks <html data-om-exporting> for the capture window; the
  // page-level hide script can't reach shadow DOM, this rule can).
  ':host-context([data-om-exporting]) .ctl,' + ':host-context([data-om-exporting]) .credit{display:none !important}' +
  // Print must ship just the image too: the hover-gated controls can be
  // mid-hover when print() fires, and the credit chip is screen chrome —
  // the same rule the capture window gets, keyed on print media instead
  // of the host's data-om-exporting mark (the print path sets no mark).
  '@media print{.ctl,.credit{display:none !important}}' +
  // No export-window mask rules here on purpose: the export capture
  // releases the replacement mask by REMOVING data-swapping (the
  // shadow-root pass in pages/export/shared.ts HIDE_EXPORT_CHROME_SCRIPT)
  // — attribute removal works in every engine (:host-context is
  // Chromium-only), is scoped by construction to slots actually
  // mid-swap, and hides the spinner through the same gate. A masked img
  // would otherwise be silently dropped from PPTX decks (the capture
  // walk skips visibility:hidden imgs).
  // Attribution error tile: REPLACES the photo when an Unsplash src has
  // no credit attribute — rendering the photo uncredited is the terms
  // violation, so the photo must not appear at all.
  // Calm and neutral on purpose (review feedback): the tile informs the
  // user; the fix instructions are machine-facing (usage docblock, tool
  // description, and the turn-end scan's bounce copy name the attributes
  // for the agent).
  '.attr-error{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  background:#f2f1ef;color:#6e6c66;user-select:none;' + '  font:13px/1.45 system-ui,-apple-system,sans-serif}' + '.attr-error svg{opacity:.55}' + '.attr-error .cap{max-width:92%;font-weight:500;letter-spacing:.01em}' + ':host([data-attribution-error]) .attr-error{display:flex}' + ':host([data-attribution-error]) .ring{display:none}';
  const icon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>' + '<path d="m21 15-5-5L5 21"/></svg>';
  const warnIcon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>' + '<path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
  class ImageSlot extends HTMLElement {
    static get observedAttributes() {
      return ['shape', 'radius', 'mask', 'fit', 'placeholder', 'src', 'id', 'credit', 'credit-href'];
    }

    /** Duplicate-slide hook (called by deck-stage, see its
     *  _remintDuplicateIds): copy this id's stored image, if any, under a
     *  freshly minted key and return that key — so a duplicated slide's
     *  slot keeps its dropped photo instead of reverting to the
     *  placeholder. 'isFree' is the caller's uniqueness check (document
     *  ids); candidates must ALSO be unused in the sidecar, which can
     *  hold keys from other pages sharing the project root. (An EMPTY
     *  slot on another page leaves no sidecar entry, so its id is not
     *  detectable here — a minted key can collide with it and that slot
     *  would show this photo. Same blast radius as two pages reusing an
     *  id by hand, which the shared sidecar already permits.) Returns null
     *  when no id could be minted (caller strips the id, today's
     *  behavior). */
    static cloneSlot(fromId, isFree) {
      if (typeof fromId !== 'string' || !fromId) return null;
      // Pre-hydration the store can't veto candidates or source the copy
      // — degrade to the strip (today's behavior) rather than mint
      // against keys we can't see yet. Any rendered (= droppable) slot
      // means load() has already settled.
      if (!loaded) return null;
      const stem = fromId.replace(/-\d+$/, '') || fromId;
      for (let n = 2; n < 100; n++) {
        const toId = stem + '-' + n;
        if (toId === fromId) continue;
        if (slots[toId] !== undefined) {
          // Reuse a key holding this exact value (bytes AND crop) if no
          // live element here owns it — a duplicate op the host refused
          // after minting leaves such a key behind, and reusing keeps
          // refused retries from accumulating one orphaned copy per
          // attempt. Full equality (not just bytes) so a byte-identical
          // key another PAGE owns with its own crop is stepped past, not
          // adopted or rewritten. (Entries without .u never match.)
          const prev = getSlot(toId);
          const cur = getSlot(fromId);
          if (!(prev && cur && prev.u && prev.u === cur.u && prev.s === cur.s && prev.x === cur.x && prev.y === cur.y && (typeof isFree !== 'function' || isFree(toId)))) continue;
          return toId;
        }
        if (typeof isFree === 'function' && !isFree(toId)) continue;
        const v = getSlot(fromId);
        if (v) setSlot(toId, Object.assign({}, v));
        return toId;
      }
      return null;
    }
    constructor() {
      super();
      // clonable: rail thumbnails deep-clone slides and carry this shadow
      // along; reuse an already-cloned root so upgrade-after-clone works.
      // (Deliberately NOT serializable — a getHTML consumer would embed
      // multi-MB sidecar data-URLs into serialized page HTML.)
      const root = this.shadowRoot || this.attachShadow({
        mode: 'open',
        clonable: true
      });
      // .spill and .ctl sit OUTSIDE .frame so overflow:hidden + border-radius
      // on the frame (circle, pill, rounded) can't clip them.
      root.innerHTML = '<style>' + stylesheet + '</style>' + '<div class="frame" part="frame">' + '  <img part="image" alt="" draggable="false" style="display:none">' + '  <div class="empty" part="empty">' + icon + '    <div class="cap"></div>' + '    <div class="sub">or <u>browse files</u></div></div>' + '  <div class="attr-error" part="attribution-error">' + warnIcon + '    <div class="cap">This photo needs attribution</div></div>' + '  <div class="loading" part="loading"></div>' + '  <div class="ring" part="ring"></div>' + '</div>' +
      // Outside .frame, like .spill/.ctl — the frame's overflow:hidden +
      // border-radius/clip-path would cut the credit off on circle/pill/mask.
      // A SPAN, not an <a>: the prescribed Unsplash credit holds two links
      // (photographer + Unsplash), built per-render in _render().
      '<span class="credit" part="credit"></span>' + '<div class="spill" popover="manual" data-dc-edit-transparent>' + '  <img class="ghost" alt="" draggable="false">' + '  <div class="handle" data-c="nw"></div><div class="handle" data-c="ne"></div>' + '  <div class="handle" data-c="sw"></div><div class="handle" data-c="se"></div>' + '</div>' +
      // data-dc-edit-transparent: the DC editor's edit-mode picker lets
      // clicks through for chrome marked with it (EDIT_TRANSPARENT_SEL)
      // — without it, Replace/Edit clicks in Edit mode are swallowed by
      // element selection and the controls look dead.
      '<div class="ctl" popover="manual" data-dc-edit-transparent><button data-act="replace" title="Replace image">Replace</button>' + '  <button data-act="edit" title="Reframe image">Edit</button></div>' + '<input type="file" accept="' + ACCEPT.join(',') + '" hidden>';
      this._frame = root.querySelector('.frame');
      this._ring = root.querySelector('.ring');
      this._img = root.querySelector('.frame img');
      this._empty = root.querySelector('.empty');
      this._cap = root.querySelector('.cap');
      this._sub = root.querySelector('.sub');
      this._spill = root.querySelector('.spill');
      this._ctl = root.querySelector('.ctl');
      this._credit = root.querySelector('.credit');
      this._attrError = root.querySelector('.attr-error');
      // Credit clicks open the link, not browse/reframe.
      this._credit.addEventListener('click', e => e.stopPropagation());
      this._credit.addEventListener('dblclick', e => e.stopPropagation());
      this._ghost = root.querySelector('.ghost');
      this._err = null;
      this._input = root.querySelector('input');
      this._depth = 0;
      this._gen = 0;
      // Encode-in-flight marker (the owning _ingest generation): while set,
      // the same-src "nothing in flight" clear in _render must not fire —
      // the stored value still points at the OLD image until the encode
      // lands, so that clear would unmask the stale image mid-replace.
      this._swapGen = 0;
      // Render-owned swap in flight: set when _render assigns a new src,
      // cleared only by the img's own load/error (or the empty branch).
      // img.complete CANNOT stand in for this — setting src only QUEUES
      // the current-request swap (a microtask), so synchronously after an
      // assignment, complete still reports the OLD settled request. The
      // pick path does exactly that: the host sets src, credit, and
      // credit-href back-to-back in one task, and renders #2/#3 would
      // read the stale complete === true and drop the mask one render
      // after it was set.
      this._loadPending = false;
      // See _render's empty branch: a transient attribution-error wipe of a
      // showing image must make the follow-up render a replacement (spinner),
      // not a first fill (blank frame).
      this._hidShowing = false;
      this._view = {
        s: 1,
        x: 0,
        y: 0
      };
      this._subFn = () => this._render();
      // Shadow-DOM listeners live with the shadow DOM — bound once here so
      // disconnect/reconnect (e.g. React remount) doesn't stack handlers.
      this._empty.addEventListener('click', () => this._input.click());
      root.addEventListener('click', e => {
        const act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
        if (!act) return;
        // The hidden controls are opacity-0 but still tabbable — without
        // this gate a keyboard user could drive them on a read-only share
        // link (mirrors the dblclick handler's editable gate).
        if (!this.hasAttribute('data-editable')) return;
        if (act === 'replace') {
          this._exitReframe(true);
          // Host-owned picker (Unsplash modal; it also offers local import).
          this.dispatchEvent(new CustomEvent('image-slot:pick', {
            bubbles: true,
            composed: true,
            detail: {
              id: this.id || null
            }
          }));
        }
        if (act === 'edit') {
          if (!this._reframes()) return;
          if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
        }
      });
      this._input.addEventListener('change', () => {
        const f = this._input.files && this._input.files[0];
        if (f) this._ingest(f);
        this._input.value = '';
      });
      // naturalWidth/Height aren't known until load — re-apply so the cover
      // baseline is computed from real dimensions, not the 100%×100% fallback.
      // load/error also release the replacement-in-flight mask (via the
      // single discipline in _releaseMask): the swap is only revealed once
      // the new image can actually paint (on error the frame shows its
      // background, same as a fresh slot with a broken src).
      this._img.addEventListener('load', () => {
        this._loadPending = false;
        this._releaseMask(true);
        this._applyView();
      });
      this._img.addEventListener('error', () => {
        this._loadPending = false;
        this._releaseMask(true);
      });
      // Gated only on editable — any filled slot can be repositioned/scaled,
      // regardless of fit. Share links (no writeFile) stay static.
      this.addEventListener('dblclick', e => {
        if (!this.hasAttribute('data-editable') || !this._reframes()) return;
        e.preventDefault();
        if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
      });
      // Pan + resize both originate on the spill layer. A handle pointerdown
      // drives an aspect-locked resize anchored at the opposite corner; any
      // other pointerdown on the spill pans. Offsets are frame-% so a
      // reframed slot survives responsive resize / PPTX export.
      this._spill.addEventListener('pointerdown', e => {
        if (e.button !== 0 || !this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        e.stopPropagation();
        this._spill.setPointerCapture(e.pointerId);
        const rect = this.getBoundingClientRect();
        const fw = rect.width || 1,
          fh = rect.height || 1;
        const corner = e.target.getAttribute && e.target.getAttribute('data-c');
        let move;
        if (corner) {
          // Resize about the OPPOSITE corner. Viewport-px throughout (rect
          // fw/fh, not clientWidth) so the math survives a transform:scale()
          // ancestor — deck_stage renders slides scaled-to-fit.
          const iw = this._img.naturalWidth || 1,
            ih = this._img.naturalHeight || 1;
          const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
          const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
          const sx = corner.includes('e') ? 1 : -1;
          const sy = corner.includes('s') ? 1 : -1;
          const s0 = this._view.s;
          const w0 = iw * base * s0,
            h0 = ih * base * s0;
          const cx0 = (50 + this._view.x) / 100 * fw;
          const cy0 = (50 + this._view.y) / 100 * fh;
          const ox = cx0 - sx * w0 / 2,
            oy = cy0 - sy * h0 / 2;
          const diag0 = Math.hypot(w0, h0);
          const ux = sx * w0 / diag0,
            uy = sy * h0 / diag0;
          move = ev => {
            const proj = (ev.clientX - rect.left - ox) * ux + (ev.clientY - rect.top - oy) * uy;
            const s = clampS(s0 * proj / diag0);
            const d = diag0 * s / s0;
            this._view.s = s;
            this._view.x = (ox + ux * d / 2) / fw * 100 - 50;
            this._view.y = (oy + uy * d / 2) / fh * 100 - 50;
            this._clampView();
            this._applyView();
          };
        } else {
          this.setAttribute('data-panning', '');
          const start = {
            px: e.clientX,
            py: e.clientY,
            x: this._view.x,
            y: this._view.y
          };
          move = ev => {
            this._view.x = start.x + (ev.clientX - start.px) / fw * 100;
            this._view.y = start.y + (ev.clientY - start.py) / fh * 100;
            this._clampView();
            this._applyView();
          };
        }
        const up = () => {
          try {
            this._spill.releasePointerCapture(e.pointerId);
          } catch {}
          this._spill.removeEventListener('pointermove', move);
          this._spill.removeEventListener('pointerup', up);
          this._spill.removeEventListener('pointercancel', up);
          this.removeAttribute('data-panning');
          this._dragUp = null;
        };
        // Stashed so _exitReframe (Escape / outside-click mid-drag) can
        // tear the capture + listeners down synchronously.
        this._dragUp = up;
        this._spill.addEventListener('pointermove', move);
        this._spill.addEventListener('pointerup', up);
        this._spill.addEventListener('pointercancel', up);
      });
      // Wheel zoom stays available inside reframe mode as a trackpad nicety —
      // zooms toward the cursor (offset' = cursor·(1-k) + offset·k).
      this.addEventListener('wheel', e => {
        if (!this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        const r = this.getBoundingClientRect();
        const cx = (e.clientX - r.left) / r.width * 100 - 50;
        const cy = (e.clientY - r.top) / r.height * 100 - 50;
        const prev = this._view.s;
        const next = clampS(prev * Math.pow(1.0015, -e.deltaY));
        if (next === prev) return;
        const k = next / prev;
        this._view.s = next;
        this._view.x = cx * (1 - k) + this._view.x * k;
        this._view.y = cy * (1 - k) + this._view.y * k;
        this._clampView();
        this._applyView();
      }, {
        passive: false
      });
    }
    connectedCallback() {
      // Warn once per page — an id-less slot works for the session but
      // cannot persist, and two id-less slots would share nothing.
      if (!this.id && !ImageSlot._warned) {
        ImageSlot._warned = true;
        console.warn('<image-slot> without an id will not persist its dropped image.');
      }
      this.addEventListener('dragenter', this);
      this.addEventListener('dragover', this);
      this.addEventListener('dragleave', this);
      this.addEventListener('drop', this);
      subs.add(this._subFn);
      // The host may inject window.omelette.writeFile AFTER the first render;
      // re-render on hover so the editable-gated controls reliably appear.
      this.addEventListener('pointerenter', this._subFn);
      // width%/height% in _applyView encode the frame aspect at call time —
      // a host resize (responsive grid, pane divider) would stretch the
      // image until the next _render. Re-render on size change: _render()
      // re-seeds _view from stored before clamp/apply, so a shrink→grow
      // cycle round-trips instead of ratcheting x/y toward the narrower
      // frame's clamp range.
      this._ro = new ResizeObserver(() => this._render());
      this._ro.observe(this);
      load();
      this._render();
    }
    disconnectedCallback() {
      subs.delete(this._subFn);
      this.removeEventListener('pointerenter', this._subFn);
      this.removeEventListener('dragenter', this);
      this.removeEventListener('dragover', this);
      this.removeEventListener('dragleave', this);
      this.removeEventListener('drop', this);
      if (this._ro) {
        this._ro.disconnect();
        this._ro = null;
      }
      // commit=false: a disconnect is not a user intent — committing here
      // would persist whatever half-finished drag a React remount or DOM
      // splice happened to interrupt. Deliberate exits commit on their own
      // paths (Escape/click-out/toggle), and unloads commit via pagehide.
      this._exitReframe(false);
    }
    _enterReframe() {
      if (this.hasAttribute('data-reframe')) return;
      this.setAttribute('data-reframe', '');
      this._signalReframe(true);
      // Best-effort commit when the document unloads mid-reframe (a host
      // navigation racing the enter signal, a manual reload, tab close):
      // the sidecar write rides the host bridge, which outlives this
      // document, so the crop survives even though the mode dies with the
      // DOM. Held on the instance so _exitReframe detaches exactly what
      // was attached.
      this._pagehide = () => {
        this._exitReframe(true);
        flushNow();
      };
      window.addEventListener('pagehide', this._pagehide);
      // Promote spill to the top layer, then keep it pinned over the frame:
      // scroll/resize cover the common cases, and a per-frame rect check
      // catches layout shifts that fire neither (an image above finishing
      // load, streamed DOM pushing the slot down, an ancestor transform
      // change) so the overlay can't detach from the frame.
      try {
        this._spill.showPopover();
      } catch {}
      // After the spill, so the controls stack above it in the top layer.
      try {
        this._ctl.showPopover();
      } catch {}
      this._reposition = () => {
        if (this.hasAttribute('data-reframe')) this._applyView();
      };
      window.addEventListener('scroll', this._reposition, true);
      window.addEventListener('resize', this._reposition);
      this._lastRect = '';
      this._watch = () => {
        if (!this.hasAttribute('data-reframe')) return;
        const r = this.getBoundingClientRect();
        const key = r.left + ',' + r.top + ',' + r.width + ',' + r.height;
        if (key !== this._lastRect) {
          this._lastRect = key;
          this._applyView();
        }
        this._watchId = requestAnimationFrame(this._watch);
      };
      this._watchId = requestAnimationFrame(this._watch);
      this._applyView();
      // Close on click outside (the spill handler stopPropagation()s so
      // in-image drags don't reach this) and on Escape. Listeners are held
      // on the instance so _exitReframe / disconnectedCallback can detach
      // exactly what was attached.
      this._outside = e => {
        if (e.composedPath && e.composedPath().includes(this)) return;
        this._exitReframe(true);
      };
      this._esc = e => {
        if (e.key === 'Escape') this._exitReframe(true);
      };
      document.addEventListener('pointerdown', this._outside, true);
      document.addEventListener('keydown', this._esc, true);
    }
    _exitReframe(commit) {
      if (!this.hasAttribute('data-reframe')) return;
      if (this._dragUp) this._dragUp();
      this.removeAttribute('data-reframe');
      this.removeAttribute('data-panning');
      if (this._outside) document.removeEventListener('pointerdown', this._outside, true);
      if (this._esc) document.removeEventListener('keydown', this._esc, true);
      this._outside = this._esc = null;
      if (this._reposition) {
        window.removeEventListener('scroll', this._reposition, true);
        window.removeEventListener('resize', this._reposition);
        this._reposition = null;
      }
      if (this._watchId) {
        cancelAnimationFrame(this._watchId);
        this._watchId = 0;
      }
      if (this._pagehide) {
        window.removeEventListener('pagehide', this._pagehide);
        this._pagehide = null;
      }
      try {
        this._spill.hidePopover();
      } catch {}
      try {
        this._ctl.hidePopover();
      } catch {}
      this._ctl.style.left = '';
      this._ctl.style.top = '';
      if (commit) this._commitView();
      this._signalReframe(false);
    }

    // Reframe state lives only in this DOM until commit, invisible to the
    // host's dirty signals — announce enter/exit so the host can hold
    // auto-reloads for exactly the gesture (the guest bundle forwards
    // image-slot:reframe to the host as imageSlotReframe). Dispatched on
    // the element (composed, so it escapes shadow roots) while connected;
    // a disconnected exit (disconnectedCallback) falls back to document so
    // the host still hears it.
    _signalReframe(active) {
      const target = this.isConnected ? this : document;
      target.dispatchEvent(new CustomEvent('image-slot:reframe', {
        bubbles: true,
        composed: true,
        detail: {
          active: active,
          id: this.id || null
        }
      }));
    }

    // Public: host's "Import from computer" calls this to run local browse.
    openFilePicker() {
      this._exitReframe(true);
      this._input.click();
    }

    // A src write is a newer intent for this slot's content — the host
    // pick path (setImageSlotImage) or an agent edit — so it must win
    // over any encode still in flight from an earlier drop: left live,
    // that encode lands later, passes _ingest's gen guard, and its
    // setSlot silently overwrites the pick (the stored value shadows
    // src in _render). Bumping _gen kills the encode before its own
    // _swapGen clear runs, so clear the dead claim here too — otherwise
    // _releaseMask (gated on !_swapGen) never fires and the pick's
    // spinner is stranded. src ONLY: the pick sets credit/credit-href
    // in the same task, and clearing _swapGen on those would let the
    // same-src branch unmask the old image mid-encode.
    attributeChangedCallback(name, oldVal, newVal) {
      if (name === 'src' && oldVal !== newVal) {
        this._gen++;
        this._swapGen = 0;
      }
      if (this.shadowRoot) this._render();
    }

    // handleEvent — one listener object for all four drag events keeps the
    // add/remove symmetric and the depth counter correct.
    handleEvent(e) {
      if (e.type === 'dragenter' || e.type === 'dragover') {
        // Without preventDefault the browser never fires 'drop'.
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        if (e.type === 'dragenter') this._depth++;
        this.setAttribute('data-over', '');
      } else if (e.type === 'dragleave') {
        // dragenter/leave fire for every descendant crossing — count depth
        // so hovering the icon inside the empty state doesn't flicker.
        if (--this._depth <= 0) {
          this._depth = 0;
          this.removeAttribute('data-over');
        }
      } else if (e.type === 'drop') {
        e.preventDefault();
        e.stopPropagation();
        this._depth = 0;
        this.removeAttribute('data-over');
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) this._ingest(f);
      }
    }
    async _ingest(file) {
      this._setError(null);
      if (!file || ACCEPT.indexOf(file.type) < 0) {
        this._setError('Drop a PNG, JPEG, WebP, or AVIF image.');
        return;
      }
      // toDataUrl can take hundreds of ms on a large photo. A Clear or a
      // newer drop during that window would be clobbered when this await
      // resumes — bump + capture a generation so stale encodes bail.
      const gen = ++this._gen;
      // Replacing a shown image: surface the swap through the encode too,
      // not just the decode — otherwise the old photo sits there with no
      // feedback while the canvas re-encode runs. An empty slot keeps its
      // placeholder (no spinner) until the encode lands, as before.
      // _swapGen guards the mask against re-renders DURING the encode
      // (pointerenter, ResizeObserver, another slot's store write): the
      // stored value still resolves to the old image there, so _render's
      // same-src clear would otherwise unmask it mid-replace.
      if (this.hasAttribute('data-filled')) {
        this.setAttribute('data-swapping', '');
        this._swapGen = gen;
      }
      try {
        const w = this.clientWidth || this.offsetWidth || MAX_DIM;
        const url = await toDataUrl(file, w);
        if (gen !== this._gen) return;
        // Only exit reframe once the new image is in hand — a rejected type
        // or decode failure leaves the in-progress crop untouched.
        this._exitReframe(false);
        // Clear BEFORE setSlot: its synchronous re-render must see no
        // pending encode, so a byte-identical re-upload (same data URL, no
        // load event coming) still clears the mask via the complete branch.
        this._swapGen = 0;
        const val = {
          u: url,
          s: 1,
          x: 0,
          y: 0
        };
        setSlot(this.id || '', val);
        // Keep a session-local copy for id-less slots so the drop still
        // shows, even though it cannot persist.
        if (!this.id) {
          this._local = val;
          this._render();
        }
      } catch (err) {
        if (gen !== this._gen) return;
        this._swapGen = 0;
        // Reveal the kept old image — unless another replacement (a
        // remote pick's src swap) is still in flight, in which case the
        // mask stays until THAT image settles (its load/error releases).
        this._releaseMask();
        this._setError('Could not read that image.');
        console.warn('<image-slot> ingest failed:', err);
      }
    }
    _setError(msg) {
      if (this._err) {
        this._err.remove();
        this._err = null;
      }
      if (!msg) return;
      const d = document.createElement('div');
      d.className = 'err';
      d.textContent = msg;
      this.shadowRoot.appendChild(d);
      this._err = d;
      setTimeout(() => {
        if (this._err === d) {
          d.remove();
          this._err = null;
        }
      }, 3000);
    }

    // Reframing (pan/resize) is available on any filled slot — the user can
    // always reposition/scale. `fit` only sets the initial baseline (see
    // _geom): contain starts fully-visible, cover starts frame-filling.
    _reframes() {
      return this.hasAttribute('data-filled');
    }

    // The single release discipline for the replacement-in-flight mask
    // (data-swapping). The mask comes off only when BOTH hold:
    //  - no encode is pending (_swapGen) — mid-encode the stored value
    //    still resolves to the old image, so any reveal paints it;
    //  - the frame img has settled on its current src — an unsettled src
    //    means some replacement is still in flight (e.g. a remote pick),
    //    whoever started it, and revealing would paint the previous
    //    frame. The load/error listeners pass settled=true (the event IS
    //    the settlement signal, per spec complete is true by then);
    //    other callers rely on the complete flag (covers loaded AND
    //    failed).
    // Every release path funnels through here EXCEPT _render's empty
    // branch (the img is being cleared — nothing will ever settle).
    _releaseMask(settled) {
      if (!this._swapGen && !this._loadPending && (settled || this._img.complete)) {
        this.removeAttribute('data-swapping');
      }
    }

    // Baseline geometry, shared by clamp/apply/resize. `base` is the scale at
    // view-scale s=1: cover = fill the frame (overflow on the looser axis),
    // contain = fit fully inside (letterboxed). Zooming a contain image past
    // s where it overflows naturally becomes a crop. Null until the img has
    // loaded (naturalWidth is 0 before that) or when the slot has no layout
    // box — ResizeObserver fires with a 0×0 rect under display:none, and
    // clamping against a degenerate 1×1 frame would silently pull the stored
    // pan toward zero.
    _geom() {
      const iw = this._img.naturalWidth,
        ih = this._img.naturalHeight;
      const fw = this.clientWidth,
        fh = this.clientHeight;
      if (!iw || !ih || !fw || !fh) return null;
      const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
      const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
      return {
        iw,
        ih,
        fw,
        fh,
        base
      };
    }
    _clampView() {
      // Pan range on each axis is half the overflow past the frame edge.
      const g = this._geom();
      if (!g) return;
      const mx = Math.max(0, (g.iw * g.base * this._view.s / g.fw - 1) * 50);
      const my = Math.max(0, (g.ih * g.base * this._view.s / g.fh - 1) * 50);
      this._view.x = Math.max(-mx, Math.min(mx, this._view.x));
      this._view.y = Math.max(-my, Math.min(my, this._view.y));
    }
    _applyView() {
      const g = this._geom();
      // Top-layer controls: pin to the frame's top-right in viewport px
      // (the same 8px inset as the in-frame layout; unscaled — top-layer UI
      // reads as chrome, not page content). BEFORE the geometry branch:
      // placement needs only the frame rect, and a not-yet-loaded or broken
      // src must not leave the promoted strip floating unpositioned. Gated
      // on the popover actually being open: without the Popover API,
      // showPopover() threw (swallowed in _enterReframe), .ctl stays in
      // its in-frame absolute layout, and viewport-px coordinates would
      // shove it off-frame — and matches(':popover-open') itself throws
      // there (unknown pseudo-class), hence the try/catch.
      if (this.hasAttribute('data-reframe')) {
        let onTop = false;
        try {
          onTop = this._ctl.matches(':popover-open');
        } catch {}
        if (onTop) {
          const r = this.getBoundingClientRect();
          this._ctl.style.left = r.right - 8 + 'px';
          this._ctl.style.top = r.top + 8 + 'px';
        }
      }
      if (!g) {
        // Dimensions not known yet (before img load) — centered fit so there
        // is no flash of an unpositioned image before the geometry lands.
        const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
        this._img.style.width = '100%';
        this._img.style.height = '100%';
        this._img.style.left = '50%';
        this._img.style.top = '50%';
        this._img.style.objectFit = contain ? 'contain' : 'cover';
        return;
      }
      // Baseline (cover-fill or contain-fit) × view scale. Width/height and
      // left/top are all frame-% — depends only on the frame aspect ratio, so
      // a responsive resize keeps the same crop. The spill layer mirrors the
      // same box so its corners = image corners.
      const k = g.base * this._view.s;
      const w = g.iw * k / g.fw * 100 + '%';
      const h = g.ih * k / g.fh * 100 + '%';
      const l = 50 + this._view.x + '%';
      const t = 50 + this._view.y + '%';
      this._img.style.width = w;
      this._img.style.height = h;
      this._img.style.left = l;
      this._img.style.top = t;
      this._img.style.objectFit = '';
      if (this.hasAttribute('data-reframe')) {
        // Top-layer spill: position in viewport px over the frame. The top
        // layer escapes ancestor transforms entirely, so EVERY term must be
        // in viewport units: getBoundingClientRect gives the frame's scaled
        // origin AND size, and the rect/layout ratio rescales the ghost —
        // sizing from layout px alone renders it 1/scale too large under a
        // scaled deck slide. Inner ghost + handles stay box-relative.
        const r = this.getBoundingClientRect();
        const sx = g.fw ? r.width / g.fw : 1;
        const sy = g.fh ? r.height / g.fh : 1;
        this._spill.style.width = g.iw * k * sx + 'px';
        this._spill.style.height = g.ih * k * sy + 'px';
        this._spill.style.left = r.left + (50 + this._view.x) / 100 * r.width + 'px';
        this._spill.style.top = r.top + (50 + this._view.y) / 100 * r.height + 'px';
      }
    }
    _commitView() {
      const v = {
        s: this._view.s,
        x: this._view.x,
        y: this._view.y
      };
      if (this._userUrl) v.u = this._userUrl;
      // Framing-only (no u) persists too so an author-src slot remembers its
      // crop; clearing the sidecar still falls through to src=.
      if (this.id) setSlot(this.id, v);else {
        this._local = v;
      }
    }
    _render() {
      // Shape / mask. Presets use border-radius so the dashed ring can
      // follow the rounded outline; clip-path is only applied for an
      // explicit `mask` (the ring is hidden there since a rectangle
      // dashed border chopped by an arbitrary polygon looks broken).
      const mask = this.getAttribute('mask');
      const shape = (this.getAttribute('shape') || 'rounded').toLowerCase();
      let radius = '';
      if (shape === 'circle') radius = '50%';else if (shape === 'pill') radius = '9999px';else if (shape === 'rounded') {
        const n = parseFloat(this.getAttribute('radius'));
        radius = (Number.isFinite(n) ? n : 12) + 'px';
      }
      this._frame.style.borderRadius = mask ? '' : radius;
      this._frame.style.clipPath = mask || '';
      this._ring.style.borderRadius = mask ? '' : radius;
      this._ring.style.display = mask ? 'none' : '';

      // Controls and reframe entry gate on this so share links stay read-only.
      const editable = !!(window.omelette && window.omelette.writeFile);
      this.toggleAttribute('data-editable', editable);
      this._sub.style.display = editable ? '' : 'none';

      // Content. The sidecar is also writable by the agent's write_file
      // tool, so its value isn't guaranteed canvas-originated — only accept
      // data:image/ URLs from it. The `src` attribute is author-controlled
      // (Claude wrote it into the HTML) so it passes through unchanged.
      let stored = this.id ? getSlot(this.id) : this._local;
      if (stored && stored.u && !/^data:image\//i.test(stored.u)) stored = null;
      const srcAttr = this.getAttribute('src') || '';
      this._userUrl = stored && stored.u || null;
      const url = this._userUrl || srcAttr;
      // Don't clobber an in-flight reframe with a store-triggered re-render.
      if (!this.hasAttribute('data-reframe')) {
        this._view = {
          s: stored && Number.isFinite(stored.s) ? clampS(stored.s) : 1,
          x: stored && Number.isFinite(stored.x) ? stored.x : 0,
          y: stored && Number.isFinite(stored.y) ? stored.y : 0
        };
      }
      this._cap.textContent = this.getAttribute('placeholder') || 'Drop an image';
      // Toggle via style.display — the [hidden] attribute alone loses to
      // the display:flex / display:block rules in the stylesheet above.
      // An Unsplash src with no credit attribute must NOT render — showing
      // the photo uncredited is the Unsplash-terms violation itself. The
      // error tile replaces the photo until the credit is written. A
      // user-dropped image is the user's own content and always renders.
      // Trimmed: credit is agent/user-editable content, and a whitespace-
      // only value must count as missing — otherwise it would suppress the
      // error tile AND render an empty credit box (no text, no links),
      // exactly the unattributed state this gate exists to prevent.
      const credit = (this.getAttribute('credit') || '').trim();
      const attrError = !!(!credit && !this._userUrl && srcAttr && isUnsplashHost(srcAttr));
      this.toggleAttribute('data-attribution-error', attrError);
      if (url && !attrError) {
        const prev = this._img.getAttribute('src');
        if (prev !== url) {
          // Replacing an already-shown image: mark the swap BEFORE setting
          // src so the stale frame is never revealed (see the data-swapping
          // stylesheet rules). First fill (prev empty) keeps the existing
          // placeholder-until-load behavior — no spinner. _hidShowing
          // covers the pick path's transient attribution-error wipe: prev
          // is gone, but an image WAS showing, so this is a replacement.
          if (prev || this._hidShowing) this.setAttribute('data-swapping', '');
          // Mark the swap BEFORE assigning src: complete keeps reporting
          // the old settled request until the browser's
          // update-the-image-data microtask runs, so same-task re-renders
          // (the pick path's credit/credit-href setAttributes) need this
          // flag, not complete, to know a load is in flight.
          this._loadPending = true;
          this._img.src = url;
          this._ghost.src = url;
        } else {
          // Same-src re-render — release if settled, so an ingest-set
          // spinner can't stick after a byte-identical re-upload (same
          // data URL, no further load event ever fires).
          this._releaseMask();
        }
        this._hidShowing = false;
        this._img.style.display = 'block';
        this._empty.style.display = 'none';
        this.setAttribute('data-filled', '');
        this._clampView();
        this._applyView();
      } else {
        this.removeAttribute('data-swapping');
        // The src is being removed — no load/error will ever fire for it.
        this._loadPending = false;
        // A transient attribution-error wipe of a showing image happens on
        // the pick path: the host sets src one setAttribute before credit,
        // so render N hides the old image (attrError) and render N+1
        // restores a URL. Remember the wipe so that restore renders as a
        // replacement (spinner), not a first fill (blank frame).
        this._hidShowing = attrError && !!this._img.getAttribute('src');
        this._img.style.display = 'none';
        this._img.removeAttribute('src');
        this._ghost.removeAttribute('src');
        // The error tile owns the blocked-photo state; .empty stays for
        // the genuinely-empty slot.
        this._empty.style.display = attrError ? 'none' : 'flex';
        this.removeAttribute('data-filled');
      }

      // Credit belongs to the author src, so a user drop hides it.
      // textContent + the http(s)-only funnel keep external strings inert.
      const showCredit = !!(url && credit && !this._userUrl && !attrError);
      this._credit.textContent = '';
      if (showCredit) {
        // Validate once (resolved against the document, http(s) only),
        // then append the terms-required utm referral params to links
        // that point back at unsplash.com.
        let href = '';
        const rawHref = this.getAttribute('credit-href') || '';
        if (rawHref) {
          try {
            const u = new URL(rawHref, document.baseURI);
            if (u.protocol === 'http:' || u.protocol === 'https:') {
              href = withReferral(u.href);
            }
          } catch {}
        }
        const mkLink = (text, linkHref) => {
          const a = document.createElement('a');
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'noopener noreferrer');
          a.setAttribute('href', linkHref);
          a.textContent = text;
          return a;
        };
        // Unsplash's prescribed credit is TWO links — the photographer's
        // name to their profile (credit-href) and 'Unsplash' to the
        // homepage. Render that split whenever the text has the canonical
        // shape; other text keeps the legacy single-link rendering.
        const m = /^Photo by (.+) on Unsplash$/.exec(credit);
        if (m) {
          this._credit.appendChild(document.createTextNode('Photo by '));
          this._credit.appendChild(href ? mkLink(m[1], href) : document.createTextNode(m[1]));
          this._credit.appendChild(document.createTextNode(' on '));
          this._credit.appendChild(mkLink('Unsplash', UNSPLASH_HOMEPAGE_HREF));
        } else if (href) {
          this._credit.appendChild(mkLink(credit, href));
        } else {
          this._credit.textContent = credit;
        }
      }
      this.toggleAttribute('data-credit', showCredit);
    }
  }
  if (!customElements.get('image-slot')) {
    customElements.define('image-slot', ImageSlot);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "design_handoff_pumallen_os/ui_kit/image-slot.js", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/AnalysisScreen.jsx
try { (() => {
const {
  TopBar,
  BottomNav,
  Chip,
  TimeframeCard,
  VerdictBanner,
  Button,
  LoadingDots,
  Badge
} = window.PumallenOSDesignSystem_ac653c;
const TF_ORDER = ['MO', 'W', 'D', 'H4', 'H1'];
const TF_META = {
  MO: {
    label: 'Monthly',
    role: 'Mission Timeframe · Supreme Authority'
  },
  W: {
    label: 'Weekly',
    role: 'Strategic Planning · Refine the Mission'
  },
  D: {
    label: 'Daily',
    role: 'Permission Timeframe · Confirm Direction'
  },
  H4: {
    label: 'H4',
    role: 'Engineering · Build the Execution Environment'
  },
  H1: {
    label: 'H1',
    role: 'Execution Engine · Final Trigger'
  }
};
const MOCK_RESULT = {};
const AN_CHAINS = ['BA', 'LM', 'INF', 'CON', 'GRO', 'CB'];
const AN_CORE = ['BA', 'LM', 'INF'];
const AN_SUPPORT = ['CON', 'GRO', 'CB'];
const AN_SCORE = {
  Strong: 1,
  Mixed: 0,
  Weak: -1
};
function computeEconomyCandidate(economy) {
  if (!economy || !economy.data) return null;
  const month = economy.reportingMonth || 'Jul';
  const results = Object.keys(economy.data).map(c => {
    const cd = economy.data[c];
    let total = 0;
    const complete = {};
    AN_CHAINS.forEach(id => {
      total += AN_SCORE[cd[id].thesis];
      const anchors = cd[id].anchors || [];
      const monthAnchors = anchors.filter(a => a.date && a.date.slice(0, 3) === month);
      const answered = monthAnchors.filter(a => a.verdict);
      complete[id] = monthAnchors.length > 0 && answered.length === monthAnchors.length;
    });
    const eligible = AN_CORE.every(id => complete[id]) && AN_SUPPORT.some(id => complete[id]);
    return {
      c,
      total,
      eligible
    };
  }).filter(r => r.eligible).sort((a, b) => b.total - a.total);
  if (results.length < 2) return {
    status: 'insufficient',
    count: results.length
  };
  const gap = results[0].total - results[results.length - 1].total;
  return {
    status: gap >= 3 ? 'candidate' : 'no-trade',
    gap,
    strongest: results[0].c,
    weakest: results[results.length - 1].c
  };
}
function buildPrompts(pair) {
  return {
    MO: 'Analyze this MONTHLY ' + pair + ' chart per PMTS rules. Identify: 1) Long-term bias BULLISH/BEARISH/RANGING 2) Major liquidity objective 3) Key structural levels 4) Premium/discount areas. This is the mission timeframe — no entries. Conclude with a line starting "MONTHLY MISSION:".',
    W: 'Analyze this WEEKLY ' + pair + ' chart. Monthly mission confirmed above. Identify bias, liquidity zones, structure, and whether this plan aligns with the Monthly mission. Conclude with a line starting "WEEKLY PLAN:" and state ALIGNED WITH MONTHLY: YES or NO.',
    D: 'Analyze this DAILY ' + pair + ' chart. Higher timeframes aligned. Check reaction from the weekly zone and BOS in the weekly direction. Conclude with a line starting "DAILY PERMISSION:" GRANTED or DENIED.',
    H4: 'Analyze this H4 ' + pair + ' chart. Higher timeframes aligned. Identify the Level (L1 pullback / L2 expansion / L3 distribution), current leg, and whether structure still serves the Monthly mission. Conclude with a line starting "H4 STRUCTURE:" ALIGNED or NOT ALIGNED.',
    H1: 'Analyze this H1 ' + pair + ' chart. All higher timeframes aligned. Check for a liquidity sweep, BOS/CHoCH after the sweep, and a clean pullback entry. Conclude with a line starting "H1 ENTRY SIGNAL:" CONFIRMED or NOT CONFIRMED, and EXECUTE or STAND DOWN.'
  };
}
function AnalysisScreen(props) {
  const {
    analysis,
    setAnalysis,
    checklist,
    navigate,
    pair,
    economy
  } = props;
  const {
    states,
    results,
    verdict
  } = analysis;
  const AF_PROMPTS = buildPrompts(pair || 'EURUSD');
  const economyCandidate = computeEconomyCandidate(economy) || {
    status: 'insufficient'
  };
  const checklistDone = checklist.every(Boolean);
  const checklistCount = checklist.filter(Boolean).length;
  const slotRefs = React.useRef({});
  function patch(fn) {
    setAnalysis(a => fn(a));
  }
  async function beginAnalysis(tf) {
    patch(a => ({
      ...a,
      states: {
        ...a.states,
        [tf]: 'analyzing'
      }
    }));
    try {
      const slotEl = slotRefs.current[tf];
      const imgEl = slotEl && slotEl.shadowRoot && slotEl.shadowRoot.querySelector('.frame img');
      const dataUrl = imgEl && imgEl.src;
      if (!dataUrl || dataUrl.indexOf('data:') !== 0) throw new Error('No chart image found');
      const mediaType = dataUrl.slice(5, dataUrl.indexOf(';'));
      const base64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
      const text = await window.claude.complete({
        messages: [{
          role: 'user',
          content: [{
            type: 'image',
            source: {
              type: 'base64',
              media_type: mediaType,
              data: base64
            }
          }, {
            type: 'text',
            text: AF_PROMPTS[tf]
          }]
        }]
      });
      patch(a => ({
        ...a,
        results: {
          ...a.results,
          [tf]: text
        },
        states: {
          ...a.states,
          [tf]: 'ready'
        }
      }));
    } catch (err) {
      patch(a => ({
        ...a,
        results: {
          ...a.results,
          [tf]: '⚠ ' + (err && err.message ? err.message : 'Analysis failed. Try again.')
        },
        states: {
          ...a.states,
          [tf]: 'ready'
        }
      }));
    }
  }
  React.useEffect(() => {
    const observers = [];
    TF_ORDER.forEach(tf => {
      const el = slotRefs.current[tf];
      if (!el || states[tf] !== 'active') return;
      const obs = new MutationObserver(() => {
        if (el.hasAttribute('data-filled')) beginAnalysis(tf);
      });
      obs.observe(el, {
        attributes: true,
        attributeFilter: ['data-filled']
      });
      observers.push(obs);
    });
    return () => observers.forEach(o => o.disconnect());
  }, [states]);
  function grant(tf, ok) {
    const idx = TF_ORDER.indexOf(tf);
    if (!ok) {
      patch(a => ({
        ...a,
        states: {
          ...a.states,
          [tf]: 'rejected'
        },
        verdict: 'stand-down'
      }));
      return;
    }
    const next = {
      ...states,
      [tf]: 'aligned'
    };
    if (TF_ORDER[idx + 1]) next[TF_ORDER[idx + 1]] = 'active';
    if (tf === 'H1' && !checklistDone) return;
    patch(a => ({
      ...a,
      states: next,
      verdict: tf === 'H1' ? 'execute' : a.verdict
    }));
  }
  function reset() {
    setAnalysis({
      states: {
        MO: 'active',
        W: 'locked',
        D: 'locked',
        H4: 'locked',
        H1: 'locked'
      },
      results: {},
      verdict: null
    });
  }
  const cardState = tf => ['aligned', 'rejected'].includes(states[tf]) ? states[tf] : states[tf] === 'locked' ? 'locked' : 'active';
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 92,
      left: 0,
      right: 0,
      bottom: 64,
      overflowY: 'auto',
      padding: '12px 14px 20px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      padding: '10px 14px',
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-default)',
      borderRadius: 10,
      fontSize: 13,
      fontWeight: 700,
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-hi)'
    }
  }, "SYSTEM READY"), /*#__PURE__*/React.createElement(Badge, {
    tone: economyCandidate.status === 'candidate' ? 'green' : economyCandidate.status === 'no-trade' ? 'red' : 'muted'
  }, economyCandidate.status === 'candidate' ? '🌐 ' + economyCandidate.strongest + '/' + economyCandidate.weakest : economyCandidate.status === 'no-trade' ? '🌐 GAP<3' : '🌐 —'), /*#__PURE__*/React.createElement(Badge, {
    tone: checklistDone ? 'green' : 'muted'
  }, "CHECKLIST ", checklistCount, "/9")), TF_ORDER.map((tf, i) => /*#__PURE__*/React.createElement(React.Fragment, {
    key: tf
  }, /*#__PURE__*/React.createElement(TimeframeCard, {
    code: tf,
    label: TF_META[tf].label,
    role: TF_META[tf].role,
    state: cardState(tf),
    showUpload: false
  }, states[tf] === 'active' && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    },
    ref: el => {
      if (el) slotRefs.current[tf] = el.querySelector('image-slot');
    }
  }, /*#__PURE__*/React.createElement("image-slot", {
    id: 'chart-' + tf,
    shape: "rounded",
    radius: "10",
    placeholder: 'Drop ' + TF_META[tf].label + ' chart',
    style: {
      width: '100%',
      height: 90,
      display: 'block'
    }
  })), states[tf] === 'analyzing' && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement(LoadingDots, null, "Analyzing ", TF_META[tf].label, "...")), states[tf] === 'ready' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8,
      marginTop: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 12,
      background: 'rgba(0,0,0,.4)',
      borderRadius: 10,
      border: '1px solid var(--border-default)',
      fontSize: 12,
      lineHeight: 1.75,
      color: 'var(--text-dim)',
      whiteSpace: 'pre-wrap'
    }
  }, results[tf]), tf === 'H1' && !checklistDone && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--accent-danger)',
      padding: '8px 10px',
      background: 'var(--surface-red-tint)',
      borderRadius: 8,
      border: '1px solid var(--border-red)'
    }
  }, "\u26A0\uFE0F Complete the 9-condition checklist before execution is allowed."), /*#__PURE__*/React.createElement(Button, {
    variant: "success",
    size: "sm",
    disabled: tf === 'H1' && !checklistDone,
    onClick: () => grant(tf, true)
  }, "\u2705 Confirmed \u2014 Unlock Next"), /*#__PURE__*/React.createElement(Button, {
    variant: "danger",
    size: "sm",
    onClick: () => grant(tf, false)
  }, "\uD83D\uDEAB Stand Down"))), i < TF_ORDER.length - 1 && /*#__PURE__*/React.createElement("div", {
    style: {
      height: 16,
      display: 'flex',
      alignItems: 'center',
      justifyContent: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 1,
      height: '100%',
      background: 'var(--border-default)'
    }
  })))), verdict && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 12
    }
  }, /*#__PURE__*/React.createElement(VerdictBanner, {
    verdict: verdict,
    title: verdict === 'execute' ? 'Execute' : 'Stand Down',
    subtitle: verdict === 'execute' ? 'All 9 conditions met. H1 entry clear.' : 'A required condition failed upstream.'
  }), /*#__PURE__*/React.createElement(Button, {
    variant: "gold",
    style: {
      width: '100%',
      marginTop: 10
    },
    onClick: () => navigate('chat')
  }, "\uD83D\uDCAC Continue in AI Chat")), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    style: {
      width: '100%',
      marginTop: 16
    },
    onClick: reset
  }, "\u21BA Reset Analysis"));
}
window.AnalysisScreen = AnalysisScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/AnalysisScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/App.jsx
try { (() => {
const {
  TopBar,
  BottomNav,
  Chip
} = window.PumallenOSDesignSystem_ac653c;
const NAV_ITEMS = [{
  id: 'analysis',
  icon: '🔬',
  label: 'Analysis'
}, {
  id: 'chat',
  icon: '💬',
  label: 'AI Chat'
}, {
  id: 'checklist',
  icon: '✅',
  label: 'Checks'
}, {
  id: 'calc',
  icon: '🧮',
  label: 'Calc'
}, {
  id: 'journal',
  icon: '📒',
  label: 'Journal'
}, {
  id: 'more',
  icon: '⋯',
  label: 'More'
}];
const SCREENS = {
  analysis: window.AnalysisScreen,
  chat: window.ChatScreen,
  checklist: window.ChecklistScreen,
  calc: window.CalcScreen,
  journal: window.JournalScreen,
  settings: window.SettingsScreen,
  stats: window.StatsScreen,
  planner: window.PlannerScreen,
  narrative: window.NarrativeScreen,
  history: window.HistoryScreen,
  economy: window.EconomyScreen,
  brief: window.BriefScreen
};
const DEFAULT_STATE = {
  analysis: {
    states: {
      MO: 'active',
      W: 'locked',
      D: 'locked',
      H4: 'locked',
      H1: 'locked'
    },
    results: {},
    verdict: null
  },
  checklist: Array(9).fill(false),
  chat: [{
    role: 'assistant',
    content: 'PMTS chain of authority loaded. Ask about the current analysis or the 9 conditions.'
  }, {
    role: 'user',
    content: 'why did daily stand down?'
  }, {
    role: 'assistant',
    content: 'Daily stood down because the weekly plan conflicted with the monthly mission — no permission was granted, so H4/H1 stay locked until it clears.'
  }],
  journal: [{
    dir: 'Long',
    date: '2026-07-28',
    entry: '1.0842',
    sl: '1.0810',
    tp: '1.0910',
    result: 'Win'
  }, {
    dir: 'Short',
    date: '2026-07-22',
    entry: '1.0921',
    sl: '1.0955',
    tp: '1.0860',
    result: 'Win'
  }, {
    dir: 'Long',
    date: '2026-07-15',
    entry: '1.0788',
    sl: '1.0760',
    tp: '1.0840',
    result: 'Loss'
  }],
  narrative: [{
    date: '2026-08-03',
    body: 'EURUSD holding monthly discount, weekly reaction from demand. Watching for daily BOS to confirm.'
  }],
  pair: 'EURUSD',
  economy: {
    reportingMonth: 'Jul',
    data: {
      USD: {
        BA: {
          question: 'Is business activity expanding or contracting?',
          thesis: 'Strong',
          anchors: [{
            date: 'Jul 1',
            impact: 'Red',
            news: 'ISM Manufacturing PMI',
            forecast: '',
            previous: '',
            actual: '53.3',
            verdict: 'Supports Thesis'
          }, {
            date: 'Jul 6',
            impact: 'Red',
            news: 'ISM Services PMI',
            forecast: '',
            previous: '',
            actual: '54.0',
            verdict: 'Supports Thesis'
          }, {
            date: 'Aug 3',
            impact: 'Red',
            news: 'ISM Manufacturing PMI',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 5',
            impact: 'Orange',
            news: 'ISM Services PMI',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        },
        LM: {
          question: 'Is the labour market strengthening or weakening?',
          thesis: 'Mixed',
          anchors: [{
            date: 'Jul 1',
            impact: 'Orange',
            news: 'ADP Non-Farm Employment Change',
            forecast: '',
            previous: '',
            actual: '98K',
            verdict: 'Rejects Thesis'
          }, {
            date: 'Jul 2',
            impact: 'Red',
            news: 'Average Hourly Earnings m/m',
            forecast: '0.3%',
            previous: '0.3%',
            actual: '0.3%',
            verdict: 'Supports Thesis'
          }, {
            date: 'Jul 2',
            impact: 'Red',
            news: 'Non-Farm Employment Change',
            forecast: '110K',
            previous: '172K',
            actual: '57K',
            verdict: 'Rejects Thesis'
          }, {
            date: 'Jul 2',
            impact: 'Red',
            news: 'Unemployment Rate',
            forecast: '4.3%',
            previous: '4.3%',
            actual: '4.2%',
            verdict: 'Supports Thesis'
          }, {
            date: 'Aug 5',
            impact: 'Orange',
            news: 'ADP Non-Farm Employment Change',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 7',
            impact: 'Red',
            news: 'Average Hourly Earnings m/m',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 7',
            impact: 'Red',
            news: 'Non-Farm Employment Change',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 7',
            impact: 'Red',
            news: 'Unemployment Rate',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        },
        INF: {
          question: 'Is inflation accelerating or cooling?',
          thesis: 'Weak',
          anchors: [{
            date: 'Jul 14',
            impact: 'Red',
            news: 'Core CPI m/m',
            forecast: '0.2%',
            previous: '0.2%',
            actual: '0.0%',
            verdict: 'Rejects Thesis'
          }, {
            date: 'Jul 14',
            impact: 'Red',
            news: 'Core CPI y/y',
            forecast: '2.8%',
            previous: '2.9%',
            actual: '2.6%',
            verdict: 'Rejects Thesis'
          }, {
            date: 'Jul 14',
            impact: 'Red',
            news: 'CPI m/m',
            forecast: '-0.1%',
            previous: '0.5%',
            actual: '-0.4%',
            verdict: 'Rejects Thesis'
          }, {
            date: 'Jul 14',
            impact: 'Red',
            news: 'CPI y/y',
            forecast: '3.8%',
            previous: '4.2%',
            actual: '3.5%',
            verdict: 'Rejects Thesis'
          }, {
            date: 'Jul 30',
            impact: 'Red',
            news: 'Core PCE Price Index m/m',
            forecast: '0.2%',
            previous: '0.3%',
            actual: '0.1%',
            verdict: 'Rejects Thesis'
          }, {
            date: 'Aug 12',
            impact: 'Red',
            news: 'Core CPI m/m',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 12',
            impact: 'Red',
            news: 'Core CPI y/y',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 12',
            impact: 'Red',
            news: 'CPI m/m',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 12',
            impact: 'Red',
            news: 'CPI y/y',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 26',
            impact: 'Red',
            news: 'Core PCE Price Index m/m',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        },
        CON: {
          question: 'Is the consumer becoming stronger or weaker?',
          thesis: 'Mixed',
          anchors: [{
            date: 'Jul 16',
            impact: 'Orange',
            news: 'Core Retail Sales m/m',
            forecast: '0.0%',
            previous: '1.0%',
            actual: '-0.2%',
            verdict: 'Rejects Thesis'
          }, {
            date: 'Jul 16',
            impact: 'Orange',
            news: 'Retail Sales m/m',
            forecast: '0.2%',
            previous: '1.0%',
            actual: '0.2%',
            verdict: 'Supports Thesis'
          }, {
            date: 'Jul 28',
            impact: 'Orange',
            news: 'CB Consumer Confidence',
            forecast: '',
            previous: '',
            actual: '90.8',
            verdict: 'Rejects Thesis'
          }, {
            date: 'Aug 25',
            impact: 'Orange',
            news: 'CB Consumer Confidence',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        },
        GRO: {
          question: 'Is economic growth improving or slowing?',
          thesis: 'Weak',
          anchors: [{
            date: 'Jul 30',
            impact: 'Red',
            news: 'Advance GDP q/q',
            forecast: '2.1%',
            previous: '2.1%',
            actual: '1.5%',
            verdict: 'Rejects Thesis'
          }, {
            date: 'Aug 26',
            impact: 'Red',
            news: 'Prelim GDP q/q',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        },
        CB: {
          question: 'Based on the completed economic chains, is monetary policy likely to become more hawkish, more dovish, or remain unchanged?',
          thesis: 'Mixed',
          anchors: [{
            date: 'Jul 29',
            impact: 'Red',
            news: 'Federal Funds Rate',
            forecast: '3.75%',
            previous: '3.75%',
            actual: '3.75%',
            verdict: 'Supports Thesis'
          }]
        }
      },
      EUR: {
        BA: {
          question: 'Is business activity expanding or contracting?',
          thesis: 'Mixed',
          anchors: [{
            date: 'Aug 21',
            impact: 'Orange',
            news: 'French Flash Manufacturing PMI',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 21',
            impact: 'Orange',
            news: 'French Flash Services PMI',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 21',
            impact: 'Orange',
            news: 'German Flash Manufacturing PMI',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 21',
            impact: 'Orange',
            news: 'German Flash Services PMI',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        },
        LM: {
          question: 'Is the labour market strengthening or weakening?',
          thesis: 'Mixed',
          anchors: []
        },
        INF: {
          question: 'Is inflation accelerating or cooling?',
          thesis: 'Mixed',
          anchors: []
        },
        CON: {
          question: 'Is the consumer becoming stronger or weaker?',
          thesis: 'Mixed',
          anchors: []
        },
        GRO: {
          question: 'Is economic growth improving or slowing?',
          thesis: 'Mixed',
          anchors: []
        },
        CB: {
          question: 'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?',
          thesis: 'Mixed',
          anchors: []
        }
      },
      GBP: {
        BA: {
          question: 'Is business activity expanding or contracting?',
          thesis: 'Mixed',
          anchors: [{
            date: 'Jul 24',
            impact: 'Orange',
            news: 'Flash Manufacturing PMI',
            forecast: '',
            previous: '',
            actual: '52.8',
            verdict: ''
          }, {
            date: 'Jul 24',
            impact: 'Orange',
            news: 'Flash Services PMI',
            forecast: '',
            previous: '',
            actual: '51.8',
            verdict: ''
          }, {
            date: 'Aug 21',
            impact: 'Orange',
            news: 'Flash Manufacturing PMI',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }, {
            date: 'Aug 21',
            impact: 'Orange',
            news: 'Flash Services PMI',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        },
        LM: {
          question: 'Is the labour market strengthening or weakening?',
          thesis: 'Mixed',
          anchors: []
        },
        INF: {
          question: 'Is inflation accelerating or cooling?',
          thesis: 'Mixed',
          anchors: []
        },
        CON: {
          question: 'Is the consumer becoming stronger or weaker?',
          thesis: 'Mixed',
          anchors: []
        },
        GRO: {
          question: 'Is economic growth improving or slowing?',
          thesis: 'Mixed',
          anchors: []
        },
        CB: {
          question: 'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?',
          thesis: 'Mixed',
          anchors: []
        }
      },
      JPY: {
        BA: {
          question: 'Is business activity expanding or contracting?',
          thesis: 'Mixed',
          anchors: []
        },
        LM: {
          question: 'Is the labour market strengthening or weakening?',
          thesis: 'Mixed',
          anchors: []
        },
        INF: {
          question: 'Is inflation accelerating or cooling?',
          thesis: 'Mixed',
          anchors: []
        },
        CON: {
          question: 'Is the consumer becoming stronger or weaker?',
          thesis: 'Mixed',
          anchors: []
        },
        GRO: {
          question: 'Is economic growth improving or slowing?',
          thesis: 'Mixed',
          anchors: []
        },
        CB: {
          question: 'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?',
          thesis: 'Mixed',
          anchors: [{
            date: 'Jul 31',
            impact: 'Red',
            news: 'BOJ Policy Rate',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        }
      },
      AUD: {
        BA: {
          question: 'Is business activity expanding or contracting?',
          thesis: 'Mixed',
          anchors: []
        },
        LM: {
          question: 'Is the labour market strengthening or weakening?',
          thesis: 'Strong',
          anchors: [{
            date: 'Jul 17',
            impact: 'Red',
            news: 'Employment Change',
            forecast: '',
            previous: '',
            actual: '',
            verdict: 'Supports Thesis'
          }]
        },
        INF: {
          question: 'Is inflation accelerating or cooling?',
          thesis: 'Weak',
          anchors: [{
            date: 'Jul 30',
            impact: 'Red',
            news: 'CPI q/q',
            forecast: '',
            previous: '',
            actual: '',
            verdict: 'Rejects Thesis'
          }]
        },
        CON: {
          question: 'Is the consumer becoming stronger or weaker?',
          thesis: 'Mixed',
          anchors: []
        },
        GRO: {
          question: 'Is economic growth improving or slowing?',
          thesis: 'Mixed',
          anchors: []
        },
        CB: {
          question: 'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?',
          thesis: 'Mixed',
          anchors: []
        }
      },
      CAD: {
        BA: {
          question: 'Is business activity expanding or contracting?',
          thesis: 'Mixed',
          anchors: [{
            date: 'Jul 7',
            impact: 'Orange',
            news: 'Ivey PMI',
            forecast: '',
            previous: '',
            actual: '56.2',
            verdict: ''
          }, {
            date: 'Aug 7',
            impact: 'Orange',
            news: 'Ivey PMI',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        },
        LM: {
          question: 'Is the labour market strengthening or weakening?',
          thesis: 'Mixed',
          anchors: []
        },
        INF: {
          question: 'Is inflation accelerating or cooling?',
          thesis: 'Mixed',
          anchors: []
        },
        CON: {
          question: 'Is the consumer becoming stronger or weaker?',
          thesis: 'Mixed',
          anchors: []
        },
        GRO: {
          question: 'Is economic growth improving or slowing?',
          thesis: 'Mixed',
          anchors: []
        },
        CB: {
          question: 'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?',
          thesis: 'Mixed',
          anchors: []
        }
      },
      CHF: {
        BA: {
          question: 'Is business activity expanding or contracting?',
          thesis: 'Mixed',
          anchors: []
        },
        LM: {
          question: 'Is the labour market strengthening or weakening?',
          thesis: 'Mixed',
          anchors: []
        },
        INF: {
          question: 'Is inflation accelerating or cooling?',
          thesis: 'Mixed',
          anchors: [{
            date: 'Jul 3',
            impact: 'Orange',
            news: 'CPI m/m',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        },
        CON: {
          question: 'Is the consumer becoming stronger or weaker?',
          thesis: 'Mixed',
          anchors: []
        },
        GRO: {
          question: 'Is economic growth improving or slowing?',
          thesis: 'Mixed',
          anchors: []
        },
        CB: {
          question: 'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?',
          thesis: 'Mixed',
          anchors: []
        }
      },
      NZD: {
        BA: {
          question: 'Is business activity expanding or contracting?',
          thesis: 'Mixed',
          anchors: []
        },
        LM: {
          question: 'Is the labour market strengthening or weakening?',
          thesis: 'Mixed',
          anchors: []
        },
        INF: {
          question: 'Is inflation accelerating or cooling?',
          thesis: 'Mixed',
          anchors: [{
            date: 'Jul 21',
            impact: 'Orange',
            news: 'CPI q/q',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        },
        CON: {
          question: 'Is the consumer becoming stronger or weaker?',
          thesis: 'Mixed',
          anchors: []
        },
        GRO: {
          question: 'Is economic growth improving or slowing?',
          thesis: 'Mixed',
          anchors: []
        },
        CB: {
          question: 'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?',
          thesis: 'Mixed',
          anchors: [{
            date: 'Aug 20',
            impact: 'Red',
            news: 'RBNZ Official Cash Rate',
            forecast: '',
            previous: '',
            actual: '',
            verdict: ''
          }]
        }
      }
    }
  }
};
const STORAGE_KEY = 'pmallen_os_demo_state';
function loadInitial() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      const economy = parsed.economy && parsed.economy.data ? {
        reportingMonth: parsed.economy.reportingMonth || DEFAULT_STATE.economy.reportingMonth,
        data: {
          ...DEFAULT_STATE.economy.data,
          ...parsed.economy.data
        }
      } : DEFAULT_STATE.economy;
      return {
        ...DEFAULT_STATE,
        ...parsed,
        economy
      };
    }
  } catch (e) {}
  return DEFAULT_STATE;
}
function App() {
  const [tab, setTab] = React.useState('analysis');
  const [moreOpen, setMoreOpen] = React.useState(false);
  const [appState, setAppState] = React.useState(loadInitial);
  React.useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(appState));
    } catch (e) {}
  }, [appState]);
  const patch = (key, val) => setAppState(s => ({
    ...s,
    [key]: typeof val === 'function' ? val(s[key]) : val
  }));
  function resetAll() {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch (e) {}
    setAppState(DEFAULT_STATE);
  }
  const ACCENTS = {
    gold: {
      primary: '#f0c040',
      deep: '#d4a017'
    },
    silver: {
      primary: '#c7cdd6',
      deep: '#9aa2ac'
    },
    green: {
      primary: '#00e87a',
      deep: '#00b862'
    }
  };
  React.useEffect(() => {
    const a = ACCENTS[appState.accent || 'gold'];
    document.documentElement.style.setProperty('--gold', a.primary);
    document.documentElement.style.setProperty('--gold-deep', a.deep);
  }, [appState.accent]);
  const day = new Date().getDay();
  const dayNames = ['SUN', 'MON', 'TUE', 'WED', 'THU', 'FRI', 'SAT'];
  const dayLabel = dayNames[day] + (day >= 2 && day <= 4 ? ' · EXECUTE' : day === 1 ? ' · ANALYSIS' : ' · NO TRADE');
  const dayTone = day >= 2 && day <= 4 ? 'exec' : day === 5 || day === 0 || day === 6 ? 'warn' : 'default';
  const [now, setNow] = React.useState(new Date());
  React.useEffect(() => {
    const t = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(t);
  }, []);
  const sast = new Date(now.getTime() + 2 * 60 * 60 * 1000);
  const sastMinutes = sast.getUTCHours() * 60 + sast.getUTCMinutes();
  const sastTime = String(sast.getUTCHours()).padStart(2, '0') + ':' + String(sast.getUTCMinutes()).padStart(2, '0') + ':' + String(sast.getUTCSeconds()).padStart(2, '0');
  const SESSION_DEFS = [{
    n: 'London',
    o: 540,
    c: 1080,
    e: true
  }, {
    n: 'NY',
    o: 840,
    c: 1380,
    e: true
  }, {
    n: 'Asian',
    o: 0,
    c: 540,
    e: false
  }];
  const sessions = SESSION_DEFS.map(s => {
    const isOpen = sastMinutes >= s.o && sastMinutes < s.c;
    return {
      n: s.n,
      tone: isOpen ? s.e ? 'open' : 'obs' : 'default',
      label: isOpen ? 'OPEN' : 'CLOSED'
    };
  });
  function select(id) {
    if (id === 'more') {
      setMoreOpen(v => !v);
      return;
    }
    setMoreOpen(false);
    setTab(id);
  }
  const Screen = SCREENS[tab] || window.AnalysisScreen;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      inset: 0,
      background: 'var(--bg-page)',
      color: 'var(--text-hi)'
    }
  }, /*#__PURE__*/React.createElement(TopBar, {
    title: "PUMALLEN OS",
    subtitle: 'Master Trading System · ' + (appState.pair || 'EURUSD')
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement(Chip, {
    tone: dayTone
  }, dayLabel), /*#__PURE__*/React.createElement(Chip, {
    tone: "obs",
    dense: true,
    dot: false
  }, "SAST ", sastTime))), tab === 'analysis' && /*#__PURE__*/React.createElement("div", {
    className: "pm-hscroll",
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      zIndex: 100,
      display: 'flex',
      gap: 4,
      padding: '5px 8px',
      overflowX: 'auto',
      background: 'rgba(10,8,0,.9)',
      borderBottom: '1px solid var(--bg-surface-alt)'
    }
  }, sessions.map(s => /*#__PURE__*/React.createElement(Chip, {
    key: s.n,
    tone: s.tone,
    dense: true
  }, s.n, " ", s.label))), /*#__PURE__*/React.createElement("div", {
    key: tab,
    className: "pm-screen",
    style: {
      position: 'absolute',
      inset: 0
    }
  }, /*#__PURE__*/React.createElement(Screen, {
    analysis: appState.analysis,
    setAnalysis: v => patch('analysis', v),
    checklist: appState.checklist,
    setChecklist: v => patch('checklist', v),
    chat: appState.chat,
    setChat: v => patch('chat', v),
    journal: appState.journal,
    setJournal: v => patch('journal', v),
    narrative: appState.narrative,
    setNarrative: v => patch('narrative', v),
    resetAll: resetAll,
    accent: appState.accent || 'gold',
    setAccent: v => patch('accent', v),
    navigate: select,
    pair: appState.pair || 'EURUSD',
    setPair: v => patch('pair', v),
    economy: appState.economy,
    setEconomy: v => patch('economy', v)
  })), moreOpen && /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      bottom: 64,
      left: 0,
      right: 0,
      background: 'var(--bg-surface)',
      borderTop: '1px solid var(--border-default)',
      padding: 12,
      zIndex: 9998
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: 'repeat(4,1fr)',
      gap: 8
    }
  }, [{
    id: 'stats',
    icon: '📊',
    label: 'Stats'
  }, {
    id: 'planner',
    icon: '📅',
    label: 'Planner'
  }, {
    id: 'narrative',
    icon: '📝',
    label: 'Narrative'
  }, {
    id: 'history',
    icon: '🗂',
    label: 'History'
  }, {
    id: 'economy',
    icon: '🌐',
    label: 'Economy'
  }, {
    id: 'brief',
    icon: '🧾',
    label: 'Brief'
  }, {
    id: 'settings',
    icon: '⚙️',
    label: 'Settings'
  }].map(it => /*#__PURE__*/React.createElement("div", {
    key: it.id,
    onClick: () => {
      setMoreOpen(false);
      setTab(it.id);
    },
    style: {
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 5,
      padding: '12px 6px',
      background: 'var(--bg-surface-alt)',
      borderRadius: 10,
      cursor: 'pointer',
      fontSize: 10,
      color: 'var(--text-dim)'
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 22
    }
  }, it.icon), it.label)))), /*#__PURE__*/React.createElement(BottomNav, {
    items: NAV_ITEMS,
    active: tab,
    onSelect: select
  }));
}
ReactDOM.createRoot(document.getElementById('root')).render(/*#__PURE__*/React.createElement(App, null));
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/App.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/BriefScreen.jsx
try { (() => {
const {
  Badge,
  VerdictBanner
} = window.PumallenOSDesignSystem_ac653c;
const BR_CHAINS = ['BA', 'LM', 'INF', 'CON', 'GRO', 'CB'];
const BR_CORE = ['BA', 'LM', 'INF'];
const BR_SUPPORT = ['CON', 'GRO', 'CB'];
const BR_SCORE = {
  Strong: 1,
  Mixed: 0,
  Weak: -1
};
function computeCandidate(economy) {
  if (!economy || !economy.data) return null;
  const month = economy.reportingMonth || 'Jul';
  const results = Object.keys(economy.data).map(c => {
    const cd = economy.data[c];
    let total = 0;
    const complete = {};
    BR_CHAINS.forEach(id => {
      total += BR_SCORE[cd[id].thesis];
      const anchors = cd[id].anchors || [];
      const monthAnchors = anchors.filter(a => a.date && a.date.slice(0, 3) === month);
      const answered = monthAnchors.filter(a => a.verdict);
      complete[id] = monthAnchors.length > 0 && answered.length === monthAnchors.length;
    });
    const eligible = BR_CORE.every(id => complete[id]) && BR_SUPPORT.some(id => complete[id]);
    return {
      c,
      total,
      eligible
    };
  }).filter(r => r.eligible).sort((a, b) => b.total - a.total);
  if (results.length < 2) return {
    status: 'insufficient'
  };
  const gap = results[0].total - results[results.length - 1].total;
  return {
    status: gap >= 3 ? 'candidate' : 'no-trade',
    gap,
    strongest: results[0].c,
    weakest: results[results.length - 1].c
  };
}
function BriefScreen(props) {
  const {
    economy,
    checklist,
    analysis,
    pair
  } = props;
  const candidate = computeCandidate(economy);
  const checklistCount = (checklist || []).filter(Boolean).length;
  const checklistDone = checklistCount === 9;
  const verdict = analysis && analysis.verdict;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      bottom: 64,
      overflowY: 'auto',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent-primary)',
      fontSize: 18,
      fontWeight: 800,
      marginBottom: 2
    }
  }, "Session Brief \uD83E\uDDFE"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      marginBottom: 16
    }
  }, "Everything gating today's trade, in one view"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-default)',
      borderRadius: 12,
      padding: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      color: 'var(--text-hi)'
    }
  }, "\uD83C\uDF10 Economic Ranking"), candidate && /*#__PURE__*/React.createElement(Badge, {
    tone: candidate.status === 'candidate' ? 'green' : candidate.status === 'no-trade' ? 'red' : 'muted'
  }, candidate.status === 'candidate' ? 'CANDIDATE' : candidate.status === 'no-trade' ? 'GAP < 3' : 'INSUFFICIENT')), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-dim)',
      lineHeight: 1.6
    }
  }, candidate && candidate.status === 'candidate' && `Strongest vs weakest eligible economy: ${candidate.strongest}/${candidate.weakest}, gap ${candidate.gap}.`, candidate && candidate.status === 'no-trade' && `Strongest/weakest gap (${candidate.gap}) is below the 3-point trade threshold.`, (!candidate || candidate.status === 'insufficient') && `Fewer than 2 currencies meet the PMTS eligibility rule yet.`)), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-default)',
      borderRadius: 12,
      padding: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      color: 'var(--text-hi)'
    }
  }, "\u2705 Pre-Trade Checklist"), /*#__PURE__*/React.createElement(Badge, {
    tone: checklistDone ? 'green' : 'muted'
  }, checklistCount, "/9")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-dim)',
      lineHeight: 1.6
    }
  }, checklistDone ? 'All 9 conditions confirmed.' : `${9 - checklistCount} condition(s) still unconfirmed.`)), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-default)',
      borderRadius: 12,
      padding: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      fontWeight: 700,
      color: 'var(--text-hi)'
    }
  }, "\uD83D\uDD2C Analysis Chain \u2014 ", pair || 'EURUSD'), verdict && /*#__PURE__*/React.createElement(Badge, {
    tone: verdict === 'execute' ? 'green' : 'red'
  }, verdict.toUpperCase())), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-dim)',
      lineHeight: 1.6
    }
  }, verdict ? verdict === 'execute' ? 'Chain of authority reached EXECUTE.' : 'Chain of authority reached STAND DOWN.' : 'No verdict yet — timeframe chain in progress.'))), verdict && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16
    }
  }, /*#__PURE__*/React.createElement(VerdictBanner, {
    verdict: verdict,
    title: verdict === 'execute' ? 'Ready to Execute' : 'Stand Down',
    subtitle: checklistDone ? 'All gates aligned.' : 'Checklist incomplete — resolve before execution.'
  })));
}
window.BriefScreen = BriefScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/BriefScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/CalcScreen.jsx
try { (() => {
const {
  TextField
} = window.PumallenOSDesignSystem_ac653c;
const PIP_VALUE = {
  EURUSD: 10,
  GBPUSD: 10,
  AUDUSD: 10,
  USDCHF: 11,
  USDJPY: 9.13
};
function CalcScreen(props) {
  const pair = props && props.pair || 'EURUSD';
  const [balance, setBalance] = React.useState('1000');
  const [risk, setRisk] = React.useState('1');
  const [pips, setPips] = React.useState('50');
  const [result, setResult] = React.useState(null);
  const [error, setError] = React.useState('');
  function calc() {
    const b = parseFloat(balance),
      r = parseFloat(risk),
      p = parseFloat(pips);
    setError('');
    setResult(null);
    if (!b || b <= 0) {
      setError('Enter a valid account balance greater than 0.');
      return;
    }
    if (!r || r <= 0 || r > 100) {
      setError('Risk per trade must be between 0 and 100%.');
      return;
    }
    if (!p || p <= 0) {
      setError('Stop loss must be a positive number of pips.');
      return;
    }
    if (r > 5) {
      setError('⚠️ ' + r + '% risk per trade is well above the 1–2% PMTS guideline — proceed with caution.');
    }
    const pipValuePerLot = PIP_VALUE[pair] || 10;
    const riskAmt = b * r / 100;
    const lots = riskAmt / (p * pipValuePerLot);
    if (lots < 0.01) {
      setResult({
        riskAmt: riskAmt.toFixed(2),
        lots: '0.00',
        warn: 'Position rounds to below the 0.01 micro-lot minimum — reduce stop loss or increase risk.'
      });
      return;
    }
    setResult({
      riskAmt: riskAmt.toFixed(2),
      lots: lots.toFixed(2),
      pipValue: (lots * pipValuePerLot).toFixed(2)
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      bottom: 64,
      overflowY: 'auto',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent-primary)',
      fontSize: 18,
      fontWeight: 800,
      marginBottom: 2
    }
  }, "Position Size Calculator \uD83E\uDDEE"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      marginBottom: 16
    }
  }, pair, " lot sizing based on account risk \xB7 pip value assumes a USD account"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 12,
      padding: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(TextField, {
    label: "Account Balance ($)",
    type: "number",
    placeholder: "1000",
    value: balance,
    onChange: e => setBalance(e.target.value)
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Risk per Trade (%)",
    type: "number",
    placeholder: "1",
    value: risk,
    onChange: e => setRisk(e.target.value)
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Stop Loss (pips)",
    type: "number",
    placeholder: "50",
    value: pips,
    onChange: e => setPips(e.target.value)
  }), /*#__PURE__*/React.createElement("button", {
    onClick: calc,
    style: {
      width: '100%',
      padding: 12,
      background: 'var(--accent-primary)',
      border: 'none',
      borderRadius: 10,
      color: '#0a0800',
      fontWeight: 800,
      fontSize: 13,
      cursor: 'pointer'
    }
  }, "Calculate"), error && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 12px',
      background: 'var(--surface-red-tint)',
      border: '1px solid var(--border-red)',
      borderRadius: 8,
      fontSize: 12,
      color: 'var(--accent-danger)',
      lineHeight: 1.5
    }
  }, error), result && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 12,
      background: 'rgba(0,0,0,.4)',
      borderRadius: 10,
      border: '1px solid var(--border-default)',
      fontSize: 12,
      lineHeight: 1.75,
      color: 'var(--text-dim)',
      fontFamily: 'var(--font-mono)'
    }
  }, "Risk amount: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--accent-primary)'
    }
  }, "$", result.riskAmt), /*#__PURE__*/React.createElement("br", null), "Position size: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--accent-primary)'
    }
  }, result.lots, " lots"), result.pipValue && /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("br", null), "Pip value at this size: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--accent-primary)'
    }
  }, "$", result.pipValue, "/pip")), result.warn && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 8,
      color: 'var(--accent-danger)',
      fontFamily: 'var(--font-body)'
    }
  }, "\u26A0\uFE0F ", result.warn))));
}
window.CalcScreen = CalcScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/CalcScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/ChatScreen.jsx
try { (() => {
const {
  LoadingDots
} = window.PumallenOSDesignSystem_ac653c;
const PMTS_SYSTEM_BASE = function (pair) {
  return 'You are the Pumallen OS trading assistant for the Pumallen Master Trading System (PMTS) — a disciplined ' + pair + ' price-action framework. Chain of authority: MONTHLY=Supreme authority (mission, no entries), WEEKLY=Strategic planning (cannot contradict Monthly), DAILY=Permission timeframe (no permission=no trade), H4=Engineering (builds execution environment), H1=Execution engine (needs sweep+BOS+pullback), M15=Optional precision only when H1 unclear. Authority flows downward, evidence flows upward. 9 conditions ALL required to execute: Tue-Thu only, London/NY session, Monthly mission confirmed, Weekly aligned, Daily permission, H4 aligned, H1 sweep, H1 BOS, clean pullback — one failure means stand down. Be direct, disciplined, concise. Use checkmarks/bold for key conclusions. When a chart image is attached, read it directly.';
};
const TF_LABELS = {
  MO: 'Monthly',
  W: 'Weekly',
  D: 'Daily',
  H4: 'H4',
  H1: 'H1'
};
function buildContext(analysis, checklist) {
  const lines = [];
  Object.keys(analysis.results || {}).forEach(tf => {
    if (analysis.results[tf]) lines.push('--- ' + TF_LABELS[tf] + ' ANALYSIS ---\n' + analysis.results[tf]);
  });
  if (analysis.verdict) lines.push('CURRENT VERDICT: ' + analysis.verdict.toUpperCase());
  const checkedCount = checklist.filter(Boolean).length;
  lines.push('CHECKLIST: ' + checkedCount + '/9 conditions met.');
  if (!lines.length) return '';
  return '\n\nCURRENT SESSION CONTEXT:\n' + lines.join('\n\n');
}
function ChatScreen(props) {
  const {
    chat,
    setChat,
    analysis,
    checklist,
    pair
  } = props;
  const [val, setVal] = React.useState('');
  const [typing, setTyping] = React.useState(false);
  const [attaching, setAttaching] = React.useState(false);
  const [attachedThumb, setAttachedThumb] = React.useState(null);
  const threadRef = React.useRef(null);
  const slotRef = React.useRef(null);
  React.useEffect(() => {
    if (threadRef.current) threadRef.current.scrollTop = threadRef.current.scrollHeight;
  }, [chat, typing]);
  React.useEffect(() => {
    if (!attaching || !slotRef.current) return;
    const el = slotRef.current;
    const obs = new MutationObserver(() => {
      if (el.hasAttribute('data-filled')) {
        const img = el.shadowRoot && el.shadowRoot.querySelector('.frame img');
        if (img) setAttachedThumb(img.src);
      }
    });
    obs.observe(el, {
      attributes: true,
      attributeFilter: ['data-filled']
    });
    return () => obs.disconnect();
  }, [attaching]);
  function getAttachedImage() {
    const el = slotRef.current;
    const img = el && el.shadowRoot && el.shadowRoot.querySelector('.frame img');
    return img && img.src && img.src.indexOf('data:') === 0 ? img.src : null;
  }
  async function send() {
    if (!val.trim() && !attachedThumb || typing) return;
    const dataUrl = attachedThumb ? getAttachedImage() : null;
    const userMsg = {
      role: 'user',
      content: val || '(chart attached)',
      thumb: attachedThumb
    };
    const next = [...chat, userMsg];
    setChat(next);
    setVal('');
    setAttaching(false);
    setAttachedThumb(null);
    setTyping(true);
    try {
      const apiMessages = next.slice(-10).map((m, i, arr) => {
        if (i === arr.length - 1 && dataUrl) {
          const mediaType = dataUrl.slice(5, dataUrl.indexOf(';'));
          const base64 = dataUrl.slice(dataUrl.indexOf(',') + 1);
          return {
            role: 'user',
            content: [{
              type: 'image',
              source: {
                type: 'base64',
                media_type: mediaType,
                data: base64
              }
            }, {
              type: 'text',
              text: m.content
            }]
          };
        }
        return {
          role: m.role,
          content: m.content
        };
      });
      const reply = await window.claude.complete({
        system: PMTS_SYSTEM_BASE(pair || 'EURUSD') + buildContext(analysis, checklist),
        messages: apiMessages
      });
      setChat(c => [...c, {
        role: 'assistant',
        content: reply
      }]);
    } catch (err) {
      setChat(c => [...c, {
        role: 'assistant',
        content: '⚠ ' + (err && err.message ? err.message : 'Request failed. Try again.')
      }]);
    }
    setTyping(false);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      bottom: 64,
      display: 'flex',
      flexDirection: 'column'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '16px 16px 10px',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent-primary)',
      fontSize: 18,
      fontWeight: 800
    }
  }, "AI Chat \uD83D\uDCAC"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      marginTop: 2
    }
  }, "Ask about the current ", pair || 'EURUSD', " analysis or PMTS rules \xB7 powered by Claude")), /*#__PURE__*/React.createElement("div", {
    ref: threadRef,
    style: {
      flex: 1,
      overflowY: 'auto',
      padding: '0 16px 12px',
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, chat.map((m, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      maxWidth: '85%',
      padding: '10px 13px',
      borderRadius: 14,
      fontSize: 13,
      lineHeight: 1.5,
      whiteSpace: 'pre-wrap',
      animation: 'pmFadeIn .2s ease',
      alignSelf: m.role === 'user' ? 'flex-end' : 'flex-start',
      background: m.role === 'user' ? 'var(--accent-primary)' : 'var(--bg-surface-alt)',
      color: m.role === 'user' ? '#0a0800' : 'var(--text-hi)',
      border: m.role === 'user' ? 'none' : '1px solid var(--border-default)'
    }
  }, m.thumb && /*#__PURE__*/React.createElement("img", {
    src: m.thumb,
    style: {
      width: '100%',
      maxHeight: 120,
      objectFit: 'cover',
      borderRadius: 8,
      marginBottom: 6,
      display: 'block'
    }
  }), m.content)), typing && /*#__PURE__*/React.createElement("div", {
    style: {
      alignSelf: 'flex-start',
      padding: '10px 13px',
      borderRadius: 14,
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement(LoadingDots, null))), attaching && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '0 16px 10px',
      flexShrink: 0
    }
  }, /*#__PURE__*/React.createElement("div", {
    ref: el => {
      if (el) slotRef.current = el.querySelector('image-slot');
    }
  }, /*#__PURE__*/React.createElement("image-slot", {
    id: "chat-attach",
    shape: "rounded",
    radius: "10",
    placeholder: "Drop a chart to ask about",
    style: {
      width: '100%',
      height: 80,
      display: 'block'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: '10px 16px 16px',
      flexShrink: 0,
      display: 'flex',
      gap: 8,
      borderTop: '1px solid var(--border-default)'
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setAttaching(a => !a),
    style: {
      padding: '11px 13px',
      background: attaching ? 'var(--accent-primary)' : 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 20,
      color: attaching ? '#0a0800' : 'var(--text-muted)',
      cursor: 'pointer',
      fontSize: 14
    }
  }, "\uD83D\uDCCE"), /*#__PURE__*/React.createElement("input", {
    value: val,
    onChange: e => setVal(e.target.value),
    onKeyDown: e => e.key === 'Enter' && send(),
    placeholder: "Ask a question...",
    style: {
      flex: 1,
      padding: '11px 13px',
      background: 'var(--bg-surface-alt)',
      border: '1.5px solid var(--border-gold)',
      borderRadius: 20,
      color: 'var(--text-hi)',
      fontFamily: 'var(--font-body)',
      fontSize: 13
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: send,
    style: {
      padding: '11px 16px',
      background: 'var(--accent-primary)',
      border: 'none',
      borderRadius: 20,
      color: '#0a0800',
      fontWeight: 800,
      cursor: 'pointer'
    }
  }, "\u27A4")));
}
window.ChatScreen = ChatScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/ChatScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/ChecklistScreen.jsx
try { (() => {
const {
  ChecklistItem,
  Button
} = window.PumallenOSDesignSystem_ac653c;
const CHECKLIST_ITEMS = ['Tuesday–Thursday only', 'London or New York session active', 'Monthly mission confirmed', 'Weekly plan aligned with Monthly', 'Daily permission granted', 'H4 structure aligned', 'H1 liquidity sweep occurred', 'H1 break of structure confirmed', 'Clean pullback entry available'];
function ChecklistScreen(props) {
  const {
    checklist,
    setChecklist
  } = props;
  const count = checklist.filter(Boolean).length;
  const all = count === 9;
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      bottom: 64,
      overflowY: 'auto',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent-primary)',
      fontSize: 18,
      fontWeight: 800,
      marginBottom: 2
    }
  }, "Pre-Trade Checklist \u2705"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      marginBottom: 16
    }
  }, "PMTS 9-Condition Gate \u2014 feeds the Analysis screen's execution gate"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, CHECKLIST_ITEMS.map((label, i) => /*#__PURE__*/React.createElement(ChecklistItem, {
    key: i,
    label: label,
    checked: checklist[i],
    onToggle: () => setChecklist(checklist.map((v, j) => j === i ? !v : v))
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      padding: 16,
      borderRadius: 12,
      textAlign: 'center',
      fontWeight: 800,
      fontSize: 15,
      background: all ? 'var(--surface-green-tint)' : 'var(--surface-red-tint)',
      border: '1px solid ' + (all ? 'var(--accent-success)' : 'var(--accent-danger)'),
      color: all ? 'var(--accent-success)' : 'var(--accent-danger)'
    }
  }, all ? '✅ ALL CONDITIONS MET — EXECUTE' : '🚫 STAND DOWN (' + count + '/9 conditions met)'), /*#__PURE__*/React.createElement(Button, {
    variant: "ghost",
    style: {
      width: '100%',
      marginTop: 12
    },
    onClick: () => setChecklist(Array(9).fill(false))
  }, "\u21BA Reset Checklist"));
}
window.ChecklistScreen = ChecklistScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/ChecklistScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/EconomyScreen.jsx
try { (() => {
const {
  Badge
} = window.PumallenOSDesignSystem_ac653c;
const CHAINS = [{
  id: 'BA',
  label: 'Business Activity'
}, {
  id: 'LM',
  label: 'Labour Market'
}, {
  id: 'INF',
  label: 'Inflation'
}, {
  id: 'CON',
  label: 'Consumer Activity'
}, {
  id: 'GRO',
  label: 'Economic Growth'
}, {
  id: 'CB',
  label: 'Central Bank'
}];
const CORE = ['BA', 'LM', 'INF'];
const SUPPORT = ['CON', 'GRO', 'CB'];
const CCYS = ['USD', 'EUR', 'GBP', 'JPY', 'AUD', 'CAD', 'CHF', 'NZD'];
const THESES = ['Strong', 'Mixed', 'Weak'];
const VERDICTS = ['', 'Supports Thesis', 'Rejects Thesis', 'Neutral / N/A'];
const SCORE = {
  Strong: 1,
  Mixed: 0,
  Weak: -1
};
const VERDICT_WEIGHT = {
  'Supports Thesis': 1,
  'Rejects Thesis': -1,
  'Neutral / N/A': 0
};
function suggestThesis(chain) {
  const answered = (chain.anchors || []).filter(a => a.verdict);
  if (answered.length === 0) return null;
  const sum = answered.reduce((s, a) => s + (VERDICT_WEIGHT[a.verdict] || 0), 0);
  const avg = sum / answered.length;
  return avg > 0.25 ? 'Strong' : avg < -0.25 ? 'Weak' : 'Mixed';
}
const USD_PAIR_ORDER = ['EUR', 'GBP', 'AUD', 'NZD']; // conventionally quoted ahead of USD
function toPairSymbol(a, b) {
  if (a === 'USD' && USD_PAIR_ORDER.includes(b)) return b + 'USD';
  if (b === 'USD' && USD_PAIR_ORDER.includes(a)) return a + 'USD';
  if (a === 'USD') return 'USD' + b;
  if (b === 'USD') return 'USD' + a;
  return a + b;
}
function computeStatus(chain, month) {
  const anchors = chain.anchors || [];
  const monthAnchors = anchors.filter(a => a.date && a.date.slice(0, 3) === month);
  if (monthAnchors.length === 0) return anchors.length === 0 ? 'Not Started' : 'Collecting Evidence';
  const answered = monthAnchors.filter(a => a.verdict);
  if (answered.length === 0) return 'Not Started';
  if (answered.length === monthAnchors.length) return 'Thesis Complete';
  return 'Collecting Evidence';
}
function computeCurrency(data, month) {
  let total = 0;
  const statuses = {};
  CHAINS.forEach(c => {
    total += SCORE[data[c.id].thesis];
    statuses[c.id] = computeStatus(data[c.id], month);
  });
  const coreComplete = CORE.every(id => statuses[id] === 'Thesis Complete');
  const supportComplete = SUPPORT.some(id => statuses[id] === 'Thesis Complete');
  const eligible = coreComplete && supportComplete;
  const chainsComplete = CHAINS.filter(c => statuses[c.id] === 'Thesis Complete').length;
  return {
    total,
    statuses,
    coreComplete,
    supportComplete,
    eligible,
    chainsComplete,
    eligibleScore: eligible ? total : null
  };
}
function EconomyScreen(props) {
  const {
    economy,
    setEconomy,
    pair,
    setPair
  } = props;
  if (!economy || !economy.data) return null;
  const month = economy.reportingMonth || 'Jul';
  const data = economy.data;
  const pairCcys = [(pair || 'EURUSD').slice(0, 3), (pair || 'EURUSD').slice(3, 6)];
  const [tab, setTab] = React.useState('calendar');
  const [ccy, setCcy] = React.useState('USD');
  const [chainId, setChainId] = React.useState('BA');
  function setMonth(m) {
    setEconomy({
      ...economy,
      reportingMonth: m
    });
  }
  function updateThesis(c, cid, val) {
    setEconomy({
      ...economy,
      data: {
        ...data,
        [c]: {
          ...data[c],
          [cid]: {
            ...data[c][cid],
            thesis: val
          }
        }
      }
    });
  }
  function updateAnchorVerdict(c, cid, idx, val) {
    const anchors = data[c][cid].anchors.map((a, i) => i === idx ? {
      ...a,
      verdict: val
    } : a);
    setEconomy({
      ...economy,
      data: {
        ...data,
        [c]: {
          ...data[c],
          [cid]: {
            ...data[c][cid],
            anchors
          }
        }
      }
    });
  }
  function addAnchor(c, cid, draft) {
    const anchors = [...data[c][cid].anchors, {
      date: draft.date || month,
      impact: draft.impact || 'Orange',
      news: draft.news,
      forecast: draft.forecast || '',
      previous: draft.previous || '',
      actual: draft.actual || '',
      verdict: ''
    }];
    setEconomy({
      ...economy,
      data: {
        ...data,
        [c]: {
          ...data[c],
          [cid]: {
            ...data[c][cid],
            anchors
          }
        }
      }
    });
  }
  function removeAnchor(c, cid, idx) {
    const anchors = data[c][cid].anchors.filter((_, i) => i !== idx);
    setEconomy({
      ...economy,
      data: {
        ...data,
        [c]: {
          ...data[c],
          [cid]: {
            ...data[c][cid],
            anchors
          }
        }
      }
    });
  }
  const [showAddForm, setShowAddForm] = React.useState(false);
  const [draft, setDraft] = React.useState({
    date: '',
    impact: 'Orange',
    news: '',
    forecast: '',
    previous: '',
    actual: ''
  });
  React.useEffect(() => {
    setShowAddForm(false);
    setDraft({
      date: '',
      impact: 'Orange',
      news: '',
      forecast: '',
      previous: '',
      actual: ''
    });
  }, [ccy, chainId]);
  function updateAnchorField(c, cid, idx, field, val) {
    const anchors = data[c][cid].anchors.map((a, i) => i === idx ? {
      ...a,
      [field]: val
    } : a);
    setEconomy({
      ...economy,
      data: {
        ...data,
        [c]: {
          ...data[c],
          [cid]: {
            ...data[c][cid],
            anchors
          }
        }
      }
    });
  }
  const allEvents = [];
  CCYS.forEach(c => CHAINS.forEach(ch => {
    (data[c][ch.id].anchors || []).forEach((a, idx) => {
      allEvents.push({
        ...a,
        ccy: c,
        chainId: ch.id,
        chainLabel: ch.label,
        idx
      });
    });
  }));
  const monthOrder = {
    Jul: 0,
    Aug: 1
  };
  allEvents.sort((a, b) => {
    const ma = monthOrder[a.date.slice(0, 3)] !== undefined ? monthOrder[a.date.slice(0, 3)] : 9;
    const mb = monthOrder[b.date.slice(0, 3)] !== undefined ? monthOrder[b.date.slice(0, 3)] : 9;
    if (ma !== mb) return ma - mb;
    return (parseInt(a.date.slice(3)) || 0) - (parseInt(b.date.slice(3)) || 0);
  });
  const [calFilter, setCalFilter] = React.useState('all');
  const [calScope, setCalScope] = React.useState('pair');
  const [expandedEvent, setExpandedEvent] = React.useState(null);
  const scopedEvents = calScope === 'pair' ? allEvents.filter(e => pairCcys.includes(e.ccy)) : allEvents;
  const calEvents = scopedEvents.filter(e => calFilter === 'all' ? true : calFilter === 'pending' ? !e.actual : !!e.actual);
  const computed = {};
  CCYS.forEach(c => {
    computed[c] = computeCurrency(data[c], month);
  });
  const eligibleList = CCYS.filter(c => computed[c].eligible).map(c => ({
    c,
    score: computed[c].eligibleScore
  })).sort((a, b) => b.score - a.score);
  let pairResult;
  if (eligibleList.length < 2) {
    pairResult = {
      status: 'insufficient',
      text: 'NOT ENOUGH ELIGIBLE CURRENCIES — fewer than 2 pass the PMTS Eligibility Rule'
    };
  } else {
    const strongest = eligibleList[0],
      weakest = eligibleList[eligibleList.length - 1];
    const gap = strongest.score - weakest.score;
    const confidence = gap >= 8 ? 'Very High' : gap >= 5 ? 'High' : gap >= 3 ? 'Moderate' : '—';
    pairResult = {
      status: gap >= 3 ? 'candidate' : 'no-trade',
      strongest,
      weakest,
      gap,
      confidence
    };
  }
  const TABS = [{
    id: 'calendar',
    label: 'Calendar'
  }, {
    id: 'evidence',
    label: 'Evidence'
  }, {
    id: 'rankings',
    label: 'Rankings'
  }, {
    id: 'pair',
    label: 'Pair Select'
  }];
  const chain = data[ccy][chainId];
  const chainStatus = computed[ccy].statuses[chainId];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      bottom: 64,
      overflowY: 'auto',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent-primary)',
      fontSize: 18,
      fontWeight: 800
    }
  }, "Economic Ranking \uD83C\uDF10"), /*#__PURE__*/React.createElement("select", {
    value: month,
    onChange: e => setMonth(e.target.value),
    style: {
      padding: '5px 8px',
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 8,
      color: 'var(--accent-primary)',
      fontSize: 11,
      fontWeight: 700,
      fontFamily: 'var(--font-mono)'
    }
  }, ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'].map(m => /*#__PURE__*/React.createElement("option", {
    key: m,
    value: m
  }, m)))), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      marginBottom: 4
    }
  }, "Evidence-based currency ranking & pair selection engine"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 10,
      marginBottom: 12,
      fontStyle: 'italic'
    }
  }, "From your PMTS Economic Ranking workbook \u2014 not part of the original app"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginBottom: 14
    }
  }, TABS.map(t => /*#__PURE__*/React.createElement("button", {
    key: t.id,
    onClick: () => setTab(t.id),
    style: {
      flex: 1,
      padding: '8px 6px',
      borderRadius: 8,
      fontSize: 11,
      fontWeight: 700,
      cursor: 'pointer',
      background: tab === t.id ? 'var(--accent-primary)' : 'var(--bg-surface-alt)',
      color: tab === t.id ? '#0a0800' : 'var(--text-muted)',
      border: '1px solid var(--border-default)'
    }
  }, t.label))), tab === 'calendar' && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)',
      marginBottom: 10,
      lineHeight: 1.5
    }
  }, "All logged anchor events across every currency, in date order. Enter the Actual value as soon as a print comes out \u2014 it updates the same record shown on the Evidence tab."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginBottom: 8
    }
  }, [{
    id: 'pair',
    label: 'This Pair (' + pairCcys.join('/') + ')'
  }, {
    id: 'all',
    label: 'All Currencies'
  }].map(s => /*#__PURE__*/React.createElement("button", {
    key: s.id,
    onClick: () => setCalScope(s.id),
    style: {
      flex: 1,
      padding: '7px 8px',
      borderRadius: 8,
      fontSize: 10,
      fontWeight: 700,
      cursor: 'pointer',
      background: calScope === s.id ? 'var(--surface-gold-tint)' : 'var(--bg-surface-alt)',
      color: calScope === s.id ? 'var(--accent-primary)' : 'var(--text-muted)',
      border: '1px solid ' + (calScope === s.id ? 'var(--border-gold)' : 'var(--border-default)')
    }
  }, s.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginBottom: 12
    }
  }, [{
    id: 'all',
    label: 'All'
  }, {
    id: 'pending',
    label: 'Pending'
  }, {
    id: 'released',
    label: 'Released'
  }].map(f => /*#__PURE__*/React.createElement("button", {
    key: f.id,
    onClick: () => setCalFilter(f.id),
    style: {
      flex: 1,
      padding: '7px 8px',
      borderRadius: 8,
      fontSize: 11,
      fontWeight: 700,
      cursor: 'pointer',
      background: calFilter === f.id ? 'var(--accent-primary)' : 'var(--bg-surface-alt)',
      color: calFilter === f.id ? '#0a0800' : 'var(--text-muted)',
      border: '1px solid var(--border-default)'
    }
  }, f.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6
    }
  }, calEvents.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      textAlign: 'center',
      padding: 20
    }
  }, "No events match this filter."), calEvents.map((e, i) => {
    const key = e.ccy + '-' + e.chainId + '-' + e.idx;
    const released = !!e.actual;
    return /*#__PURE__*/React.createElement("div", {
      key: key,
      style: {
        background: 'var(--bg-surface)',
        border: '1px solid var(--border-default)',
        borderRadius: 10,
        padding: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        justifyContent: 'space-between',
        alignItems: 'center',
        marginBottom: 4
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 10,
        color: 'var(--text-muted)',
        fontFamily: 'var(--font-mono)'
      }
    }, e.date, " \xB7 ", e.ccy, " \xB7 ", e.chainLabel), /*#__PURE__*/React.createElement(Badge, {
      tone: released ? 'green' : 'amber'
    }, released ? 'RELEASED' : 'PENDING')), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: 'var(--text-hi)',
        fontWeight: 600,
        marginBottom: released ? 6 : 8
      }
    }, e.news), released ? /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 11,
        color: 'var(--text-dim)',
        fontFamily: 'var(--font-mono)',
        display: 'flex',
        gap: 12
      }
    }, /*#__PURE__*/React.createElement("span", null, "Actual: ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: 'var(--accent-primary)'
      }
    }, e.actual)), e.forecast && /*#__PURE__*/React.createElement("span", null, "Forecast: ", e.forecast), e.verdict && /*#__PURE__*/React.createElement("span", {
      style: {
        color: e.verdict === 'Supports Thesis' ? 'var(--accent-success)' : e.verdict === 'Rejects Thesis' ? 'var(--accent-danger)' : 'var(--text-muted)'
      }
    }, e.verdict)) : expandedEvent === key ? /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        flexDirection: 'column',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("input", {
      autoFocus: true,
      placeholder: "Enter actual value",
      value: e.actual,
      onChange: ev => updateAnchorField(e.ccy, e.chainId, e.idx, 'actual', ev.target.value),
      style: {
        padding: '7px 8px',
        background: 'var(--bg-page)',
        border: '1px solid var(--border-gold)',
        borderRadius: 6,
        color: 'var(--text-hi)',
        fontSize: 11,
        boxSizing: 'border-box'
      }
    }), /*#__PURE__*/React.createElement("select", {
      value: e.verdict,
      onChange: ev => updateAnchorField(e.ccy, e.chainId, e.idx, 'verdict', ev.target.value),
      style: {
        padding: '7px 8px',
        background: 'var(--bg-page)',
        border: '1px solid var(--border-default)',
        borderRadius: 6,
        fontSize: 11,
        color: 'var(--text-hi)'
      }
    }, VERDICTS.map(v => /*#__PURE__*/React.createElement("option", {
      key: v,
      value: v
    }, v || '— Operator Verdict —'))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: 'flex',
        gap: 6
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: () => setExpandedEvent(null),
      style: {
        flex: 1,
        padding: 8,
        background: 'var(--accent-primary)',
        border: 'none',
        borderRadius: 6,
        color: '#0a0800',
        fontWeight: 700,
        fontSize: 11,
        cursor: 'pointer'
      }
    }, "Done"))) : /*#__PURE__*/React.createElement("button", {
      onClick: () => setExpandedEvent(key),
      style: {
        padding: '6px 10px',
        background: 'var(--bg-surface-alt)',
        border: '1px dashed var(--border-gold)',
        borderRadius: 6,
        color: 'var(--accent-primary)',
        fontSize: 11,
        fontWeight: 700,
        cursor: 'pointer'
      }
    }, "Enter Actual \u2192"));
  }))), tab === 'evidence' && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    className: "pm-hscroll",
    style: {
      display: 'flex',
      gap: 6,
      marginBottom: 10,
      overflowX: 'auto'
    }
  }, CCYS.map(c => /*#__PURE__*/React.createElement("button", {
    key: c,
    onClick: () => setCcy(c),
    style: {
      padding: '6px 12px',
      borderRadius: 20,
      fontSize: 11,
      fontWeight: 700,
      cursor: 'pointer',
      flexShrink: 0,
      background: ccy === c ? 'var(--accent-primary)' : 'var(--bg-surface-alt)',
      color: ccy === c ? '#0a0800' : 'var(--text-muted)',
      border: '1px solid var(--border-default)'
    }
  }, c))), /*#__PURE__*/React.createElement("div", {
    className: "pm-hscroll",
    style: {
      display: 'flex',
      gap: 6,
      marginBottom: 12,
      overflowX: 'auto'
    }
  }, CHAINS.map(c => /*#__PURE__*/React.createElement("button", {
    key: c.id,
    onClick: () => setChainId(c.id),
    style: {
      padding: '6px 10px',
      borderRadius: 8,
      fontSize: 10,
      fontWeight: 700,
      cursor: 'pointer',
      flexShrink: 0,
      background: chainId === c.id ? 'var(--surface-gold-tint)' : 'var(--bg-surface-alt)',
      color: chainId === c.id ? 'var(--accent-primary)' : 'var(--text-muted)',
      border: '1px solid ' + (chainId === c.id ? 'var(--border-gold)' : 'var(--border-default)')
    }
  }, c.label))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-default)',
      borderRadius: 10,
      padding: 12,
      marginBottom: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--text-hi)'
    }
  }, CHAINS.find(c => c.id === chainId).label), /*#__PURE__*/React.createElement(Badge, {
    tone: CORE.includes(chainId) ? 'amber' : 'muted'
  }, CORE.includes(chainId) ? 'CORE' : 'SUPPORT')), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)',
      marginBottom: 10,
      lineHeight: 1.4
    }
  }, chain.question), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      alignItems: 'center',
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)'
    }
  }, "Chain Thesis:"), /*#__PURE__*/React.createElement("select", {
    value: chain.thesis,
    onChange: e => updateThesis(ccy, chainId, e.target.value),
    style: {
      flex: 1,
      padding: '6px 8px',
      background: 'var(--bg-page)',
      border: '1px solid var(--border-gold)',
      borderRadius: 8,
      color: 'var(--text-hi)',
      fontSize: 11
    }
  }, THESES.map(s => /*#__PURE__*/React.createElement("option", {
    key: s,
    value: s
  }, s))), /*#__PURE__*/React.createElement(Badge, {
    tone: chainStatus === 'Thesis Complete' ? 'green' : chainStatus === 'Collecting Evidence' ? 'amber' : 'muted'
  }, chainStatus.toUpperCase())), (() => {
    const suggestion = suggestThesis(chain);
    return suggestion && suggestion !== chain.thesis && /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 6,
        display: 'flex',
        alignItems: 'center',
        gap: 6,
        fontSize: 10,
        color: 'var(--text-muted)'
      }
    }, "Suggested from verdicts: ", /*#__PURE__*/React.createElement("b", {
      style: {
        color: 'var(--accent-primary)'
      }
    }, suggestion), /*#__PURE__*/React.createElement("button", {
      onClick: () => updateThesis(ccy, chainId, suggestion),
      style: {
        padding: '3px 8px',
        background: 'var(--surface-gold-tint)',
        border: '1px solid var(--border-gold)',
        borderRadius: 12,
        color: 'var(--accent-primary)',
        fontSize: 10,
        fontWeight: 700,
        cursor: 'pointer'
      }
    }, "Use"));
  })()), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)',
      marginBottom: 6,
      fontWeight: 700,
      letterSpacing: '.05em'
    }
  }, "ANCHOR REPORTS (", month, ")"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 6,
      marginBottom: 10
    }
  }, chain.anchors.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      padding: 10,
      textAlign: 'center'
    }
  }, "No anchor reports logged yet."), chain.anchors.map((a, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 8,
      padding: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      fontSize: 10,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)',
      marginBottom: 3
    }
  }, /*#__PURE__*/React.createElement("span", null, a.date, " \xB7 ", a.impact), a.actual && /*#__PURE__*/React.createElement("span", null, "Actual: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--text-hi)'
    }
  }, a.actual))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-hi)',
      fontWeight: 600,
      marginBottom: 6
    }
  }, a.news), (a.forecast || a.previous) && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 12,
      fontSize: 10,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)',
      marginBottom: 6
    }
  }, a.forecast && /*#__PURE__*/React.createElement("span", null, "Forecast: ", a.forecast), a.previous && /*#__PURE__*/React.createElement("span", null, "Previous: ", a.previous)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6
    }
  }, /*#__PURE__*/React.createElement("select", {
    value: a.verdict,
    onChange: e => updateAnchorVerdict(ccy, chainId, i, e.target.value),
    style: {
      flex: 1,
      padding: '6px 8px',
      background: 'var(--bg-page)',
      border: '1px solid var(--border-default)',
      borderRadius: 6,
      fontSize: 11,
      color: a.verdict === 'Supports Thesis' ? 'var(--accent-success)' : a.verdict === 'Rejects Thesis' ? 'var(--accent-danger)' : 'var(--text-muted)'
    }
  }, VERDICTS.map(v => /*#__PURE__*/React.createElement("option", {
    key: v,
    value: v
  }, v || '— Operator Verdict —'))), /*#__PURE__*/React.createElement("button", {
    onClick: () => removeAnchor(ccy, chainId, i),
    style: {
      padding: '6px 10px',
      background: 'transparent',
      border: '1px solid var(--border-default)',
      borderRadius: 6,
      color: 'var(--text-muted)',
      cursor: 'pointer',
      fontSize: 12
    }
  }, "\uD83D\uDDD1\uFE0F"))))), !showAddForm ? /*#__PURE__*/React.createElement("button", {
    onClick: () => setShowAddForm(true),
    style: {
      width: '100%',
      padding: 10,
      background: 'var(--bg-surface-alt)',
      border: '1.5px dashed var(--border-gold)',
      borderRadius: 8,
      color: 'var(--accent-primary)',
      fontSize: 11,
      fontWeight: 700,
      cursor: 'pointer'
    }
  }, "+ Add Anchor Report") : /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface)',
      border: '1.5px solid var(--border-gold)',
      borderRadius: 10,
      padding: 12,
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontWeight: 700,
      color: 'var(--text-hi)',
      marginBottom: 2
    }
  }, "New Anchor Report"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: 'var(--text-muted)',
      marginBottom: 3
    }
  }, "Date"), /*#__PURE__*/React.createElement("input", {
    value: draft.date,
    onChange: e => setDraft({
      ...draft,
      date: e.target.value
    }),
    placeholder: month + ' 12',
    style: {
      width: '100%',
      padding: '7px 8px',
      background: 'var(--bg-page)',
      border: '1px solid var(--border-default)',
      borderRadius: 6,
      color: 'var(--text-hi)',
      fontSize: 11,
      boxSizing: 'border-box'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: 'var(--text-muted)',
      marginBottom: 3
    }
  }, "Impact"), /*#__PURE__*/React.createElement("select", {
    value: draft.impact,
    onChange: e => setDraft({
      ...draft,
      impact: e.target.value
    }),
    style: {
      width: '100%',
      padding: '7px 8px',
      background: 'var(--bg-page)',
      border: '1px solid var(--border-default)',
      borderRadius: 6,
      color: 'var(--text-hi)',
      fontSize: 11
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "Red"
  }, "Red"), /*#__PURE__*/React.createElement("option", {
    value: "Orange"
  }, "Orange"), /*#__PURE__*/React.createElement("option", {
    value: "Yellow"
  }, "Yellow")))), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: 'var(--text-muted)',
      marginBottom: 3
    }
  }, "News Event"), /*#__PURE__*/React.createElement("input", {
    value: draft.news,
    onChange: e => setDraft({
      ...draft,
      news: e.target.value
    }),
    placeholder: "e.g. ISM Manufacturing PMI",
    style: {
      width: '100%',
      padding: '7px 8px',
      background: 'var(--bg-page)',
      border: '1px solid var(--border-default)',
      borderRadius: 6,
      color: 'var(--text-hi)',
      fontSize: 11,
      boxSizing: 'border-box'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: 'var(--text-muted)',
      marginBottom: 3
    }
  }, "Forecast"), /*#__PURE__*/React.createElement("input", {
    value: draft.forecast,
    onChange: e => setDraft({
      ...draft,
      forecast: e.target.value
    }),
    style: {
      width: '100%',
      padding: '7px 8px',
      background: 'var(--bg-page)',
      border: '1px solid var(--border-default)',
      borderRadius: 6,
      color: 'var(--text-hi)',
      fontSize: 11,
      boxSizing: 'border-box'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: 'var(--text-muted)',
      marginBottom: 3
    }
  }, "Previous"), /*#__PURE__*/React.createElement("input", {
    value: draft.previous,
    onChange: e => setDraft({
      ...draft,
      previous: e.target.value
    }),
    style: {
      width: '100%',
      padding: '7px 8px',
      background: 'var(--bg-page)',
      border: '1px solid var(--border-default)',
      borderRadius: 6,
      color: 'var(--text-hi)',
      fontSize: 11,
      boxSizing: 'border-box'
    }
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: 'var(--text-muted)',
      marginBottom: 3
    }
  }, "Actual"), /*#__PURE__*/React.createElement("input", {
    value: draft.actual,
    onChange: e => setDraft({
      ...draft,
      actual: e.target.value
    }),
    style: {
      width: '100%',
      padding: '7px 8px',
      background: 'var(--bg-page)',
      border: '1px solid var(--border-default)',
      borderRadius: 6,
      color: 'var(--text-hi)',
      fontSize: 11,
      boxSizing: 'border-box'
    }
  }))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginTop: 4
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      if (!draft.news.trim()) return;
      addAnchor(ccy, chainId, draft);
      setShowAddForm(false);
      setDraft({
        date: '',
        impact: 'Orange',
        news: '',
        forecast: '',
        previous: '',
        actual: ''
      });
    },
    style: {
      flex: 1,
      padding: 10,
      background: 'var(--accent-primary)',
      border: 'none',
      borderRadius: 8,
      color: '#0a0800',
      fontWeight: 800,
      fontSize: 12,
      cursor: 'pointer'
    }
  }, "Add Report"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setShowAddForm(false),
    style: {
      padding: 10,
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 8,
      color: 'var(--text-muted)',
      fontWeight: 700,
      fontSize: 12,
      cursor: 'pointer'
    }
  }, "Cancel")))), tab === 'rankings' && /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)',
      marginBottom: 2
    }
  }, "Strong=+1 \xB7 Mixed=0 \xB7 Weak=-1 \xB7 Eligible requires all 3 core chains + at least 1 support chain \"Thesis Complete\" for ", month), CCYS.slice().sort((a, b) => computed[b].total - computed[a].total).map(c => /*#__PURE__*/React.createElement("div", {
    key: c,
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-default)',
      borderRadius: 10,
      padding: '10px 12px',
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 13,
      fontWeight: 700,
      color: 'var(--text-hi)'
    }
  }, c), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)'
    }
  }, computed[c].chainsComplete, "/6 chains complete")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: 'var(--font-mono)',
      fontSize: 14,
      fontWeight: 800,
      color: computed[c].total > 0 ? 'var(--accent-success)' : computed[c].total < 0 ? 'var(--accent-danger)' : 'var(--text-muted)'
    }
  }, computed[c].total > 0 ? '+' : '', computed[c].total), /*#__PURE__*/React.createElement(Badge, {
    tone: computed[c].eligible ? 'green' : 'muted'
  }, computed[c].eligible ? 'ELIGIBLE' : '—'))))), tab === 'pair' && /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      marginBottom: 12
    }
  }, eligibleList.length, " of ", CCYS.length, " currencies meet the PMTS Eligibility Rule for ", month), pairResult.status === 'insufficient' ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      borderRadius: 12,
      background: 'var(--surface-red-tint)',
      border: '1px solid var(--border-red)',
      color: 'var(--accent-danger)',
      fontSize: 13,
      fontWeight: 700,
      textAlign: 'center',
      lineHeight: 1.5
    }
  }, "\uD83D\uDEAB ", pairResult.text) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8,
      marginBottom: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      background: 'var(--surface-green-tint)',
      border: '1px solid var(--border-green)',
      borderRadius: 10,
      padding: 12,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)',
      marginBottom: 4
    }
  }, "STRONGEST"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 800,
      color: 'var(--accent-success)'
    }
  }, pairResult.strongest.c), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-dim)'
    }
  }, "score ", pairResult.strongest.score)), /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      background: 'var(--surface-red-tint)',
      border: '1px solid var(--border-red)',
      borderRadius: 10,
      padding: 12,
      textAlign: 'center'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)',
      marginBottom: 4
    }
  }, "WEAKEST"), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 18,
      fontWeight: 800,
      color: 'var(--accent-danger)'
    }
  }, pairResult.weakest.c), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      fontFamily: 'var(--font-mono)',
      color: 'var(--text-dim)'
    }
  }, "score ", pairResult.weakest.score))), /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 16,
      borderRadius: 12,
      textAlign: 'center',
      marginBottom: 12,
      background: pairResult.status === 'candidate' ? 'var(--surface-green-tint)' : 'var(--surface-red-tint)',
      border: '1px solid ' + (pairResult.status === 'candidate' ? 'var(--border-green)' : 'var(--border-red)')
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 15,
      fontWeight: 800,
      color: pairResult.status === 'candidate' ? 'var(--accent-success)' : 'var(--accent-danger)',
      marginBottom: 4
    }
  }, pairResult.status === 'candidate' ? '✅ ' + pairResult.strongest.c + '/' + pairResult.weakest.c : '🚫 NO TRADE'), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)'
    }
  }, "Gap ", pairResult.gap, " \xB7 Confidence: ", pairResult.confidence), pairResult.status === 'candidate' && setPair && /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      setPair(toPairSymbol(pairResult.strongest.c, pairResult.weakest.c));
      if (props.navigate) props.navigate('analysis');
    },
    style: {
      marginTop: 10,
      padding: '8px 14px',
      background: 'var(--accent-primary)',
      border: 'none',
      borderRadius: 8,
      color: '#0a0800',
      fontWeight: 800,
      fontSize: 11,
      cursor: 'pointer'
    }
  }, "Use ", toPairSymbol(pairResult.strongest.c, pairResult.weakest.c), " \u2192 Go to Analysis"))), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)',
      lineHeight: 1.6,
      padding: '0 2px'
    }
  }, "Operator rule: Gap < 3 = No Trade. Gap \u2265 3 = Candidate Pair, continue to PMTS technical analysis. This tab selects WHICH pair to study \u2014 it does not authorize a trade.")));
}
window.EconomyScreen = EconomyScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/EconomyScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/HistoryScreen.jsx
try { (() => {
const {
  Badge
} = window.PumallenOSDesignSystem_ac653c;
function HistoryScreen() {
  const items = [{
    date: '2026-08-03',
    tf: 'H1',
    verdict: 'execute',
    summary: 'Sweep + BOS + pullback at 1.0862'
  }, {
    date: '2026-08-01',
    tf: 'D',
    verdict: 'stand-down',
    summary: 'Daily conflicted with weekly plan'
  }, {
    date: '2026-07-29',
    tf: 'H1',
    verdict: 'execute',
    summary: 'Clean London session entry'
  }];
  const [filter, setFilter] = React.useState('all');
  const filtered = items.filter(it => filter === 'all' ? true : it.verdict === filter);
  function exportSummary() {
    const text = filtered.map(it => `${it.date} · ${it.tf} · ${it.verdict === 'execute' ? 'EXECUTE' : 'STAND DOWN'} — ${it.summary}`).join('\n');
    navigator.clipboard && navigator.clipboard.writeText(text).catch(() => {});
    alert('History summary copied to clipboard:\n\n' + text);
  }
  const FILTERS = [{
    id: 'all',
    label: 'All'
  }, {
    id: 'execute',
    label: 'Execute'
  }, {
    id: 'stand-down',
    label: 'Stand Down'
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      bottom: 64,
      overflowY: 'auto',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent-primary)',
      fontSize: 18,
      fontWeight: 800,
      marginBottom: 2
    }
  }, "Analysis History \uD83D\uDD50"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      marginBottom: 12
    }
  }, "Past PMTS chart analyses, saved automatically"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 6,
      marginBottom: 12
    }
  }, FILTERS.map(f => /*#__PURE__*/React.createElement("button", {
    key: f.id,
    onClick: () => setFilter(f.id),
    style: {
      flex: 1,
      padding: '7px 8px',
      borderRadius: 8,
      fontSize: 11,
      fontWeight: 700,
      cursor: 'pointer',
      background: filter === f.id ? 'var(--accent-primary)' : 'var(--bg-surface-alt)',
      color: filter === f.id ? '#0a0800' : 'var(--text-muted)',
      border: '1px solid var(--border-default)'
    }
  }, f.label)), /*#__PURE__*/React.createElement("button", {
    onClick: exportSummary,
    style: {
      padding: '7px 10px',
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 8,
      color: 'var(--text-muted)',
      fontSize: 14,
      cursor: 'pointer'
    }
  }, "\uD83D\uDCCB")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, filtered.map((it, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-default)',
      borderRadius: 10,
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 6
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)'
    }
  }, it.date, " \xB7 ", it.tf), /*#__PURE__*/React.createElement(Badge, {
    tone: it.verdict === 'execute' ? 'green' : 'red'
  }, it.verdict === 'execute' ? 'EXECUTE' : 'STAND DOWN')), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-dim)',
      lineHeight: 1.5
    }
  }, it.summary))), filtered.length === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-muted)',
      textAlign: 'center',
      padding: 20
    }
  }, "No entries match this filter.")));
}
window.HistoryScreen = HistoryScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/HistoryScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/JournalScreen.jsx
try { (() => {
const {
  TextField,
  Select
} = window.PumallenOSDesignSystem_ac653c;
const JR_CHAINS = ['BA', 'LM', 'INF', 'CON', 'GRO', 'CB'];
const JR_CORE = ['BA', 'LM', 'INF'];
const JR_SUPPORT = ['CON', 'GRO', 'CB'];
const JR_SCORE = {
  Strong: 1,
  Mixed: 0,
  Weak: -1
};
const JR_USD_ORDER = ['EUR', 'GBP', 'AUD', 'NZD'];
function jrPairSymbol(a, b) {
  if (a === 'USD' && JR_USD_ORDER.includes(b)) return b + 'USD';
  if (b === 'USD' && JR_USD_ORDER.includes(a)) return a + 'USD';
  if (a === 'USD') return 'USD' + b;
  if (b === 'USD') return 'USD' + a;
  return a + b;
}
function computeEconomyCandidate(economy) {
  if (!economy || !economy.data) return null;
  const month = economy.reportingMonth || 'Jul';
  const results = Object.keys(economy.data).map(c => {
    const cd = economy.data[c];
    let total = 0;
    const complete = {};
    JR_CHAINS.forEach(id => {
      total += JR_SCORE[cd[id].thesis];
      const anchors = cd[id].anchors || [];
      const monthAnchors = anchors.filter(a => a.date && a.date.slice(0, 3) === month);
      const answered = monthAnchors.filter(a => a.verdict);
      complete[id] = monthAnchors.length > 0 && answered.length === monthAnchors.length;
    });
    const eligible = JR_CORE.every(id => complete[id]) && JR_SUPPORT.some(id => complete[id]);
    return {
      c,
      total,
      eligible
    };
  }).filter(r => r.eligible).sort((a, b) => b.total - a.total);
  if (results.length < 2) return null;
  const strongest = results[0],
    weakest = results[results.length - 1];
  const gap = strongest.total - weakest.total;
  if (gap < 3) return null;
  return {
    pairSymbol: jrPairSymbol(strongest.c, weakest.c),
    strongest: strongest.c,
    weakest: weakest.c,
    gap
  };
}
function JournalScreen(props) {
  const {
    journal,
    setJournal,
    pair,
    economy
  } = props;
  const candidate = computeEconomyCandidate(economy);
  const [linkEconomy, setLinkEconomy] = React.useState(false);
  const [dir, setDir] = React.useState('Long');
  const [date, setDate] = React.useState('');
  const [entry, setEntry] = React.useState('');
  const [sl, setSl] = React.useState('');
  const [tp, setTp] = React.useState('');
  const [result, setResult] = React.useState('Open');
  function add() {
    if (!entry.trim()) return;
    const source = linkEconomy && candidate ? `Economic Ranking: ${candidate.strongest}/${candidate.weakest} (gap ${candidate.gap})` : null;
    setJournal([{
      dir,
      date: date || new Date().toISOString().slice(0, 10),
      entry,
      sl,
      tp,
      result,
      pair: pair || 'EURUSD',
      source
    }, ...journal]);
    setDate('');
    setEntry('');
    setSl('');
    setTp('');
    setResult('Open');
    setLinkEconomy(false);
  }
  function remove(i) {
    setJournal(journal.filter((_, j) => j !== i));
  }
  function updateResult(i, val) {
    setJournal(journal.map((e, j) => j === i ? {
      ...e,
      result: val
    } : e));
  }
  function exportSummary() {
    const text = journal.map(e => `${e.date} · ${e.dir} · Entry ${e.entry} SL ${e.sl} TP ${e.tp} · ${e.result}`).join('\n');
    navigator.clipboard && navigator.clipboard.writeText(text).catch(() => {});
    alert('Journal summary copied to clipboard:\n\n' + text);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      bottom: 64,
      overflowY: 'auto',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent-primary)',
      fontSize: 18,
      fontWeight: 800,
      marginBottom: 2
    }
  }, "Trade Journal \uD83D\uDCD2"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      marginBottom: 14
    }
  }, "Log every trade per PMTS governance \xB7 new entries tagged ", pair || 'EURUSD'), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 12,
      padding: 14,
      marginBottom: 14,
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(Select, {
    options: ['Long', 'Short'],
    value: dir,
    onChange: e => setDir(e.target.value)
  }), /*#__PURE__*/React.createElement(TextField, {
    placeholder: "Date",
    value: date,
    onChange: e => setDate(e.target.value)
  })), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement(TextField, {
    placeholder: "Entry",
    value: entry,
    onChange: e => setEntry(e.target.value)
  }), /*#__PURE__*/React.createElement(TextField, {
    placeholder: "SL",
    value: sl,
    onChange: e => setSl(e.target.value)
  }), /*#__PURE__*/React.createElement(TextField, {
    placeholder: "TP",
    value: tp,
    onChange: e => setTp(e.target.value)
  })), /*#__PURE__*/React.createElement(Select, {
    options: ['Open', 'Win', 'Loss', 'Breakeven'],
    value: result,
    onChange: e => setResult(e.target.value)
  }), /*#__PURE__*/React.createElement(TextField, {
    type: "textarea",
    placeholder: "Notes..."
  }), candidate && /*#__PURE__*/React.createElement("label", {
    style: {
      display: 'flex',
      alignItems: 'center',
      gap: 8,
      fontSize: 11,
      color: 'var(--text-muted)',
      cursor: 'pointer'
    }
  }, /*#__PURE__*/React.createElement("input", {
    type: "checkbox",
    checked: linkEconomy,
    onChange: e => setLinkEconomy(e.target.checked)
  }), "\uD83C\uDF10 Tag with current Economic Ranking pick (", candidate.strongest, "/", candidate.weakest, ", gap ", candidate.gap, ")"), /*#__PURE__*/React.createElement("button", {
    onClick: add,
    style: {
      width: '100%',
      marginTop: 2,
      padding: 11,
      background: 'var(--accent-primary)',
      border: 'none',
      borderRadius: 10,
      color: '#0a0800',
      fontWeight: 800,
      fontSize: 13,
      cursor: 'pointer'
    }
  }, "+ Add Entry")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'flex-end',
      marginBottom: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: exportSummary,
    style: {
      padding: '7px 12px',
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 8,
      color: 'var(--text-muted)',
      fontSize: 11,
      fontWeight: 700,
      cursor: 'pointer'
    }
  }, "\uD83D\uDCCB Export Summary")), journal.map((e, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-default)',
      borderRadius: 10,
      padding: 12,
      marginBottom: 8,
      fontSize: 12,
      color: 'var(--text-dim)',
      fontFamily: 'var(--font-mono)'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 4
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-hi)',
      fontWeight: 700
    }
  }, e.dir, " \xB7 ", e.pair || 'EURUSD', " \xB7 ", e.date), /*#__PURE__*/React.createElement("button", {
    onClick: () => remove(i),
    style: {
      background: 'none',
      border: 'none',
      color: 'var(--text-muted)',
      cursor: 'pointer',
      fontSize: 13,
      padding: 2
    }
  }, "\uD83D\uDDD1\uFE0F")), e.source && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--accent-primary)',
      marginBottom: 4
    }
  }, "\uD83C\uDF10 ", e.source), "Entry ", e.entry, " \xB7 SL ", e.sl, " \xB7 TP ", e.tp, " \xB7", ' ', /*#__PURE__*/React.createElement("select", {
    value: e.result,
    onChange: ev => updateResult(i, ev.target.value),
    style: {
      background: 'transparent',
      border: 'none',
      fontFamily: 'var(--font-mono)',
      fontSize: 12,
      fontWeight: 700,
      cursor: 'pointer',
      color: e.result === 'Win' ? 'var(--accent-success)' : e.result === 'Loss' ? 'var(--accent-danger)' : 'var(--text-muted)'
    }
  }, /*#__PURE__*/React.createElement("option", {
    value: "Open"
  }, "Open"), /*#__PURE__*/React.createElement("option", {
    value: "Win"
  }, "Win"), /*#__PURE__*/React.createElement("option", {
    value: "Loss"
  }, "Loss"), /*#__PURE__*/React.createElement("option", {
    value: "Breakeven"
  }, "Breakeven")))));
}
window.JournalScreen = JournalScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/JournalScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/NarrativeScreen.jsx
try { (() => {
function NarrativeScreen(props) {
  const {
    narrative,
    setNarrative
  } = props;
  const [text, setText] = React.useState('');
  const [saving, setSaving] = React.useState(false);
  async function save() {
    if (!text.trim()) return;
    setSaving(true);
    let tag = '';
    try {
      tag = await window.claude.complete('Summarize this trading market narrative in 5 words or fewer, no punctuation at the end:\n\n' + text);
    } catch (e) {}
    setNarrative([{
      date: new Date().toISOString().slice(0, 10),
      body: text,
      tag: tag.trim()
    }, ...narrative]);
    setText('');
    setSaving(false);
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      bottom: 64,
      overflowY: 'auto',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent-primary)',
      fontSize: 18,
      fontWeight: 800,
      marginBottom: 2
    }
  }, "Market Narrative \uD83D\uDCDD"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      marginBottom: 12
    }
  }, "Freeform session notes and market read"), /*#__PURE__*/React.createElement("textarea", {
    value: text,
    onChange: e => setText(e.target.value),
    placeholder: "Today's market narrative...",
    style: {
      width: '100%',
      minHeight: 120,
      padding: 12,
      background: 'var(--bg-surface-alt)',
      border: '1.5px solid var(--border-gold)',
      borderRadius: 10,
      color: 'var(--text-hi)',
      fontSize: 13,
      boxSizing: 'border-box',
      fontFamily: 'var(--font-body)'
    }
  }), /*#__PURE__*/React.createElement("button", {
    onClick: save,
    disabled: saving,
    style: {
      width: '100%',
      marginTop: 10,
      padding: 11,
      background: 'var(--accent-primary)',
      border: 'none',
      borderRadius: 10,
      color: '#0a0800',
      fontWeight: 800,
      fontSize: 13,
      cursor: saving ? 'default' : 'pointer',
      opacity: saving ? .6 : 1
    }
  }, saving ? 'Saving…' : '💾 Save Entry'), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 8
    }
  }, narrative.map((e, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-default)',
      borderRadius: 10,
      padding: 12
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      justifyContent: 'space-between',
      alignItems: 'center',
      marginBottom: 5
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)',
      fontFamily: 'var(--font-mono)'
    }
  }, e.date), e.tag && /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 9,
      color: 'var(--accent-primary)',
      fontFamily: 'var(--font-mono)',
      fontWeight: 700,
      textTransform: 'uppercase'
    }
  }, e.tag)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 12,
      color: 'var(--text-dim)',
      lineHeight: 1.6
    }
  }, e.body)))));
}
window.NarrativeScreen = NarrativeScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/NarrativeScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/PlannerScreen.jsx
try { (() => {
const {
  TextField
} = window.PumallenOSDesignSystem_ac653c;
function PlannerScreen() {
  const [current, setCurrent] = React.useState('256.63');
  const [target, setTarget] = React.useState('500');
  const [monthly, setMonthly] = React.useState('125');
  const [result, setResult] = React.useState(null);
  function calc() {
    const c = parseFloat(current),
      t = parseFloat(target),
      m = parseFloat(monthly);
    if (!t || !m) return;
    const remaining = Math.max(t - (c || 0), 0);
    const months = Math.ceil(remaining / m);
    setResult({
      months,
      remaining: remaining.toFixed(2)
    });
  }
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      bottom: 64,
      overflowY: 'auto',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent-primary)',
      fontSize: 18,
      fontWeight: 800,
      marginBottom: 2
    }
  }, "Funding Planner \uD83C\uDFAF"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      marginBottom: 16
    }
  }, "Track progress toward your PMTS Level ceiling"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 12,
      padding: 16,
      display: 'flex',
      flexDirection: 'column',
      gap: 10
    }
  }, /*#__PURE__*/React.createElement(TextField, {
    label: "Current Balance ($)",
    type: "number",
    placeholder: "256.63",
    value: current,
    onChange: e => setCurrent(e.target.value)
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Level Ceiling Target ($)",
    type: "number",
    placeholder: "500",
    value: target,
    onChange: e => setTarget(e.target.value)
  }), /*#__PURE__*/React.createElement(TextField, {
    label: "Planned Monthly Funding ($)",
    type: "number",
    placeholder: "125",
    value: monthly,
    onChange: e => setMonthly(e.target.value)
  }), /*#__PURE__*/React.createElement("button", {
    onClick: calc,
    style: {
      width: '100%',
      padding: 12,
      background: 'var(--accent-primary)',
      border: 'none',
      borderRadius: 10,
      color: '#0a0800',
      fontWeight: 800,
      fontSize: 13,
      cursor: 'pointer'
    }
  }, "Calculate Timeline"), result && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: 12,
      background: 'rgba(0,0,0,.4)',
      borderRadius: 10,
      border: '1px solid var(--border-default)',
      fontSize: 12,
      lineHeight: 1.75,
      color: 'var(--text-dim)',
      fontFamily: 'var(--font-mono)'
    }
  }, "Remaining: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--accent-primary)'
    }
  }, "$", result.remaining), /*#__PURE__*/React.createElement("br", null), "Est. timeline: ", /*#__PURE__*/React.createElement("b", {
    style: {
      color: 'var(--accent-primary)'
    }
  }, result.months, " month", result.months === 1 ? '' : 's'))));
}
window.PlannerScreen = PlannerScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/PlannerScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/SettingsScreen.jsx
try { (() => {
function SettingsScreen(props) {
  const {
    resetAll,
    accent,
    setAccent,
    pair,
    setPair
  } = props;
  const [key, setKey] = React.useState('');
  const [status, setStatus] = React.useState('');
  const [confirmReset, setConfirmReset] = React.useState(false);
  const ACCENTS = [{
    id: 'gold',
    label: 'Gold',
    c: '#f0c040'
  }, {
    id: 'silver',
    label: 'Silver',
    c: '#c7cdd6'
  }, {
    id: 'green',
    label: 'Green',
    c: '#00e87a'
  }];
  const PAIRS = ['EURUSD', 'GBPUSD', 'USDJPY', 'AUDUSD', 'USDCHF'];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      bottom: 64,
      overflowY: 'auto',
      padding: '20px 16px'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent-primary)',
      fontSize: 18,
      fontWeight: 800,
      marginBottom: 12
    }
  }, "Settings \u2699\uFE0F"), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--surface-gold-tint)',
      border: '1px solid var(--border-gold)',
      borderRadius: 10,
      padding: '10px 12px',
      fontSize: 11,
      color: 'var(--accent-primary)',
      lineHeight: 1.5,
      marginBottom: 14
    }
  }, "\uD83E\uDDEA AI Chat and chart analysis call Claude live in this demo. The key field below is cosmetic only \u2014 no key is sent anywhere."), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 12,
      padding: 16,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-hi)',
      fontSize: 14,
      fontWeight: 700,
      marginBottom: 6
    }
  }, "Currency Pair"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      lineHeight: 1.5,
      marginBottom: 10
    }
  }, "The source app is EURUSD-only \u2014 other pairs are an intentional addition, used for the topbar label and Calculator's pip value."), /*#__PURE__*/React.createElement("select", {
    value: pair,
    onChange: e => setPair(e.target.value),
    style: {
      width: '100%',
      padding: '11px 13px',
      background: 'var(--bg-page)',
      border: '1.5px solid var(--border-gold)',
      borderRadius: 10,
      color: 'var(--text-hi)',
      fontFamily: 'var(--font-mono)',
      fontSize: 13
    }
  }, PAIRS.map(p => /*#__PURE__*/React.createElement("option", {
    key: p,
    value: p
  }, p)))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 12,
      padding: 16,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-hi)',
      fontSize: 14,
      fontWeight: 700,
      marginBottom: 10
    }
  }, "Accent Color"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, ACCENTS.map(a => /*#__PURE__*/React.createElement("button", {
    key: a.id,
    onClick: () => setAccent(a.id),
    style: {
      flex: 1,
      padding: '10px 8px',
      borderRadius: 10,
      cursor: 'pointer',
      display: 'flex',
      flexDirection: 'column',
      alignItems: 'center',
      gap: 6,
      background: accent === a.id ? 'var(--bg-page)' : 'transparent',
      border: '1.5px solid ' + (accent === a.id ? a.c : 'var(--border-default)')
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      width: 20,
      height: 20,
      borderRadius: '50%',
      background: a.c
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10,
      color: accent === a.id ? a.c : 'var(--text-muted)',
      fontWeight: 700
    }
  }, a.label))))), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-default)',
      borderRadius: 12,
      padding: 16,
      marginBottom: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-hi)',
      fontSize: 14,
      fontWeight: 700,
      marginBottom: 6
    }
  }, "Anthropic API Key"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 12,
      lineHeight: 1.5,
      marginBottom: 12
    }
  }, "Required to run chart analysis. Your key is stored only on this device \u2014 never sent anywhere except directly to Anthropic's API."), /*#__PURE__*/React.createElement("input", {
    type: "password",
    value: key,
    onChange: e => setKey(e.target.value),
    placeholder: "sk-ant-...",
    style: {
      width: '100%',
      padding: '11px 13px',
      background: 'var(--bg-page)',
      border: '1.5px solid var(--border-gold)',
      borderRadius: 10,
      color: 'var(--text-hi)',
      fontFamily: 'var(--font-mono)',
      fontSize: 13,
      marginBottom: 10,
      boxSizing: 'border-box'
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => setStatus('Saved ✓'),
    style: {
      flex: 1,
      padding: '11px 14px',
      background: 'var(--accent-primary)',
      border: 'none',
      borderRadius: 10,
      color: '#0a0800',
      fontWeight: 700,
      fontSize: 13,
      cursor: 'pointer'
    }
  }, "\uD83D\uDCBE Save Key"), /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      setKey('');
      setStatus('Cleared');
    },
    style: {
      padding: '11px 14px',
      background: 'var(--bg-surface)',
      border: '1.5px solid var(--border-default)',
      borderRadius: 10,
      color: 'var(--text-muted)',
      fontWeight: 700,
      fontSize: 13,
      cursor: 'pointer'
    }
  }, "\uD83D\uDDD1\uFE0F Clear")), status && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 10,
      fontSize: 12,
      fontWeight: 600,
      color: 'var(--accent-success)'
    }
  }, status)), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      lineHeight: 1.6,
      padding: '0 4px',
      marginBottom: 20
    }
  }, "Don't have a key? Create one at ", /*#__PURE__*/React.createElement("span", {
    style: {
      color: 'var(--accent-primary)'
    }
  }, "console.anthropic.com"), " under API Keys."), /*#__PURE__*/React.createElement("div", {
    style: {
      background: 'var(--bg-surface-alt)',
      border: '1px solid var(--border-red)',
      borderRadius: 12,
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-hi)',
      fontSize: 14,
      fontWeight: 700,
      marginBottom: 6
    }
  }, "Reset App Data"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 12,
      lineHeight: 1.5,
      marginBottom: 12
    }
  }, "Clears checklist state, journal entries, chat history, narrative notes and analysis progress."), !confirmReset ? /*#__PURE__*/React.createElement("button", {
    onClick: () => setConfirmReset(true),
    style: {
      width: '100%',
      padding: '11px 14px',
      background: 'transparent',
      border: '1.5px solid var(--accent-danger)',
      borderRadius: 10,
      color: 'var(--accent-danger)',
      fontWeight: 700,
      fontSize: 13,
      cursor: 'pointer'
    }
  }, "\uD83D\uDDD1\uFE0F Reset All App Data") : /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'flex',
      gap: 8
    }
  }, /*#__PURE__*/React.createElement("button", {
    onClick: () => {
      resetAll();
      setConfirmReset(false);
    },
    style: {
      flex: 1,
      padding: '11px 14px',
      background: 'var(--accent-danger)',
      border: 'none',
      borderRadius: 10,
      color: '#fff',
      fontWeight: 700,
      fontSize: 13,
      cursor: 'pointer'
    }
  }, "Confirm Reset"), /*#__PURE__*/React.createElement("button", {
    onClick: () => setConfirmReset(false),
    style: {
      padding: '11px 14px',
      background: 'var(--bg-surface)',
      border: '1.5px solid var(--border-default)',
      borderRadius: 10,
      color: 'var(--text-muted)',
      fontWeight: 700,
      fontSize: 13,
      cursor: 'pointer'
    }
  }, "Cancel"))));
}
window.SettingsScreen = SettingsScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/SettingsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/StatsScreen.jsx
try { (() => {
function StatsScreen(props) {
  const {
    journal
  } = props;
  const total = journal.length;
  const wins = journal.filter(e => e.result === 'Win').length;
  const losses = journal.filter(e => e.result === 'Loss').length;
  const decided = wins + losses;
  const winRate = decided ? Math.round(wins / decided * 100) + '%' : '—';
  let streak = 0,
    bestStreak = 0,
    cur = 0;
  journal.slice().reverse().forEach(e => {
    if (e.result === 'Win') {
      cur++;
      bestStreak = Math.max(bestStreak, cur);
    } else if (e.result === 'Loss') {
      cur = 0;
    }
  });
  const stats = [{
    l: 'Total Trades',
    v: String(total)
  }, {
    l: 'Win Rate',
    v: winRate
  }, {
    l: 'Wins / Losses',
    v: wins + ' / ' + losses
  }, {
    l: 'Best Streak',
    v: bestStreak + ' wins'
  }, {
    l: 'Open Trades',
    v: String(journal.filter(e => e.result === 'Open').length)
  }, {
    l: 'Breakevens',
    v: String(journal.filter(e => e.result === 'Breakeven').length)
  }];
  return /*#__PURE__*/React.createElement("div", {
    style: {
      position: 'absolute',
      top: 58,
      left: 0,
      right: 0,
      bottom: 64,
      overflowY: 'auto',
      padding: 16
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--accent-primary)',
      fontSize: 18,
      fontWeight: 800,
      marginBottom: 2
    }
  }, "Stats \uD83D\uDCCA"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: 'var(--text-muted)',
      fontSize: 11,
      marginBottom: 14
    }
  }, "Computed live from your Journal entries"), /*#__PURE__*/React.createElement("div", {
    style: {
      display: 'grid',
      gridTemplateColumns: '1fr 1fr',
      gap: 8
    }
  }, stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: {
      background: 'var(--bg-surface)',
      border: '1px solid var(--border-default)',
      borderRadius: 12,
      padding: 14
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 20,
      fontWeight: 800,
      color: 'var(--text-hi)',
      fontFamily: 'var(--font-mono)'
    }
  }, s.v), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 10,
      color: 'var(--text-muted)',
      marginTop: 4
    }
  }, s.l)))), total === 0 && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 16,
      fontSize: 12,
      color: 'var(--text-muted)',
      textAlign: 'center',
      padding: 20
    }
  }, "Log trades in the Journal to see stats here."));
}
window.StatsScreen = StatsScreen;
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/StatsScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/pumallen-os/image-slot.js
try { (() => {
// @ds-adherence-ignore -- omelette starter scaffold (raw elements/hex/px by design)
// Copied omelette starter. Re-running copy_starter_component with this kind overwrites this file with the latest version (page content is unaffected).
/* BEGIN USAGE */
/**
 * <image-slot> — user-fillable image placeholder.
 *
 * Drop this into a deck, mockup, or page wherever a design needs an image.
 * You control the slot's shape; it sizes to its container by default. When the search_stock_photos tool
 * is available, prefill the slot by default — write the photo's URL into
 * src (with credit/credit-href); the user can still fill or replace it
 * by dragging an image file onto it (or clicking to browse). The dropped
 * image persists across reloads via a .image-slots.state.json sidecar —
 * same read-via-fetch / write-via-window.omelette pattern as
 * design_canvas.jsx, so the filled slot shows on share links, downloaded
 * zips, and PPTX export. Outside the omelette runtime the slot is read-only.
 *
 * The sidecar is a SIBLING of the HTML file that uses this component: the
 * read is a document-relative fetch, and the host resolves the bridge's
 * sidecar writes into the previewed file's directory to match (same
 * contract as design_canvas.jsx). Pages in the same directory share one
 * sidecar; keep slot ids distinct across them.
 *
 * Attributes:
 *   id           Persistence key. REQUIRED for the drop to survive reload —
 *                every slot on the page needs a distinct id.
 *   shape        'rect' | 'rounded' | 'circle' | 'pill'   (default 'rounded')
 *                'circle' applies 50% border-radius; on a non-square slot
 *                that's an ellipse — set equal width and height for a true
 *                circle.
 *   radius       Corner radius in px for 'rounded'.       (default 12)
 *   mask         Any CSS clip-path value. Overrides `shape` — use this for
 *                hexagons, blobs, arbitrary polygons.
 *   fit          Initial framing baseline: cover | contain.   (default 'cover')
 *                cover starts the image filling the frame (overflow cropped);
 *                contain starts it fully visible (letterboxed). Either way the
 *                user can always pan/scale from there — double-click, or the
 *                Edit control, enters reframe mode (drag to move, scroll or
 *                corner-handles to scale; Escape / click-out commits). The
 *                crop persists alongside the image in the sidecar.
 *   placeholder  Empty-state caption.                      (default 'Drop an image')
 *   src          Optional initial/fallback image URL. Prefill it with a real
 *                photo via search_stock_photos when that tool is available
 *                (set credit/credit-href from the result). A user drop
 *                overrides it; clearing the drop reveals src again.
 *   credit       Attribution text shown as a small overlay at the
 *                bottom-left of the filled slot. REQUIRED whenever src
 *                points at any Unsplash host (images.unsplash.com,
 *                plus.unsplash.com, …): an Unsplash src with no credit
 *                renders an error tile INSTEAD of the photo (Unsplash
 *                terms forbid showing their photos unattributed). Use the
 *                exact form 'Photo by {photographer name} on Unsplash' —
 *                the overlay then links the name to credit-href and
 *                'Unsplash' to the Unsplash homepage, and links back to
 *                unsplash.com automatically get the required utm referral
 *                params appended at render time. The credit belongs to
 *                the src image, so it only shows while src is what's
 *                displayed — a user-dropped image hides it.
 *   credit-href  Link for the photographer's name in the credit overlay
 *                (their Unsplash profile URL from the stock-photo search
 *                results). http(s) URLs only — anything else renders the
 *                name as plain text.
 *
 * Sizing: the slot fills its container by default (width/height 100%).
 * Put it in a sized wrapper — absolutely positioned, a grid cell, a fixed
 * frame — and it takes exactly that box. When the parent's height is
 * indefinite (ordinary flow), it falls back to full width at a 3:2 aspect
 * ratio instead of collapsing. In a shrink-to-fit parent (a float,
 * width:max-content, an unsized absolute wrapper), percentages have
 * nothing to resolve against — size the slot or its wrapper explicitly
 * there. For a fixed-size slot, set
 * width/height on the element itself (inline style), which overrides the
 * default. When
 * layering content above a slot (full-bleed layouts), make the overlay
 * click-through — pointer-events: none on scrims/text plates, re-enabled
 * on interactive children — so the slot's hover controls stay reachable.
 * Keep the slot's bottom-left corner visually clear as well: the credit
 * overlay renders there, and a dark fade or text plate covering it hides
 * the attribution Unsplash's terms require — end the fade above that
 * corner, or keep it nearly transparent where the credit sits.
 *
 * Usage:
 *   <div style="position:relative;width:100%;height:100%">      <!-- full-bleed: -->
 *     <image-slot id="bg" shape="rect"></image-slot>            <!-- fills the wrapper -->
 *   </div>
 *   <image-slot id="hero"   style="width:800px;height:450px" shape="rounded" radius="20"
 *               placeholder="Drop a hero image"></image-slot>
 *   <image-slot id="avatar" style="width:120px;height:120px" shape="circle"></image-slot>
 *   <image-slot id="kite"   style="width:300px;height:300px"
 *               mask="polygon(50% 0, 100% 50%, 50% 100%, 0 50%)"></image-slot>
 */
/* END USAGE */

(() => {
  const STATE_FILE = '.image-slots.state.json';

  // Unsplash terms require visible attribution wherever their photos
  // display, and every link back to unsplash.com must carry utm referral
  // params. Two render-time rules enforce that here:
  //  - an Unsplash-src slot with NO credit attribute renders an error
  //    tile INSTEAD of the photo (an uncredited Unsplash photo on screen
  //    is itself the terms violation, so it never renders bare);
  //  - rendered credit links pointing at unsplash.com get the referral
  //    params appended when absent (credit-href values live in page
  //    content that can't be edited after the fact).
  // Keep the utm_source value in sync with UTM_SOURCE in
  // platform/web-agent/unsplash.ts — this file is a project-local
  // artifact and cannot import it (equality is pinned by tests).
  const UNSPLASH_HOMEPAGE_HREF = 'https://unsplash.com/?utm_source=claude_design&utm_medium=referral';
  // Host rule mirrors the hotlink validator that admits Unsplash srcs into
  // pages in the first place (cdn$ in unsplash.ts: apex or any subdomain)
  // — Unsplash+ results serve from plus.unsplash.com, not just images.*,
  // and an admitted-but-uncredited photo must error whatever unsplash
  // host it rides on.
  // Trailing-dot FQDNs (images.unsplash.com.) are the same host to the
  // browser but would miss the regex — strip one dot so the check fails
  // CLOSED (unrecognized-but-real Unsplash srcs must error, not render).
  const isUnsplashHost = u => {
    try {
      return /(^|\.)unsplash\.com$/.test(new URL(u, document.baseURI).hostname.replace(/\.$/, ''));
    } catch {
      return false;
    }
  };
  // Render-time referral normalization for links back to Unsplash:
  // appends utm_source/utm_medium when absent, preserves every existing
  // query param, never overwrites an existing utm_source, and passes
  // non-Unsplash URLs through untouched. Input is an ABSOLUTE validated
  // http(s) URL (the credit render funnel resolves + validates first).
  const withReferral = href => {
    try {
      const u = new URL(href);
      if (!/(^|\.)unsplash\.com$/.test(u.hostname.replace(/\.$/, ''))) {
        return href;
      }
      if (!u.searchParams.has('utm_source')) {
        u.searchParams.set('utm_source', 'claude_design');
      }
      if (!u.searchParams.has('utm_medium')) {
        u.searchParams.set('utm_medium', 'referral');
      }
      return u.toString();
    } catch (e) {
      return href;
    }
  };
  // 2× a ~600px slot in a 1920-wide deck — retina-sharp without making the
  // sidecar enormous. A 1200px WebP at q=0.85 is ~150-300KB.
  const MAX_DIM = 1200;
  // Raster formats only. SVG is excluded (can carry script; createImageBitmap
  // on SVG blobs is inconsistent). GIF is excluded because the canvas
  // re-encode keeps only the first frame, so an animated GIF would silently
  // go still — better to reject than surprise.
  const ACCEPT = ['image/png', 'image/jpeg', 'image/webp', 'image/avif'];

  // ── Shared sidecar store ────────────────────────────────────────────────
  // One fetch + immediate write-on-change for every <image-slot> on the
  // page. Reads via fetch() so viewing works anywhere the HTML and sidecar
  // are served together; writes go through window.omelette.writeFile, which
  // the host allowlists to *.state.json basenames only.
  const subs = new Set();
  let slots = {};
  // ids explicitly cleared before the sidecar fetch resolved — otherwise
  // the merge below can't tell "never set" from "just deleted" and would
  // resurrect the sidecar's stale value.
  const tombstones = new Set();
  let loaded = false;
  let loadP = null;
  function load() {
    if (loadP) return loadP;
    loadP = fetch(STATE_FILE).then(r => r.ok ? r.json() : null).then(j => {
      // Merge: sidecar loses to any in-memory change that raced ahead of
      // the fetch (drop or clear) so neither is clobbered by hydration.
      if (j && typeof j === 'object') {
        const merged = Object.assign({}, j, slots);
        // A framing-only write that raced ahead of hydration must not
        // drop a user image that's only on disk — inherit u from the
        // sidecar for any in-memory entry that lacks one.
        for (const k in slots) {
          if (merged[k] && !merged[k].u && j[k]) {
            merged[k].u = typeof j[k] === 'string' ? j[k] : j[k].u;
          }
        }
        for (const id of tombstones) delete merged[id];
        slots = merged;
      }
      tombstones.clear();
    }).catch(() => {}).then(() => {
      loaded = true;
      subs.forEach(fn => fn());
    });
    return loadP;
  }

  // Serialize writes so two near-simultaneous drops on different slots
  // can't reorder at the backend and leave the sidecar with only the
  // first. A save requested mid-flight just marks dirty and re-fires on
  // completion with the then-current slots.
  let saving = false;
  let saveDirty = false;
  // Unload-time flush: save()'s serialization defers a mid-RTT re-fire to a
  // .then that never runs in an unloading document, silently dropping a
  // pagehide commit. Post the current slots immediately instead — content
  // is a superset snapshot of any in-flight save's, the write is a
  // whole-file last-writer-wins replace, and postMessage FIFO delivers it
  // to the host after the in-flight one, so a backend-side reorder at
  // worst reproduces the dropped-commit outcome this flush improves on.
  // Guarded on the initial sidecar read: pre-hydration slots can miss
  // other slots' persisted entries, and flushing it would clobber them —
  // that narrow case stays best-effort (the in-memory merge in load()
  // cannot happen in an unloading document anyway).
  function flushNow() {
    if (!loaded) return;
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    try {
      Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {});
    } catch (e) {}
  }
  function save() {
    if (saving) {
      saveDirty = true;
      return;
    }
    const w = window.omelette && window.omelette.writeFile;
    if (!w) return;
    saving = true;
    Promise.resolve(w(STATE_FILE, JSON.stringify(slots))).catch(() => {}).then(() => {
      saving = false;
      if (saveDirty) {
        saveDirty = false;
        save();
      }
    });
  }
  const S_MAX = 5;
  const clampS = s => Math.max(1, Math.min(S_MAX, s));

  // Normalize a stored slot value. Pre-reframe sidecars stored a bare
  // data-URL string; newer ones store {u, s, x, y}. Either shape is valid.
  function getSlot(id) {
    const v = slots[id];
    if (!v) return null;
    return typeof v === 'string' ? {
      u: v,
      s: 1,
      x: 0,
      y: 0
    } : v;
  }
  function setSlot(id, val) {
    if (!id) return;
    if (val) {
      slots[id] = val;
      tombstones.delete(id);
    } else {
      delete slots[id];
      if (!loaded) tombstones.add(id);
    }
    subs.forEach(fn => fn());
    // A drop is rare + high-value — write immediately so nav-away can't lose
    // it. Gate on the initial read so we don't overwrite a sidecar we haven't
    // merged yet; the merge in load() keeps this change once the read lands.
    if (loaded) save();else load().then(save);
  }

  // ── Image downscale ─────────────────────────────────────────────────────
  // Encode through a canvas so the sidecar carries resized bytes, not the
  // raw upload. Longest side is capped at 2× the slot's rendered width
  // (retina) and at MAX_DIM. WebP keeps alpha and is ~10× smaller than PNG
  // for photos, so there's no need for per-image format picking.
  async function toDataUrl(file, targetW) {
    const bitmap = await createImageBitmap(file);
    try {
      const cap = Math.min(MAX_DIM, Math.max(1, Math.round(targetW * 2)) || MAX_DIM);
      const scale = Math.min(1, cap / Math.max(bitmap.width, bitmap.height));
      const w = Math.max(1, Math.round(bitmap.width * scale));
      const h = Math.max(1, Math.round(bitmap.height * scale));
      const canvas = document.createElement('canvas');
      canvas.width = w;
      canvas.height = h;
      canvas.getContext('2d').drawImage(bitmap, 0, 0, w, h);
      return canvas.toDataURL('image/webp', 0.85);
    } finally {
      bitmap.close && bitmap.close();
    }
  }

  // ── Custom element ──────────────────────────────────────────────────────
  const stylesheet =
  // Fill the container by default: slots are usually placed inside a
  // sized wrapper (a hero frame, a grid cell, an inset:0 layer) and are
  // expected to take that box — a fixed intrinsic size would render as
  // a small tile in the corner of a full-bleed wrapper instead.
  // aspect-ratio is the companion fallback that keeps a bare slot
  // visible when the parent's height is indefinite: height:100%
  // resolves to auto there, and the ratio then derives height from
  // width instead of letting the slot collapse to zero height.
  // Explicit width/height on the element override all of this.
  // color:inherit (not a fixed near-black): the placeholder chrome —
  // empty-state icon/caption (currentColor) and the dashed ring — must
  // read on dark decks too, and the slide's own text color is the one
  // color guaranteed to contrast with the slide background. The soft
  // look comes from opacity on those parts, not from a baked-in alpha.
  ':host{display:block;position:relative;' + '  font:13px/1.3 system-ui,-apple-system,sans-serif;' + '  width:100%;height:100%;aspect-ratio:3/2}' + '.empty .cap,.empty .sub{opacity:.75}' + '.frame{position:absolute;inset:0;overflow:hidden;background:rgba(127,127,127,.08)}' +
  // .frame img (clipped) and .spill (unclipped ghost + handles) share the
  // same left/top/width/height in frame-%, computed by _applyView(), so the
  // inside-mask crop and the outside-mask spill stay pixel-aligned.
  '.frame img{position:absolute;max-width:none;transform:translate(-50%,-50%);' + '  -webkit-user-drag:none;user-select:none;touch-action:none}' +
  // Reframe mode (double-click): the full image spills past the mask. The
  // spill layer is sized to the IMAGE bounds so its corners are where the
  // resize handles belong. The ghost <img> inside is translucent; the real
  // clipped <img> underneath shows the opaque in-mask crop.
  // popover=manual promotes the spill to the top layer on reframe, so it is
  // not clipped by any overflow:hidden / clip-path / scroll-container
  // ancestor (a plain z-index can't escape overflow clipping). UA popover
  // defaults (inset:0;margin:auto) are reset; _applyView sets viewport px.
  '.spill{position:fixed;margin:0;inset:auto;border:0;padding:0;background:transparent;' + '  overflow:visible;transform:translate(-50%,-50%);z-index:1;cursor:grab;touch-action:none}' + ':host([data-panning]) .spill{cursor:grabbing}' + '.spill .ghost{position:absolute;inset:0;width:100%;height:100%;opacity:.35;' + '  pointer-events:none;-webkit-user-drag:none;user-select:none;' + '  box-shadow:0 0 0 1px rgba(0,0,0,.2),0 12px 32px rgba(0,0,0,.2)}' + '.spill .handle{position:absolute;width:12px;height:12px;border-radius:50%;' + '  background:#fff;box-shadow:0 0 0 1.5px #c96442,0 1px 3px rgba(0,0,0,.3);' + '  transform:translate(-50%,-50%)}' + '.spill .handle[data-c=nw]{left:0;top:0;cursor:nwse-resize}' + '.spill .handle[data-c=ne]{left:100%;top:0;cursor:nesw-resize}' + '.spill .handle[data-c=sw]{left:0;top:100%;cursor:nesw-resize}' + '.spill .handle[data-c=se]{left:100%;top:100%;cursor:nwse-resize}' + ':host([data-reframe]){z-index:10}' + ':host([data-reframe]) .frame{box-shadow:0 0 0 2px #c96442}' + '.empty{position:absolute;inset:0;display:flex;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  cursor:pointer;user-select:none}' + '.empty svg{opacity:.45}' + '.empty .cap{max-width:90%;font-weight:500;letter-spacing:.01em}' + '.empty .sub{font-size:11px}' + '.empty .sub u{text-underline-offset:2px}' + '.empty:hover .sub{opacity:1}' + ':host([data-over]) .frame{outline:2px solid #c96442;outline-offset:-2px;' + '  background:rgba(201,100,66,.10)}' + '.ring{position:absolute;inset:0;pointer-events:none;border:1.5px dashed currentColor;' + '  opacity:.35;transition:border-color .12s,opacity .12s}' + ':host([data-over]) .ring{border-color:#c96442;opacity:1}' + ':host([data-filled]) .ring{display:none}' +
  // Controls overlay INSIDE the frame, pinned to the top-right corner, so
  // a full-bleed slot in an overflow:hidden container still shows them
  // (the old below-mask placement got clipped). Credit sits bottom-left,
  // so top-right avoids collision. The blurred pill background keeps them
  // legible over the image.
  // The UA [popover] base rule styles the element in EVERY state (only
  // display:none is gated on :not(:popover-open), and the display:flex
  // below overrides that) — so the UA resets live HERE, like .spill's,
  // or the ordinary hover-state strip renders as a bordered Canvas box
  // centered by margin:auto. inset:auto precedes top/right (shorthand).
  '.ctl{position:absolute;inset:auto;top:8px;right:8px;margin:0;border:0;padding:0;' + '  background:transparent;overflow:visible;' + '  display:flex;gap:6px;opacity:0;pointer-events:none;transition:opacity .12s;z-index:2;' + '  white-space:nowrap}' +
  // While reframing, the spill owns the top layer and would swallow every
  // click on the in-frame controls. Promoting .ctl into the top layer
  // ABOVE the spill (shown after it — later popovers stack higher) keeps
  // Edit-as-toggle and Replace clickable mid-reframe. _applyView pins it
  // to the frame's top-right in viewport px (translateX(-100%)
  // right-aligns against the computed left edge); inset:auto clears the
  // base rule's top/right so the inline left/top position it alone.
  '.ctl:popover-open{position:fixed;inset:auto;transform:translateX(-100%)}' + ':host([data-filled][data-editable]:hover) .ctl,:host([data-reframe]) .ctl' + '  {opacity:1;pointer-events:auto}' + '.ctl button{appearance:none;border:0;border-radius:6px;padding:5px 10px;cursor:pointer;' + '  background:rgba(0,0,0,.65);color:#fff;font:11px/1 system-ui,-apple-system,sans-serif;' + '  backdrop-filter:blur(6px)}' + '.ctl button:hover{background:rgba(0,0,0,.8)}' + '.err{position:absolute;left:8px;bottom:8px;right:8px;color:#b3261e;font-size:11px;' + '  background:rgba(255,255,255,.85);padding:4px 6px;border-radius:5px;pointer-events:none}' +
  // Replacement in flight: after a src swap the browser keeps painting
  // the PREVIOUS image until the new one decodes, so a Replace would
  // flash the old photo and then pop. Hide the stale frame (visibility,
  // not display — _applyView geometry still applies) and spin until the
  // new image reports in (load/error clears data-swapping).
  ':host([data-swapping]) .frame img{visibility:hidden}' + '.loading{position:absolute;inset:0;display:none;align-items:center;' + '  justify-content:center;pointer-events:none}' + ':host([data-swapping]) .loading{display:flex}' + '.loading::after{content:"";width:22px;height:22px;border-radius:50%;' + '  border:2px solid rgba(127,127,127,.25);border-top-color:currentColor;' + '  animation:om-slot-spin .7s linear infinite}' + '@keyframes om-slot-spin{to{transform:rotate(360deg)}}' +
  // Reduced motion: the static two-tone ring still reads as "working".
  '@media (prefers-reduced-motion:reduce){.loading::after{animation:none}}' + '.credit{position:absolute;left:6px;bottom:6px;max-width:calc(100% - 12px);display:none;' + '  padding:3px 7px;border-radius:5px;background:rgba(0,0,0,.55);color:#fff;' + '  font:10px/1.2 system-ui,-apple-system,sans-serif;text-decoration:none;' + '  white-space:nowrap;overflow:hidden;text-overflow:ellipsis;backdrop-filter:blur(6px)}' +
  // The credit is a SPAN holding one or two <a>s (Unsplash's prescribed
  // form links the photographer AND Unsplash) — anchors style inline so
  // the overlay reads as one line of text.
  '.credit a{color:inherit;text-decoration:none}' + '.credit a:hover,.credit a:focus-visible{text-decoration:underline}' + ':host([data-filled][data-credit]) .credit{display:block}' +
  // Exports must ship JUST the image — no hover controls, no credit chip
  // (the host marks <html data-om-exporting> for the capture window; the
  // page-level hide script can't reach shadow DOM, this rule can).
  ':host-context([data-om-exporting]) .ctl,' + ':host-context([data-om-exporting]) .credit{display:none !important}' +
  // Print must ship just the image too: the hover-gated controls can be
  // mid-hover when print() fires, and the credit chip is screen chrome —
  // the same rule the capture window gets, keyed on print media instead
  // of the host's data-om-exporting mark (the print path sets no mark).
  '@media print{.ctl,.credit{display:none !important}}' +
  // No export-window mask rules here on purpose: the export capture
  // releases the replacement mask by REMOVING data-swapping (the
  // shadow-root pass in pages/export/shared.ts HIDE_EXPORT_CHROME_SCRIPT)
  // — attribute removal works in every engine (:host-context is
  // Chromium-only), is scoped by construction to slots actually
  // mid-swap, and hides the spinner through the same gate. A masked img
  // would otherwise be silently dropped from PPTX decks (the capture
  // walk skips visibility:hidden imgs).
  // Attribution error tile: REPLACES the photo when an Unsplash src has
  // no credit attribute — rendering the photo uncredited is the terms
  // violation, so the photo must not appear at all.
  // Calm and neutral on purpose (review feedback): the tile informs the
  // user; the fix instructions are machine-facing (usage docblock, tool
  // description, and the turn-end scan's bounce copy name the attributes
  // for the agent).
  '.attr-error{position:absolute;inset:0;display:none;flex-direction:column;align-items:center;' + '  justify-content:center;gap:6px;text-align:center;padding:12px;box-sizing:border-box;' + '  background:#f2f1ef;color:#6e6c66;user-select:none;' + '  font:13px/1.45 system-ui,-apple-system,sans-serif}' + '.attr-error svg{opacity:.55}' + '.attr-error .cap{max-width:92%;font-weight:500;letter-spacing:.01em}' + ':host([data-attribution-error]) .attr-error{display:flex}' + ':host([data-attribution-error]) .ring{display:none}';
  const icon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>' + '<path d="m21 15-5-5L5 21"/></svg>';
  const warnIcon = '<svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" ' + 'stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">' + '<path d="m21.73 18-8-14a2 2 0 0 0-3.46 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3"/>' + '<path d="M12 9v4"/><path d="M12 17h.01"/></svg>';
  class ImageSlot extends HTMLElement {
    static get observedAttributes() {
      return ['shape', 'radius', 'mask', 'fit', 'placeholder', 'src', 'id', 'credit', 'credit-href'];
    }

    /** Duplicate-slide hook (called by deck-stage, see its
     *  _remintDuplicateIds): copy this id's stored image, if any, under a
     *  freshly minted key and return that key — so a duplicated slide's
     *  slot keeps its dropped photo instead of reverting to the
     *  placeholder. 'isFree' is the caller's uniqueness check (document
     *  ids); candidates must ALSO be unused in the sidecar, which can
     *  hold keys from other pages sharing the project root. (An EMPTY
     *  slot on another page leaves no sidecar entry, so its id is not
     *  detectable here — a minted key can collide with it and that slot
     *  would show this photo. Same blast radius as two pages reusing an
     *  id by hand, which the shared sidecar already permits.) Returns null
     *  when no id could be minted (caller strips the id, today's
     *  behavior). */
    static cloneSlot(fromId, isFree) {
      if (typeof fromId !== 'string' || !fromId) return null;
      // Pre-hydration the store can't veto candidates or source the copy
      // — degrade to the strip (today's behavior) rather than mint
      // against keys we can't see yet. Any rendered (= droppable) slot
      // means load() has already settled.
      if (!loaded) return null;
      const stem = fromId.replace(/-\d+$/, '') || fromId;
      for (let n = 2; n < 100; n++) {
        const toId = stem + '-' + n;
        if (toId === fromId) continue;
        if (slots[toId] !== undefined) {
          // Reuse a key holding this exact value (bytes AND crop) if no
          // live element here owns it — a duplicate op the host refused
          // after minting leaves such a key behind, and reusing keeps
          // refused retries from accumulating one orphaned copy per
          // attempt. Full equality (not just bytes) so a byte-identical
          // key another PAGE owns with its own crop is stepped past, not
          // adopted or rewritten. (Entries without .u never match.)
          const prev = getSlot(toId);
          const cur = getSlot(fromId);
          if (!(prev && cur && prev.u && prev.u === cur.u && prev.s === cur.s && prev.x === cur.x && prev.y === cur.y && (typeof isFree !== 'function' || isFree(toId)))) continue;
          return toId;
        }
        if (typeof isFree === 'function' && !isFree(toId)) continue;
        const v = getSlot(fromId);
        if (v) setSlot(toId, Object.assign({}, v));
        return toId;
      }
      return null;
    }
    constructor() {
      super();
      // clonable: rail thumbnails deep-clone slides and carry this shadow
      // along; reuse an already-cloned root so upgrade-after-clone works.
      // (Deliberately NOT serializable — a getHTML consumer would embed
      // multi-MB sidecar data-URLs into serialized page HTML.)
      const root = this.shadowRoot || this.attachShadow({
        mode: 'open',
        clonable: true
      });
      // .spill and .ctl sit OUTSIDE .frame so overflow:hidden + border-radius
      // on the frame (circle, pill, rounded) can't clip them.
      root.innerHTML = '<style>' + stylesheet + '</style>' + '<div class="frame" part="frame">' + '  <img part="image" alt="" draggable="false" style="display:none">' + '  <div class="empty" part="empty">' + icon + '    <div class="cap"></div>' + '    <div class="sub">or <u>browse files</u></div></div>' + '  <div class="attr-error" part="attribution-error">' + warnIcon + '    <div class="cap">This photo needs attribution</div></div>' + '  <div class="loading" part="loading"></div>' + '  <div class="ring" part="ring"></div>' + '</div>' +
      // Outside .frame, like .spill/.ctl — the frame's overflow:hidden +
      // border-radius/clip-path would cut the credit off on circle/pill/mask.
      // A SPAN, not an <a>: the prescribed Unsplash credit holds two links
      // (photographer + Unsplash), built per-render in _render().
      '<span class="credit" part="credit"></span>' + '<div class="spill" popover="manual" data-dc-edit-transparent>' + '  <img class="ghost" alt="" draggable="false">' + '  <div class="handle" data-c="nw"></div><div class="handle" data-c="ne"></div>' + '  <div class="handle" data-c="sw"></div><div class="handle" data-c="se"></div>' + '</div>' +
      // data-dc-edit-transparent: the DC editor's edit-mode picker lets
      // clicks through for chrome marked with it (EDIT_TRANSPARENT_SEL)
      // — without it, Replace/Edit clicks in Edit mode are swallowed by
      // element selection and the controls look dead.
      '<div class="ctl" popover="manual" data-dc-edit-transparent><button data-act="replace" title="Replace image">Replace</button>' + '  <button data-act="edit" title="Reframe image">Edit</button></div>' + '<input type="file" accept="' + ACCEPT.join(',') + '" hidden>';
      this._frame = root.querySelector('.frame');
      this._ring = root.querySelector('.ring');
      this._img = root.querySelector('.frame img');
      this._empty = root.querySelector('.empty');
      this._cap = root.querySelector('.cap');
      this._sub = root.querySelector('.sub');
      this._spill = root.querySelector('.spill');
      this._ctl = root.querySelector('.ctl');
      this._credit = root.querySelector('.credit');
      this._attrError = root.querySelector('.attr-error');
      // Credit clicks open the link, not browse/reframe.
      this._credit.addEventListener('click', e => e.stopPropagation());
      this._credit.addEventListener('dblclick', e => e.stopPropagation());
      this._ghost = root.querySelector('.ghost');
      this._err = null;
      this._input = root.querySelector('input');
      this._depth = 0;
      this._gen = 0;
      // Encode-in-flight marker (the owning _ingest generation): while set,
      // the same-src "nothing in flight" clear in _render must not fire —
      // the stored value still points at the OLD image until the encode
      // lands, so that clear would unmask the stale image mid-replace.
      this._swapGen = 0;
      // Render-owned swap in flight: set when _render assigns a new src,
      // cleared only by the img's own load/error (or the empty branch).
      // img.complete CANNOT stand in for this — setting src only QUEUES
      // the current-request swap (a microtask), so synchronously after an
      // assignment, complete still reports the OLD settled request. The
      // pick path does exactly that: the host sets src, credit, and
      // credit-href back-to-back in one task, and renders #2/#3 would
      // read the stale complete === true and drop the mask one render
      // after it was set.
      this._loadPending = false;
      // See _render's empty branch: a transient attribution-error wipe of a
      // showing image must make the follow-up render a replacement (spinner),
      // not a first fill (blank frame).
      this._hidShowing = false;
      this._view = {
        s: 1,
        x: 0,
        y: 0
      };
      this._subFn = () => this._render();
      // Shadow-DOM listeners live with the shadow DOM — bound once here so
      // disconnect/reconnect (e.g. React remount) doesn't stack handlers.
      this._empty.addEventListener('click', () => this._input.click());
      root.addEventListener('click', e => {
        const act = e.target && e.target.getAttribute && e.target.getAttribute('data-act');
        if (!act) return;
        // The hidden controls are opacity-0 but still tabbable — without
        // this gate a keyboard user could drive them on a read-only share
        // link (mirrors the dblclick handler's editable gate).
        if (!this.hasAttribute('data-editable')) return;
        if (act === 'replace') {
          this._exitReframe(true);
          // Host-owned picker (Unsplash modal; it also offers local import).
          this.dispatchEvent(new CustomEvent('image-slot:pick', {
            bubbles: true,
            composed: true,
            detail: {
              id: this.id || null
            }
          }));
        }
        if (act === 'edit') {
          if (!this._reframes()) return;
          if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
        }
      });
      this._input.addEventListener('change', () => {
        const f = this._input.files && this._input.files[0];
        if (f) this._ingest(f);
        this._input.value = '';
      });
      // naturalWidth/Height aren't known until load — re-apply so the cover
      // baseline is computed from real dimensions, not the 100%×100% fallback.
      // load/error also release the replacement-in-flight mask (via the
      // single discipline in _releaseMask): the swap is only revealed once
      // the new image can actually paint (on error the frame shows its
      // background, same as a fresh slot with a broken src).
      this._img.addEventListener('load', () => {
        this._loadPending = false;
        this._releaseMask(true);
        this._applyView();
      });
      this._img.addEventListener('error', () => {
        this._loadPending = false;
        this._releaseMask(true);
      });
      // Gated only on editable — any filled slot can be repositioned/scaled,
      // regardless of fit. Share links (no writeFile) stay static.
      this.addEventListener('dblclick', e => {
        if (!this.hasAttribute('data-editable') || !this._reframes()) return;
        e.preventDefault();
        if (this.hasAttribute('data-reframe')) this._exitReframe(true);else this._enterReframe();
      });
      // Pan + resize both originate on the spill layer. A handle pointerdown
      // drives an aspect-locked resize anchored at the opposite corner; any
      // other pointerdown on the spill pans. Offsets are frame-% so a
      // reframed slot survives responsive resize / PPTX export.
      this._spill.addEventListener('pointerdown', e => {
        if (e.button !== 0 || !this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        e.stopPropagation();
        this._spill.setPointerCapture(e.pointerId);
        const rect = this.getBoundingClientRect();
        const fw = rect.width || 1,
          fh = rect.height || 1;
        const corner = e.target.getAttribute && e.target.getAttribute('data-c');
        let move;
        if (corner) {
          // Resize about the OPPOSITE corner. Viewport-px throughout (rect
          // fw/fh, not clientWidth) so the math survives a transform:scale()
          // ancestor — deck_stage renders slides scaled-to-fit.
          const iw = this._img.naturalWidth || 1,
            ih = this._img.naturalHeight || 1;
          const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
          const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
          const sx = corner.includes('e') ? 1 : -1;
          const sy = corner.includes('s') ? 1 : -1;
          const s0 = this._view.s;
          const w0 = iw * base * s0,
            h0 = ih * base * s0;
          const cx0 = (50 + this._view.x) / 100 * fw;
          const cy0 = (50 + this._view.y) / 100 * fh;
          const ox = cx0 - sx * w0 / 2,
            oy = cy0 - sy * h0 / 2;
          const diag0 = Math.hypot(w0, h0);
          const ux = sx * w0 / diag0,
            uy = sy * h0 / diag0;
          move = ev => {
            const proj = (ev.clientX - rect.left - ox) * ux + (ev.clientY - rect.top - oy) * uy;
            const s = clampS(s0 * proj / diag0);
            const d = diag0 * s / s0;
            this._view.s = s;
            this._view.x = (ox + ux * d / 2) / fw * 100 - 50;
            this._view.y = (oy + uy * d / 2) / fh * 100 - 50;
            this._clampView();
            this._applyView();
          };
        } else {
          this.setAttribute('data-panning', '');
          const start = {
            px: e.clientX,
            py: e.clientY,
            x: this._view.x,
            y: this._view.y
          };
          move = ev => {
            this._view.x = start.x + (ev.clientX - start.px) / fw * 100;
            this._view.y = start.y + (ev.clientY - start.py) / fh * 100;
            this._clampView();
            this._applyView();
          };
        }
        const up = () => {
          try {
            this._spill.releasePointerCapture(e.pointerId);
          } catch {}
          this._spill.removeEventListener('pointermove', move);
          this._spill.removeEventListener('pointerup', up);
          this._spill.removeEventListener('pointercancel', up);
          this.removeAttribute('data-panning');
          this._dragUp = null;
        };
        // Stashed so _exitReframe (Escape / outside-click mid-drag) can
        // tear the capture + listeners down synchronously.
        this._dragUp = up;
        this._spill.addEventListener('pointermove', move);
        this._spill.addEventListener('pointerup', up);
        this._spill.addEventListener('pointercancel', up);
      });
      // Wheel zoom stays available inside reframe mode as a trackpad nicety —
      // zooms toward the cursor (offset' = cursor·(1-k) + offset·k).
      this.addEventListener('wheel', e => {
        if (!this.hasAttribute('data-reframe')) return;
        e.preventDefault();
        const r = this.getBoundingClientRect();
        const cx = (e.clientX - r.left) / r.width * 100 - 50;
        const cy = (e.clientY - r.top) / r.height * 100 - 50;
        const prev = this._view.s;
        const next = clampS(prev * Math.pow(1.0015, -e.deltaY));
        if (next === prev) return;
        const k = next / prev;
        this._view.s = next;
        this._view.x = cx * (1 - k) + this._view.x * k;
        this._view.y = cy * (1 - k) + this._view.y * k;
        this._clampView();
        this._applyView();
      }, {
        passive: false
      });
    }
    connectedCallback() {
      // Warn once per page — an id-less slot works for the session but
      // cannot persist, and two id-less slots would share nothing.
      if (!this.id && !ImageSlot._warned) {
        ImageSlot._warned = true;
        console.warn('<image-slot> without an id will not persist its dropped image.');
      }
      this.addEventListener('dragenter', this);
      this.addEventListener('dragover', this);
      this.addEventListener('dragleave', this);
      this.addEventListener('drop', this);
      subs.add(this._subFn);
      // The host may inject window.omelette.writeFile AFTER the first render;
      // re-render on hover so the editable-gated controls reliably appear.
      this.addEventListener('pointerenter', this._subFn);
      // width%/height% in _applyView encode the frame aspect at call time —
      // a host resize (responsive grid, pane divider) would stretch the
      // image until the next _render. Re-render on size change: _render()
      // re-seeds _view from stored before clamp/apply, so a shrink→grow
      // cycle round-trips instead of ratcheting x/y toward the narrower
      // frame's clamp range.
      this._ro = new ResizeObserver(() => this._render());
      this._ro.observe(this);
      load();
      this._render();
    }
    disconnectedCallback() {
      subs.delete(this._subFn);
      this.removeEventListener('pointerenter', this._subFn);
      this.removeEventListener('dragenter', this);
      this.removeEventListener('dragover', this);
      this.removeEventListener('dragleave', this);
      this.removeEventListener('drop', this);
      if (this._ro) {
        this._ro.disconnect();
        this._ro = null;
      }
      // commit=false: a disconnect is not a user intent — committing here
      // would persist whatever half-finished drag a React remount or DOM
      // splice happened to interrupt. Deliberate exits commit on their own
      // paths (Escape/click-out/toggle), and unloads commit via pagehide.
      this._exitReframe(false);
    }
    _enterReframe() {
      if (this.hasAttribute('data-reframe')) return;
      this.setAttribute('data-reframe', '');
      this._signalReframe(true);
      // Best-effort commit when the document unloads mid-reframe (a host
      // navigation racing the enter signal, a manual reload, tab close):
      // the sidecar write rides the host bridge, which outlives this
      // document, so the crop survives even though the mode dies with the
      // DOM. Held on the instance so _exitReframe detaches exactly what
      // was attached.
      this._pagehide = () => {
        this._exitReframe(true);
        flushNow();
      };
      window.addEventListener('pagehide', this._pagehide);
      // Promote spill to the top layer, then keep it pinned over the frame:
      // scroll/resize cover the common cases, and a per-frame rect check
      // catches layout shifts that fire neither (an image above finishing
      // load, streamed DOM pushing the slot down, an ancestor transform
      // change) so the overlay can't detach from the frame.
      try {
        this._spill.showPopover();
      } catch {}
      // After the spill, so the controls stack above it in the top layer.
      try {
        this._ctl.showPopover();
      } catch {}
      this._reposition = () => {
        if (this.hasAttribute('data-reframe')) this._applyView();
      };
      window.addEventListener('scroll', this._reposition, true);
      window.addEventListener('resize', this._reposition);
      this._lastRect = '';
      this._watch = () => {
        if (!this.hasAttribute('data-reframe')) return;
        const r = this.getBoundingClientRect();
        const key = r.left + ',' + r.top + ',' + r.width + ',' + r.height;
        if (key !== this._lastRect) {
          this._lastRect = key;
          this._applyView();
        }
        this._watchId = requestAnimationFrame(this._watch);
      };
      this._watchId = requestAnimationFrame(this._watch);
      this._applyView();
      // Close on click outside (the spill handler stopPropagation()s so
      // in-image drags don't reach this) and on Escape. Listeners are held
      // on the instance so _exitReframe / disconnectedCallback can detach
      // exactly what was attached.
      this._outside = e => {
        if (e.composedPath && e.composedPath().includes(this)) return;
        this._exitReframe(true);
      };
      this._esc = e => {
        if (e.key === 'Escape') this._exitReframe(true);
      };
      document.addEventListener('pointerdown', this._outside, true);
      document.addEventListener('keydown', this._esc, true);
    }
    _exitReframe(commit) {
      if (!this.hasAttribute('data-reframe')) return;
      if (this._dragUp) this._dragUp();
      this.removeAttribute('data-reframe');
      this.removeAttribute('data-panning');
      if (this._outside) document.removeEventListener('pointerdown', this._outside, true);
      if (this._esc) document.removeEventListener('keydown', this._esc, true);
      this._outside = this._esc = null;
      if (this._reposition) {
        window.removeEventListener('scroll', this._reposition, true);
        window.removeEventListener('resize', this._reposition);
        this._reposition = null;
      }
      if (this._watchId) {
        cancelAnimationFrame(this._watchId);
        this._watchId = 0;
      }
      if (this._pagehide) {
        window.removeEventListener('pagehide', this._pagehide);
        this._pagehide = null;
      }
      try {
        this._spill.hidePopover();
      } catch {}
      try {
        this._ctl.hidePopover();
      } catch {}
      this._ctl.style.left = '';
      this._ctl.style.top = '';
      if (commit) this._commitView();
      this._signalReframe(false);
    }

    // Reframe state lives only in this DOM until commit, invisible to the
    // host's dirty signals — announce enter/exit so the host can hold
    // auto-reloads for exactly the gesture (the guest bundle forwards
    // image-slot:reframe to the host as imageSlotReframe). Dispatched on
    // the element (composed, so it escapes shadow roots) while connected;
    // a disconnected exit (disconnectedCallback) falls back to document so
    // the host still hears it.
    _signalReframe(active) {
      const target = this.isConnected ? this : document;
      target.dispatchEvent(new CustomEvent('image-slot:reframe', {
        bubbles: true,
        composed: true,
        detail: {
          active: active,
          id: this.id || null
        }
      }));
    }

    // Public: host's "Import from computer" calls this to run local browse.
    openFilePicker() {
      this._exitReframe(true);
      this._input.click();
    }

    // A src write is a newer intent for this slot's content — the host
    // pick path (setImageSlotImage) or an agent edit — so it must win
    // over any encode still in flight from an earlier drop: left live,
    // that encode lands later, passes _ingest's gen guard, and its
    // setSlot silently overwrites the pick (the stored value shadows
    // src in _render). Bumping _gen kills the encode before its own
    // _swapGen clear runs, so clear the dead claim here too — otherwise
    // _releaseMask (gated on !_swapGen) never fires and the pick's
    // spinner is stranded. src ONLY: the pick sets credit/credit-href
    // in the same task, and clearing _swapGen on those would let the
    // same-src branch unmask the old image mid-encode.
    attributeChangedCallback(name, oldVal, newVal) {
      if (name === 'src' && oldVal !== newVal) {
        this._gen++;
        this._swapGen = 0;
      }
      if (this.shadowRoot) this._render();
    }

    // handleEvent — one listener object for all four drag events keeps the
    // add/remove symmetric and the depth counter correct.
    handleEvent(e) {
      if (e.type === 'dragenter' || e.type === 'dragover') {
        // Without preventDefault the browser never fires 'drop'.
        e.preventDefault();
        e.stopPropagation();
        if (e.dataTransfer) e.dataTransfer.dropEffect = 'copy';
        if (e.type === 'dragenter') this._depth++;
        this.setAttribute('data-over', '');
      } else if (e.type === 'dragleave') {
        // dragenter/leave fire for every descendant crossing — count depth
        // so hovering the icon inside the empty state doesn't flicker.
        if (--this._depth <= 0) {
          this._depth = 0;
          this.removeAttribute('data-over');
        }
      } else if (e.type === 'drop') {
        e.preventDefault();
        e.stopPropagation();
        this._depth = 0;
        this.removeAttribute('data-over');
        const f = e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files[0];
        if (f) this._ingest(f);
      }
    }
    async _ingest(file) {
      this._setError(null);
      if (!file || ACCEPT.indexOf(file.type) < 0) {
        this._setError('Drop a PNG, JPEG, WebP, or AVIF image.');
        return;
      }
      // toDataUrl can take hundreds of ms on a large photo. A Clear or a
      // newer drop during that window would be clobbered when this await
      // resumes — bump + capture a generation so stale encodes bail.
      const gen = ++this._gen;
      // Replacing a shown image: surface the swap through the encode too,
      // not just the decode — otherwise the old photo sits there with no
      // feedback while the canvas re-encode runs. An empty slot keeps its
      // placeholder (no spinner) until the encode lands, as before.
      // _swapGen guards the mask against re-renders DURING the encode
      // (pointerenter, ResizeObserver, another slot's store write): the
      // stored value still resolves to the old image there, so _render's
      // same-src clear would otherwise unmask it mid-replace.
      if (this.hasAttribute('data-filled')) {
        this.setAttribute('data-swapping', '');
        this._swapGen = gen;
      }
      try {
        const w = this.clientWidth || this.offsetWidth || MAX_DIM;
        const url = await toDataUrl(file, w);
        if (gen !== this._gen) return;
        // Only exit reframe once the new image is in hand — a rejected type
        // or decode failure leaves the in-progress crop untouched.
        this._exitReframe(false);
        // Clear BEFORE setSlot: its synchronous re-render must see no
        // pending encode, so a byte-identical re-upload (same data URL, no
        // load event coming) still clears the mask via the complete branch.
        this._swapGen = 0;
        const val = {
          u: url,
          s: 1,
          x: 0,
          y: 0
        };
        setSlot(this.id || '', val);
        // Keep a session-local copy for id-less slots so the drop still
        // shows, even though it cannot persist.
        if (!this.id) {
          this._local = val;
          this._render();
        }
      } catch (err) {
        if (gen !== this._gen) return;
        this._swapGen = 0;
        // Reveal the kept old image — unless another replacement (a
        // remote pick's src swap) is still in flight, in which case the
        // mask stays until THAT image settles (its load/error releases).
        this._releaseMask();
        this._setError('Could not read that image.');
        console.warn('<image-slot> ingest failed:', err);
      }
    }
    _setError(msg) {
      if (this._err) {
        this._err.remove();
        this._err = null;
      }
      if (!msg) return;
      const d = document.createElement('div');
      d.className = 'err';
      d.textContent = msg;
      this.shadowRoot.appendChild(d);
      this._err = d;
      setTimeout(() => {
        if (this._err === d) {
          d.remove();
          this._err = null;
        }
      }, 3000);
    }

    // Reframing (pan/resize) is available on any filled slot — the user can
    // always reposition/scale. `fit` only sets the initial baseline (see
    // _geom): contain starts fully-visible, cover starts frame-filling.
    _reframes() {
      return this.hasAttribute('data-filled');
    }

    // The single release discipline for the replacement-in-flight mask
    // (data-swapping). The mask comes off only when BOTH hold:
    //  - no encode is pending (_swapGen) — mid-encode the stored value
    //    still resolves to the old image, so any reveal paints it;
    //  - the frame img has settled on its current src — an unsettled src
    //    means some replacement is still in flight (e.g. a remote pick),
    //    whoever started it, and revealing would paint the previous
    //    frame. The load/error listeners pass settled=true (the event IS
    //    the settlement signal, per spec complete is true by then);
    //    other callers rely on the complete flag (covers loaded AND
    //    failed).
    // Every release path funnels through here EXCEPT _render's empty
    // branch (the img is being cleared — nothing will ever settle).
    _releaseMask(settled) {
      if (!this._swapGen && !this._loadPending && (settled || this._img.complete)) {
        this.removeAttribute('data-swapping');
      }
    }

    // Baseline geometry, shared by clamp/apply/resize. `base` is the scale at
    // view-scale s=1: cover = fill the frame (overflow on the looser axis),
    // contain = fit fully inside (letterboxed). Zooming a contain image past
    // s where it overflows naturally becomes a crop. Null until the img has
    // loaded (naturalWidth is 0 before that) or when the slot has no layout
    // box — ResizeObserver fires with a 0×0 rect under display:none, and
    // clamping against a degenerate 1×1 frame would silently pull the stored
    // pan toward zero.
    _geom() {
      const iw = this._img.naturalWidth,
        ih = this._img.naturalHeight;
      const fw = this.clientWidth,
        fh = this.clientHeight;
      if (!iw || !ih || !fw || !fh) return null;
      const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
      const base = contain ? Math.min(fw / iw, fh / ih) : Math.max(fw / iw, fh / ih);
      return {
        iw,
        ih,
        fw,
        fh,
        base
      };
    }
    _clampView() {
      // Pan range on each axis is half the overflow past the frame edge.
      const g = this._geom();
      if (!g) return;
      const mx = Math.max(0, (g.iw * g.base * this._view.s / g.fw - 1) * 50);
      const my = Math.max(0, (g.ih * g.base * this._view.s / g.fh - 1) * 50);
      this._view.x = Math.max(-mx, Math.min(mx, this._view.x));
      this._view.y = Math.max(-my, Math.min(my, this._view.y));
    }
    _applyView() {
      const g = this._geom();
      // Top-layer controls: pin to the frame's top-right in viewport px
      // (the same 8px inset as the in-frame layout; unscaled — top-layer UI
      // reads as chrome, not page content). BEFORE the geometry branch:
      // placement needs only the frame rect, and a not-yet-loaded or broken
      // src must not leave the promoted strip floating unpositioned. Gated
      // on the popover actually being open: without the Popover API,
      // showPopover() threw (swallowed in _enterReframe), .ctl stays in
      // its in-frame absolute layout, and viewport-px coordinates would
      // shove it off-frame — and matches(':popover-open') itself throws
      // there (unknown pseudo-class), hence the try/catch.
      if (this.hasAttribute('data-reframe')) {
        let onTop = false;
        try {
          onTop = this._ctl.matches(':popover-open');
        } catch {}
        if (onTop) {
          const r = this.getBoundingClientRect();
          this._ctl.style.left = r.right - 8 + 'px';
          this._ctl.style.top = r.top + 8 + 'px';
        }
      }
      if (!g) {
        // Dimensions not known yet (before img load) — centered fit so there
        // is no flash of an unpositioned image before the geometry lands.
        const contain = (this.getAttribute('fit') || 'cover').toLowerCase() === 'contain';
        this._img.style.width = '100%';
        this._img.style.height = '100%';
        this._img.style.left = '50%';
        this._img.style.top = '50%';
        this._img.style.objectFit = contain ? 'contain' : 'cover';
        return;
      }
      // Baseline (cover-fill or contain-fit) × view scale. Width/height and
      // left/top are all frame-% — depends only on the frame aspect ratio, so
      // a responsive resize keeps the same crop. The spill layer mirrors the
      // same box so its corners = image corners.
      const k = g.base * this._view.s;
      const w = g.iw * k / g.fw * 100 + '%';
      const h = g.ih * k / g.fh * 100 + '%';
      const l = 50 + this._view.x + '%';
      const t = 50 + this._view.y + '%';
      this._img.style.width = w;
      this._img.style.height = h;
      this._img.style.left = l;
      this._img.style.top = t;
      this._img.style.objectFit = '';
      if (this.hasAttribute('data-reframe')) {
        // Top-layer spill: position in viewport px over the frame. The top
        // layer escapes ancestor transforms entirely, so EVERY term must be
        // in viewport units: getBoundingClientRect gives the frame's scaled
        // origin AND size, and the rect/layout ratio rescales the ghost —
        // sizing from layout px alone renders it 1/scale too large under a
        // scaled deck slide. Inner ghost + handles stay box-relative.
        const r = this.getBoundingClientRect();
        const sx = g.fw ? r.width / g.fw : 1;
        const sy = g.fh ? r.height / g.fh : 1;
        this._spill.style.width = g.iw * k * sx + 'px';
        this._spill.style.height = g.ih * k * sy + 'px';
        this._spill.style.left = r.left + (50 + this._view.x) / 100 * r.width + 'px';
        this._spill.style.top = r.top + (50 + this._view.y) / 100 * r.height + 'px';
      }
    }
    _commitView() {
      const v = {
        s: this._view.s,
        x: this._view.x,
        y: this._view.y
      };
      if (this._userUrl) v.u = this._userUrl;
      // Framing-only (no u) persists too so an author-src slot remembers its
      // crop; clearing the sidecar still falls through to src=.
      if (this.id) setSlot(this.id, v);else {
        this._local = v;
      }
    }
    _render() {
      // Shape / mask. Presets use border-radius so the dashed ring can
      // follow the rounded outline; clip-path is only applied for an
      // explicit `mask` (the ring is hidden there since a rectangle
      // dashed border chopped by an arbitrary polygon looks broken).
      const mask = this.getAttribute('mask');
      const shape = (this.getAttribute('shape') || 'rounded').toLowerCase();
      let radius = '';
      if (shape === 'circle') radius = '50%';else if (shape === 'pill') radius = '9999px';else if (shape === 'rounded') {
        const n = parseFloat(this.getAttribute('radius'));
        radius = (Number.isFinite(n) ? n : 12) + 'px';
      }
      this._frame.style.borderRadius = mask ? '' : radius;
      this._frame.style.clipPath = mask || '';
      this._ring.style.borderRadius = mask ? '' : radius;
      this._ring.style.display = mask ? 'none' : '';

      // Controls and reframe entry gate on this so share links stay read-only.
      const editable = !!(window.omelette && window.omelette.writeFile);
      this.toggleAttribute('data-editable', editable);
      this._sub.style.display = editable ? '' : 'none';

      // Content. The sidecar is also writable by the agent's write_file
      // tool, so its value isn't guaranteed canvas-originated — only accept
      // data:image/ URLs from it. The `src` attribute is author-controlled
      // (Claude wrote it into the HTML) so it passes through unchanged.
      let stored = this.id ? getSlot(this.id) : this._local;
      if (stored && stored.u && !/^data:image\//i.test(stored.u)) stored = null;
      const srcAttr = this.getAttribute('src') || '';
      this._userUrl = stored && stored.u || null;
      const url = this._userUrl || srcAttr;
      // Don't clobber an in-flight reframe with a store-triggered re-render.
      if (!this.hasAttribute('data-reframe')) {
        this._view = {
          s: stored && Number.isFinite(stored.s) ? clampS(stored.s) : 1,
          x: stored && Number.isFinite(stored.x) ? stored.x : 0,
          y: stored && Number.isFinite(stored.y) ? stored.y : 0
        };
      }
      this._cap.textContent = this.getAttribute('placeholder') || 'Drop an image';
      // Toggle via style.display — the [hidden] attribute alone loses to
      // the display:flex / display:block rules in the stylesheet above.
      // An Unsplash src with no credit attribute must NOT render — showing
      // the photo uncredited is the Unsplash-terms violation itself. The
      // error tile replaces the photo until the credit is written. A
      // user-dropped image is the user's own content and always renders.
      // Trimmed: credit is agent/user-editable content, and a whitespace-
      // only value must count as missing — otherwise it would suppress the
      // error tile AND render an empty credit box (no text, no links),
      // exactly the unattributed state this gate exists to prevent.
      const credit = (this.getAttribute('credit') || '').trim();
      const attrError = !!(!credit && !this._userUrl && srcAttr && isUnsplashHost(srcAttr));
      this.toggleAttribute('data-attribution-error', attrError);
      if (url && !attrError) {
        const prev = this._img.getAttribute('src');
        if (prev !== url) {
          // Replacing an already-shown image: mark the swap BEFORE setting
          // src so the stale frame is never revealed (see the data-swapping
          // stylesheet rules). First fill (prev empty) keeps the existing
          // placeholder-until-load behavior — no spinner. _hidShowing
          // covers the pick path's transient attribution-error wipe: prev
          // is gone, but an image WAS showing, so this is a replacement.
          if (prev || this._hidShowing) this.setAttribute('data-swapping', '');
          // Mark the swap BEFORE assigning src: complete keeps reporting
          // the old settled request until the browser's
          // update-the-image-data microtask runs, so same-task re-renders
          // (the pick path's credit/credit-href setAttributes) need this
          // flag, not complete, to know a load is in flight.
          this._loadPending = true;
          this._img.src = url;
          this._ghost.src = url;
        } else {
          // Same-src re-render — release if settled, so an ingest-set
          // spinner can't stick after a byte-identical re-upload (same
          // data URL, no further load event ever fires).
          this._releaseMask();
        }
        this._hidShowing = false;
        this._img.style.display = 'block';
        this._empty.style.display = 'none';
        this.setAttribute('data-filled', '');
        this._clampView();
        this._applyView();
      } else {
        this.removeAttribute('data-swapping');
        // The src is being removed — no load/error will ever fire for it.
        this._loadPending = false;
        // A transient attribution-error wipe of a showing image happens on
        // the pick path: the host sets src one setAttribute before credit,
        // so render N hides the old image (attrError) and render N+1
        // restores a URL. Remember the wipe so that restore renders as a
        // replacement (spinner), not a first fill (blank frame).
        this._hidShowing = attrError && !!this._img.getAttribute('src');
        this._img.style.display = 'none';
        this._img.removeAttribute('src');
        this._ghost.removeAttribute('src');
        // The error tile owns the blocked-photo state; .empty stays for
        // the genuinely-empty slot.
        this._empty.style.display = attrError ? 'none' : 'flex';
        this.removeAttribute('data-filled');
      }

      // Credit belongs to the author src, so a user drop hides it.
      // textContent + the http(s)-only funnel keep external strings inert.
      const showCredit = !!(url && credit && !this._userUrl && !attrError);
      this._credit.textContent = '';
      if (showCredit) {
        // Validate once (resolved against the document, http(s) only),
        // then append the terms-required utm referral params to links
        // that point back at unsplash.com.
        let href = '';
        const rawHref = this.getAttribute('credit-href') || '';
        if (rawHref) {
          try {
            const u = new URL(rawHref, document.baseURI);
            if (u.protocol === 'http:' || u.protocol === 'https:') {
              href = withReferral(u.href);
            }
          } catch {}
        }
        const mkLink = (text, linkHref) => {
          const a = document.createElement('a');
          a.setAttribute('target', '_blank');
          a.setAttribute('rel', 'noopener noreferrer');
          a.setAttribute('href', linkHref);
          a.textContent = text;
          return a;
        };
        // Unsplash's prescribed credit is TWO links — the photographer's
        // name to their profile (credit-href) and 'Unsplash' to the
        // homepage. Render that split whenever the text has the canonical
        // shape; other text keeps the legacy single-link rendering.
        const m = /^Photo by (.+) on Unsplash$/.exec(credit);
        if (m) {
          this._credit.appendChild(document.createTextNode('Photo by '));
          this._credit.appendChild(href ? mkLink(m[1], href) : document.createTextNode(m[1]));
          this._credit.appendChild(document.createTextNode(' on '));
          this._credit.appendChild(mkLink('Unsplash', UNSPLASH_HOMEPAGE_HREF));
        } else if (href) {
          this._credit.appendChild(mkLink(credit, href));
        } else {
          this._credit.textContent = credit;
        }
      }
      this.toggleAttribute('data-credit', showCredit);
    }
  }
  if (!customElements.get('image-slot')) {
    customElements.define('image-slot', ImageSlot);
  }
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/pumallen-os/image-slot.js", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.ChecklistItem = __ds_scope.ChecklistItem;

__ds_ns.TimeframeCard = __ds_scope.TimeframeCard;

__ds_ns.LoadingDots = __ds_scope.LoadingDots;

__ds_ns.Toast = __ds_scope.Toast;

__ds_ns.VerdictBanner = __ds_scope.VerdictBanner;

__ds_ns.TextField = __ds_scope.TextField;

__ds_ns.Select = __ds_scope.Select;

__ds_ns.BottomNav = __ds_scope.BottomNav;

__ds_ns.TopBar = __ds_scope.TopBar;

})();
