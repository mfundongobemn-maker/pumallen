# Handoff: Pumallen OS (PMTS Trading Companion)

## Overview
Pumallen OS is a disciplined trading companion for the Pumallen Master Trading System (PMTS) — a rules-based EURUSD (and optionally other pairs) price-action methodology built on a "chain of authority" across timeframes (Monthly → Weekly → Daily → H4 → H1 → optional M15). This handoff covers a full click-through prototype: chart-upload-driven AI analysis with a permission gate at each timeframe, a 9-condition pre-trade checklist, a position-size calculator, a trade journal, an AI chat assistant, and an evidence-based currency ranking / pair-selection engine.

## About the Design Files
The files in this bundle are **design references built in HTML/React (inline Babel, no build step)** — they demonstrate the intended look, layout, and interaction behavior. They are **not production code to copy directly**. The task is to recreate these designs in your target codebase's existing environment (React Native, SwiftUI/Kotlin for native, a proper React+bundler web stack, etc.) — or choose the most appropriate framework if none exists yet — using that environment's established patterns, state management, and persistence.

## Fidelity
**High-fidelity.** Colors, typography, spacing, and copy are final and should be recreated pixel-for-pixel. Interaction behavior (permission gating, live AI calls, drag-drop upload) is functionally real in the prototype (backed by a demo-only Claude API helper and localStorage) and should be treated as the intended real behavior, just needing a production backend.

## Screens / Views

### 1. Analysis (`AnalysisScreen.jsx`)
**Purpose:** Walk the trader through the PMTS chain of authority, one timeframe at a time.
**Layout:** Scrollable column, top status bar (System Ready + checklist completion badge), then 5 stacked cards (Monthly, Weekly, Daily, H4, H1) connected by a vertical line, each in one of 4 states: `locked` (40% opacity, no interaction), `active` (upload dropzone visible), `analyzing` (bouncing 3-dot indicator), `ready` (AI result text + Confirm/Stand-down buttons).
**Components:**
- Timeframe card: 40×40px number badge (mono font, bold), title (14px/700), subtitle (10px, muted), state badge (pill, top-right: LOCKED/UPLOAD/ALIGNED/REJECTED)
- Chart dropzone: rounded 10px, 90px tall, drag-and-drop image upload
- Result box: `rgba(0,0,0,.4)` background, 1px border `#2a2200`, 12px radius, mono-adjacent body text, pre-wrapped
- Confirm button: green tint `rgba(0,232,122,.08)` bg, `#00e87a` border/text; Stand-down: red tint equivalent
- Verdict banner (on completion): large centered card, icon + title (20px/800, uppercase, letter-spacing .08em) + subtitle, green for Execute / red for Stand Down, plus a "Continue in AI Chat" gold button
**Interactions:** Dropping an image on a card's dropzone triggers a real Claude vision call (image + timeframe-specific prompt) → result text → Confirm unlocks the next timeframe; Stand-down ends the chain. The final H1 "Confirm" is disabled unless the separate Checklist screen's 9 conditions are all checked (cross-screen gate).

### 2. AI Chat (`ChatScreen.jsx`)
**Purpose:** Free-form Q&A about the current PMTS session, with real Claude responses.
**Layout:** Fixed header, scrollable message thread (bubbles, 85% max-width, gold for user/right-aligned, dark surface for assistant/left-aligned), optional attach-image row, fixed composer (input + 📎 attach + send).
**Interactions:** Every message call includes a system prompt describing the full PMTS ruleset (chain of authority, 9 conditions) PLUS a live context block built from the current Analysis screen's results/verdict and Checklist completion — so answers are grounded in the user's actual session. A 📎 button reveals a drop zone; attaching an image sends it as a vision message alongside the typed question.

### 3. Pre-Trade Checklist (`ChecklistScreen.jsx`)
**Purpose:** Confirm all 9 PMTS entry conditions before execution is allowed.
**Layout:** 9 tappable rows (22×22px checkbox, green fill when checked), verdict banner at bottom (green "ALL CONDITIONS MET" or red "STAND DOWN (n/9)"), reset button.
**Behavior:** This screen's checked state is the same state read by the Analysis screen's H1 gate — it's shared app state, not screen-local.

### 4. Position Size Calculator (`CalcScreen.jsx`)
**Purpose:** Compute lot size from account balance, risk %, and stop-loss pips, for a selected currency pair.
**Fields:** Account Balance ($), Risk per Trade (%), Stop Loss (pips) — all validated (balance>0, 0<risk≤100, pips>0; risk>5% triggers a soft warning). Result shows risk amount, lot size, and pip value at that size (pip value differs per pair — EURUSD/GBPUSD/AUDUSD ≈ $10/pip, USDCHF ≈ $11/pip, USDJPY ≈ $9.13/pip, all per standard lot on a USD account).

### 5. Trade Journal (`JournalScreen.jsx`)
**Purpose:** Log trades (direction, date, entry/SL/TP, result) tagged with the currently selected currency pair.
**Behavior:** Add, delete, and inline-edit each entry's result (Open/Win/Loss/Breakeven) via a dropdown. "Export Summary" copies a plain-text summary to the clipboard.

### 6. Stats (`StatsScreen.jsx`)
**Purpose:** Live-computed trading stats — total trades, win rate, wins/losses, best win streak, open trades, breakevens — all derived from the Journal entries (no separate stats storage).

### 7. Funding Planner (`PlannerScreen.jsx`)
**Purpose:** Estimate months to reach a funded-account balance ceiling from current balance + planned monthly funding.

### 8. Market Narrative (`NarrativeScreen.jsx`)
**Purpose:** Freeform session notes. On save, a Claude call generates a 5-word-or-fewer auto-tag summarizing the entry, shown next to the date.

### 9. Analysis History (`HistoryScreen.jsx`)
**Purpose:** Past analysis outcomes, filterable by Execute/Stand Down, with a clipboard export.

### 10. Economic Ranking & Pair Selection (`EconomyScreen.jsx`)
**Purpose:** Evidence-based currency strength ranking across 8 currencies (USD, EUR, GBP, JPY, AUD, CAD, CHF, NZD) × 6 economic chains (Business Activity, Labour Market, Inflation, Consumer Activity, Economic Growth, Central Bank), modeled directly on the user's own "PMTS Economic Ranking & Pair Selection" spreadsheet.
**Sub-tabs:**
- **Evidence:** per-currency, per-chain editable Strength (Strong/Mixed/Weak, scored +1/0/-1) and Status (Not Started/Collecting Evidence/Thesis Complete)
- **Rankings:** all 8 currencies sorted by total score, with an Eligible badge (Eligible = all 3 "core" chains — Business Activity, Labour Market, Inflation — AND at least 1 of 3 "support" chains — Consumer Activity, Economic Growth, Central Bank — are "Thesis Complete")
- **Pair Select:** among eligible currencies, strongest vs weakest by score; Gap = strongest − weakest; Gap < 3 → "NO TRADE"; Gap ≥ 3 → "Candidate Pair" with a confidence label (Moderate 3-4, High 5-7, Very High 8+). Fewer than 2 eligible currencies → "NOT ENOUGH ELIGIBLE CURRENCIES".
**This screen is an intentional addition beyond the original app**, built from the user's own workbook, not the source GitHub repo.

### 11. Settings (`SettingsScreen.jsx`)
**Purpose:** Accent color theme (gold/silver/green, applied via CSS custom property overrides), currency pair selector (EURUSD/GBPUSD/USDJPY/AUDUSD/USDCHF — drives the topbar label, Calculator pip value, Economy default filter, and Analysis/Chat prompt wording), a cosmetic API key field, and a "Reset All App Data" action (with confirm step) that clears all persisted state.

## Global Shell (`App.jsx`)
- Fixed top bar (brand wordmark + day-of-week status chip: Tue-Thu = green "EXECUTE", Mon = neutral "ANALYSIS", Fri/Sat/Sun = red "NO TRADE")
- Scrolling session-status row (London/New York/Asian open-closed pills) below the top bar, hidden on Chat/Settings
- Fixed bottom tab bar: Analysis, AI Chat, Checks, Calc, Journal, More (5-item grid: Stats, Planner, Narrative, History, Economy, Settings)
- All app state (analysis progress, checklist, chat history, journal, narrative, economy data, accent, pair) is lifted to this shell and persisted to `localStorage` under one JSON key, restored (deep-merged onto defaults) on load

## Interactions & Behavior
- **Animations:** tab switches fade+slide in (`.pm-screen`, 250ms ease); the AI-analyzing indicator is a staggered 3-dot bounce (`pmDotBounce`, 1.2s loop, 0.2s stagger)
- **Press states:** buttons dip to 70% opacity on press/hold (no scale/shrink), 150ms transition
- **No hover states** — this is a touch-first mobile shell
- **Loading states:** LoadingDots component during any AI call
- **Error states:** AI call failures render inline as `⚠ <message>` in the same slot the result would occupy

## State Management
Single shell-level state object, shape:
```js
{
  analysis: { states: {MO,W,D,H4,H1: 'locked'|'active'|'analyzing'|'ready'|'aligned'|'rejected'}, results: {tf: string}, verdict: null|'execute'|'stand-down' },
  checklist: boolean[9],
  chat: {role:'user'|'assistant', content:string, thumb?:string}[],
  journal: {dir,date,entry,sl,tp,result,pair}[],
  narrative: {date,body,tag}[],
  economy: { [CCY]: { [CHAIN_ID]: {strength:'Strong'|'Mixed'|'Weak', status:'Not Started'|'Collecting Evidence'|'Thesis Complete'} } },
  accent: 'gold'|'silver'|'green',
  pair: 'EURUSD'|'GBPUSD'|'USDJPY'|'AUDUSD'|'USDCHF'
}
```
In production this state (minus ephemeral UI state like input values) should move to a real backend/database per user account, not just localStorage — the prototype uses localStorage purely for demo persistence.

## Design Tokens
- **Colors:** background `#0a0800` (near-black), surface `#0f0d02`, surface-alt `#1a1500`, border `#2a2200`; accent gold `#d4a017`→`#f0c040` gradient (swappable to silver `#c7cdd6` or green `#00e87a` per the accent toggle); success `#00e87a`, danger `#ff3355`; text `#f5ead0` (hi) / `#a89060` (mid) / `#5a4a30` (muted/lo)
- **Type:** Outfit (400–900) for all UI text; JetBrains Mono for data/timestamps/badges/scores
- **Spacing scale:** 3, 5, 8, 10, 12, 14, 16, 20px
- **Radii:** 6px (small controls), 9–10px (buttons/inputs), 14px (cards), 20px/pill (chips, toasts, CTAs)
- **No drop shadows** — elevation is communicated by border color/opacity and a soft colored glow on "aligned" states (`box-shadow: 0 0 20px rgba(0,232,122,.07)`)

## Assets
- App icon / brand mark: `assets/logo/icon-192.png`, `assets/logo/icon-512.png` (metallic gold/silver "P" monogram on black) — copied from the source GitHub repo
- No other custom icon assets — all UI icons are emoji (🔬💬✅🧮📒📊📅📝🗂🌐⚙️), consistent with the source app's convention. Do not substitute an icon font/SVG set without checking with design first.

## Files
All files live in `ui_kits/pumallen-os/` of the design system project:
- `index.html` — mounts everything, loads the design-system bundle + image-slot web component
- `App.jsx` — shell, state, nav, persistence
- `AnalysisScreen.jsx`, `ChatScreen.jsx`, `ChecklistScreen.jsx`, `CalcScreen.jsx`, `JournalScreen.jsx`, `StatsScreen.jsx`, `PlannerScreen.jsx`, `NarrativeScreen.jsx`, `HistoryScreen.jsx`, `EconomyScreen.jsx`, `SettingsScreen.jsx` — one file per screen
- `image-slot.js` — drag-and-drop image capture web component (used for chart uploads)

Reusable primitives referenced from the design system's component library (also bundled in this handoff for reference): `Button`, `Badge`, `Chip`, `Card`, `Toast`, `LoadingDots`, `VerdictBanner`, `BottomNav`, `TopBar`, `TimeframeCard`, `ChecklistItem`, `TextField`/`Select` — see each component's own `.prompt.md` for props and variants.

## Source References
- Original app: github.com/mfundongobemn-maker/pumallen (single-file PWA — `index.html`, `manifest.json`, icons)
- Economic Ranking logic: user-provided `PMTS_Economic_Ranking_Pair_Selection.xlsx` (11 sheets: Instructions, 8× currency Evidence tabs, Decision Engine, Pair Selection)
