const { LoadingDots } = window.PumallenOSDesignSystem_ac653c;
const PMTS_SYSTEM_BASE = function(pair){ return 'You are the Pumallen OS trading assistant for the Pumallen Master Trading System (PMTS) — a disciplined '+pair+' price-action framework. Chain of authority: MONTHLY=Supreme authority (mission, no entries), WEEKLY=Strategic planning (cannot contradict Monthly), DAILY=Permission timeframe (no permission=no trade), H4=Engineering (builds execution environment), H1=Execution engine (needs sweep+BOS+pullback), M15=Optional precision only when H1 unclear. Authority flows downward, evidence flows upward. 9 conditions ALL required to execute: Tue-Thu only, London/NY session, Monthly mission confirmed, Weekly aligned, Daily permission, H4 aligned, H1 sweep, H1 BOS, clean pullback — one failure means stand down. Be direct, disciplined, concise. Use checkmarks/bold for key conclusions. When a chart image is attached, read it directly.'; };
const TF_LABELS = {MO:'Monthly',W:'Weekly',D:'Daily',H4:'H4',H1:'H1'};
function buildContext(analysis, checklist){
  const lines = [];
  Object.keys(analysis.results||{}).forEach(tf=>{ if(analysis.results[tf]) lines.push('--- '+TF_LABELS[tf]+' ANALYSIS ---\n'+analysis.results[tf]); });
  if(analysis.verdict) lines.push('CURRENT VERDICT: '+analysis.verdict.toUpperCase());
  const checkedCount = checklist.filter(Boolean).length;
  lines.push('CHECKLIST: '+checkedCount+'/9 conditions met.');
  if(!lines.length) return '';
  return '\n\nCURRENT SESSION CONTEXT:\n'+lines.join('\n\n');
}
function ChatScreen(props){
  const { chat, setChat, analysis, checklist, pair } = props;
  const [val,setVal] = React.useState('');
  const [typing,setTyping] = React.useState(false);
  const [attaching,setAttaching] = React.useState(false);
  const [attachedThumb,setAttachedThumb] = React.useState(null);
  const threadRef = React.useRef(null);
  const slotRef = React.useRef(null);
  React.useEffect(()=>{ if(threadRef.current) threadRef.current.scrollTop = threadRef.current.scrollHeight; },[chat,typing]);
  React.useEffect(()=>{
    if(!attaching || !slotRef.current) return;
    const el = slotRef.current;
    const obs = new MutationObserver(()=>{
      if(el.hasAttribute('data-filled')){
        const img = el.shadowRoot && el.shadowRoot.querySelector('.frame img');
        if(img) setAttachedThumb(img.src);
      }
    });
    obs.observe(el,{attributes:true, attributeFilter:['data-filled']});
    return ()=>obs.disconnect();
  },[attaching]);
  function getAttachedImage(){
    const el = slotRef.current;
    const img = el && el.shadowRoot && el.shadowRoot.querySelector('.frame img');
    return img && img.src && img.src.indexOf('data:')===0 ? img.src : null;
  }
  async function send(){
    if((!val.trim() && !attachedThumb) || typing) return;
    const dataUrl = attachedThumb ? getAttachedImage() : null;
    const userMsg = { role:'user', content: val || '(chart attached)', thumb: attachedThumb };
    const next = [...chat, userMsg];
    setChat(next);
    setVal('');
    setAttaching(false);
    setAttachedThumb(null);
    setTyping(true);
    try {
      const apiMessages = next.slice(-10).map((m,i,arr)=>{
        if(i===arr.length-1 && dataUrl){
          const mediaType = dataUrl.slice(5, dataUrl.indexOf(';'));
          const base64 = dataUrl.slice(dataUrl.indexOf(',')+1);
          return { role:'user', content:[
            { type:'image', source:{ type:'base64', media_type:mediaType, data:base64 } },
            { type:'text', text: m.content }
          ]};
        }
        return { role:m.role, content:m.content };
      });
      const reply = await window.claude.complete({ system: PMTS_SYSTEM_BASE(pair||'EURUSD') + buildContext(analysis, checklist), messages: apiMessages });
      setChat(c=>[...c,{role:'assistant',content:reply}]);
    } catch(err){
      setChat(c=>[...c,{role:'assistant',content:'⚠ '+(err && err.message ? err.message : 'Request failed. Try again.')}]);
    }
    setTyping(false);
  }
  return (
    <div style={{position:'absolute',top:58,left:0,right:0,bottom:64,display:'flex',flexDirection:'column'}}>
      <div style={{padding:'16px 16px 10px',flexShrink:0}}>
        <div style={{color:'var(--accent-primary)',fontSize:18,fontWeight:800}}>AI Chat 💬</div>
        <div style={{color:'var(--text-muted)',fontSize:11,marginTop:2}}>Ask about the current {pair||'EURUSD'} analysis or PMTS rules · powered by Claude</div>
      </div>
      <div ref={threadRef} style={{flex:1,overflowY:'auto',padding:'0 16px 12px',display:'flex',flexDirection:'column',gap:10}}>
        {chat.map((m,i)=>(
          <div key={i} style={{maxWidth:'85%',padding:'10px 13px',borderRadius:14,fontSize:13,lineHeight:1.5,whiteSpace:'pre-wrap',animation:'pmFadeIn .2s ease',
            alignSelf: m.role==='user' ? 'flex-end':'flex-start',
            background: m.role==='user' ? 'var(--accent-primary)':'var(--bg-surface-alt)',
            color: m.role==='user' ? '#0a0800':'var(--text-hi)',
            border: m.role==='user' ? 'none':'1px solid var(--border-default)'}}>
            {m.thumb && <img src={m.thumb} style={{width:'100%',maxHeight:120,objectFit:'cover',borderRadius:8,marginBottom:6,display:'block'}}/>}
            {m.content}
          </div>
        ))}
        {typing && <div style={{alignSelf:'flex-start',padding:'10px 13px',borderRadius:14,background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)'}}><LoadingDots/></div>}
      </div>
      {attaching && (
        <div style={{padding:'0 16px 10px',flexShrink:0}}>
          <div ref={el=>{ if(el) slotRef.current = el.querySelector('image-slot'); }}>
            <image-slot id="chat-attach" shape="rounded" radius="10" placeholder="Drop a chart to ask about" style={{width:'100%',height:80,display:'block'}}></image-slot>
          </div>
        </div>
      )}
      <div style={{padding:'10px 16px 16px',flexShrink:0,display:'flex',gap:8,borderTop:'1px solid var(--border-default)'}}>
        <button onClick={()=>setAttaching(a=>!a)} style={{padding:'11px 13px',background:attaching?'var(--accent-primary)':'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:20,color:attaching?'#0a0800':'var(--text-muted)',cursor:'pointer',fontSize:14}}>📎</button>
        <input value={val} onChange={e=>setVal(e.target.value)} onKeyDown={e=>e.key==='Enter'&&send()} placeholder="Ask a question..."
          style={{flex:1,padding:'11px 13px',background:'var(--bg-surface-alt)',border:'1.5px solid var(--border-gold)',borderRadius:20,color:'var(--text-hi)',fontFamily:'var(--font-body)',fontSize:13}}/>
        <button onClick={send} style={{padding:'11px 16px',background:'var(--accent-primary)',border:'none',borderRadius:20,color:'#0a0800',fontWeight:800,cursor:'pointer'}}>➤</button>
      </div>
    </div>
  );
}
window.ChatScreen = ChatScreen;
