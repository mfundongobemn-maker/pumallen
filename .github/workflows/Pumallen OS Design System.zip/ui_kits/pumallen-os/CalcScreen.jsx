const { TextField } = window.PumallenOSDesignSystem_ac653c;
const PIP_VALUE = {EURUSD:10, GBPUSD:10, AUDUSD:10, USDCHF:11, USDJPY:9.13};
function CalcScreen(props){
  const pair = (props && props.pair) || 'EURUSD';
  const [balance,setBalance] = React.useState('1000');
  const [risk,setRisk] = React.useState('1');
  const [pips,setPips] = React.useState('50');
  const [result,setResult] = React.useState(null);
  const [error,setError] = React.useState('');
  function calc(){
    const b=parseFloat(balance),r=parseFloat(risk),p=parseFloat(pips);
    setError('');
    setResult(null);
    if(!b || b<=0){ setError('Enter a valid account balance greater than 0.'); return; }
    if(!r || r<=0 || r>100){ setError('Risk per trade must be between 0 and 100%.'); return; }
    if(!p || p<=0){ setError('Stop loss must be a positive number of pips.'); return; }
    if(r>5){ setError('⚠️ '+r+'% risk per trade is well above the 1–2% PMTS guideline — proceed with caution.'); }
    const pipValuePerLot = PIP_VALUE[pair] || 10;
    const riskAmt = b*r/100;
    const lots = riskAmt/(p*pipValuePerLot);
    if(lots < 0.01){ setResult({riskAmt:riskAmt.toFixed(2), lots:'0.00', warn:'Position rounds to below the 0.01 micro-lot minimum — reduce stop loss or increase risk.'}); return; }
    setResult({riskAmt:riskAmt.toFixed(2), lots:lots.toFixed(2), pipValue:(lots*pipValuePerLot).toFixed(2)});
  }
  return (
    <div style={{position:'absolute',top:58,left:0,right:0,bottom:64,overflowY:'auto',padding:16}}>
      <div style={{color:'var(--accent-primary)',fontSize:18,fontWeight:800,marginBottom:2}}>Position Size Calculator 🧮</div>
      <div style={{color:'var(--text-muted)',fontSize:11,marginBottom:16}}>{pair} lot sizing based on account risk · pip value assumes a USD account</div>
      <div style={{background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:12,padding:16,display:'flex',flexDirection:'column',gap:10}}>
        <TextField label="Account Balance ($)" type="number" placeholder="1000" value={balance} onChange={e=>setBalance(e.target.value)} />
        <TextField label="Risk per Trade (%)" type="number" placeholder="1" value={risk} onChange={e=>setRisk(e.target.value)} />
        <TextField label="Stop Loss (pips)" type="number" placeholder="50" value={pips} onChange={e=>setPips(e.target.value)} />
        <button onClick={calc} style={{width:'100%',padding:12,background:'var(--accent-primary)',border:'none',borderRadius:10,color:'#0a0800',fontWeight:800,fontSize:13,cursor:'pointer'}}>Calculate</button>
        {error && <div style={{padding:'10px 12px',background:'var(--surface-red-tint)',border:'1px solid var(--border-red)',borderRadius:8,fontSize:12,color:'var(--accent-danger)',lineHeight:1.5}}>{error}</div>}
        {result && (
          <div style={{padding:12,background:'rgba(0,0,0,.4)',borderRadius:10,border:'1px solid var(--border-default)',fontSize:12,lineHeight:1.75,color:'var(--text-dim)',fontFamily:'var(--font-mono)'}}>
            Risk amount: <b style={{color:'var(--accent-primary)'}}>${result.riskAmt}</b><br/>
            Position size: <b style={{color:'var(--accent-primary)'}}>{result.lots} lots</b>
            {result.pipValue && <React.Fragment><br/>Pip value at this size: <b style={{color:'var(--accent-primary)'}}>${result.pipValue}/pip</b></React.Fragment>}
            {result.warn && <div style={{marginTop:8,color:'var(--accent-danger)',fontFamily:'var(--font-body)'}}>⚠️ {result.warn}</div>}
          </div>
        )}
      </div>
    </div>
  );
}
window.CalcScreen = CalcScreen;
