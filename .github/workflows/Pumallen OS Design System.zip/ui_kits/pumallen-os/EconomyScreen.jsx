const { Badge } = window.PumallenOSDesignSystem_ac653c;
const CHAINS = [
  {id:'BA',label:'Business Activity'}, {id:'LM',label:'Labour Market'}, {id:'INF',label:'Inflation'},
  {id:'CON',label:'Consumer Activity'}, {id:'GRO',label:'Economic Growth'}, {id:'CB',label:'Central Bank'}
];
const CORE = ['BA','LM','INF'];
const SUPPORT = ['CON','GRO','CB'];
const CCYS = ['USD','EUR','GBP','JPY','AUD','CAD','CHF','NZD'];
const THESES = ['Strong','Mixed','Weak'];
const VERDICTS = ['','Supports Thesis','Rejects Thesis','Neutral / N/A'];
const SCORE = {Strong:1, Mixed:0, Weak:-1};
const VERDICT_WEIGHT = {'Supports Thesis':1, 'Rejects Thesis':-1, 'Neutral / N/A':0};
function suggestThesis(chain){
  const answered = (chain.anchors||[]).filter(a=>a.verdict);
  if(answered.length===0) return null;
  const sum = answered.reduce((s,a)=>s+(VERDICT_WEIGHT[a.verdict]||0),0);
  const avg = sum/answered.length;
  return avg>0.25 ? 'Strong' : avg<-0.25 ? 'Weak' : 'Mixed';
}
const USD_PAIR_ORDER = ['EUR','GBP','AUD','NZD']; // conventionally quoted ahead of USD
function toPairSymbol(a, b){
  if(a==='USD' && USD_PAIR_ORDER.includes(b)) return b+'USD';
  if(b==='USD' && USD_PAIR_ORDER.includes(a)) return a+'USD';
  if(a==='USD') return 'USD'+b;
  if(b==='USD') return 'USD'+a;
  return a+b;
}

function computeStatus(chain, month){
  const anchors = chain.anchors || [];
  const monthAnchors = anchors.filter(a=>a.date && a.date.slice(0,3)===month);
  if(monthAnchors.length===0) return anchors.length===0 ? 'Not Started' : 'Collecting Evidence';
  const answered = monthAnchors.filter(a=>a.verdict);
  if(answered.length===0) return 'Not Started';
  if(answered.length===monthAnchors.length) return 'Thesis Complete';
  return 'Collecting Evidence';
}
function computeCurrency(data, month){
  let total=0; const statuses={};
  CHAINS.forEach(c=>{ total += SCORE[data[c.id].thesis]; statuses[c.id] = computeStatus(data[c.id], month); });
  const coreComplete = CORE.every(id=>statuses[id]==='Thesis Complete');
  const supportComplete = SUPPORT.some(id=>statuses[id]==='Thesis Complete');
  const eligible = coreComplete && supportComplete;
  const chainsComplete = CHAINS.filter(c=>statuses[c.id]==='Thesis Complete').length;
  return { total, statuses, coreComplete, supportComplete, eligible, chainsComplete, eligibleScore: eligible?total:null };
}

function EconomyScreen(props){
  const { economy, setEconomy, pair, setPair } = props;
  if(!economy || !economy.data) return null;
  const month = economy.reportingMonth || 'Jul';
  const data = economy.data;
  const pairCcys = [(pair||'EURUSD').slice(0,3), (pair||'EURUSD').slice(3,6)];
  const [tab,setTab] = React.useState('calendar');
  const [ccy,setCcy] = React.useState('USD');
  const [chainId,setChainId] = React.useState('BA');

  function setMonth(m){ setEconomy({...economy, reportingMonth:m}); }
  function updateThesis(c, cid, val){ setEconomy({...economy, data:{...data, [c]:{...data[c], [cid]:{...data[c][cid], thesis:val}}}}); }
  function updateAnchorVerdict(c, cid, idx, val){
    const anchors = data[c][cid].anchors.map((a,i)=> i===idx ? {...a, verdict:val} : a);
    setEconomy({...economy, data:{...data, [c]:{...data[c], [cid]:{...data[c][cid], anchors}}}});
  }
  function addAnchor(c, cid, draft){
    const anchors = [...data[c][cid].anchors, {date:draft.date||month, impact:draft.impact||'Orange', news:draft.news, forecast:draft.forecast||'', previous:draft.previous||'', actual:draft.actual||'', verdict:''}];
    setEconomy({...economy, data:{...data, [c]:{...data[c], [cid]:{...data[c][cid], anchors}}}});
  }
  function removeAnchor(c, cid, idx){
    const anchors = data[c][cid].anchors.filter((_,i)=>i!==idx);
    setEconomy({...economy, data:{...data, [c]:{...data[c], [cid]:{...data[c][cid], anchors}}}});
  }
  const [showAddForm,setShowAddForm] = React.useState(false);
  const [draft,setDraft] = React.useState({date:'',impact:'Orange',news:'',forecast:'',previous:'',actual:''});
  React.useEffect(()=>{ setShowAddForm(false); setDraft({date:'',impact:'Orange',news:'',forecast:'',previous:'',actual:''}); },[ccy,chainId]);
  function updateAnchorField(c, cid, idx, field, val){
    const anchors = data[c][cid].anchors.map((a,i)=> i===idx ? {...a, [field]:val} : a);
    setEconomy({...economy, data:{...data, [c]:{...data[c], [cid]:{...data[c][cid], anchors}}}});
  }
  const allEvents = [];
  CCYS.forEach(c=>CHAINS.forEach(ch=>{
    (data[c][ch.id].anchors||[]).forEach((a,idx)=>{ allEvents.push({...a, ccy:c, chainId:ch.id, chainLabel:ch.label, idx}); });
  }));
  const monthOrder = {Jul:0,Aug:1};
  allEvents.sort((a,b)=>{
    const ma = monthOrder[a.date.slice(0,3)] !== undefined ? monthOrder[a.date.slice(0,3)] : 9;
    const mb = monthOrder[b.date.slice(0,3)] !== undefined ? monthOrder[b.date.slice(0,3)] : 9;
    if(ma!==mb) return ma-mb;
    return (parseInt(a.date.slice(3))||0) - (parseInt(b.date.slice(3))||0);
  });
  const [calFilter,setCalFilter] = React.useState('all');
  const [calScope,setCalScope] = React.useState('pair');
  const [expandedEvent,setExpandedEvent] = React.useState(null);
  const scopedEvents = calScope==='pair' ? allEvents.filter(e=>pairCcys.includes(e.ccy)) : allEvents;
  const calEvents = scopedEvents.filter(e=> calFilter==='all' ? true : calFilter==='pending' ? !e.actual : !!e.actual);

  const computed = {};
  CCYS.forEach(c=>{ computed[c] = computeCurrency(data[c], month); });
  const eligibleList = CCYS.filter(c=>computed[c].eligible).map(c=>({c, score:computed[c].eligibleScore})).sort((a,b)=>b.score-a.score);
  let pairResult;
  if(eligibleList.length<2){
    pairResult = { status:'insufficient', text:'NOT ENOUGH ELIGIBLE CURRENCIES — fewer than 2 pass the PMTS Eligibility Rule' };
  } else {
    const strongest = eligibleList[0], weakest = eligibleList[eligibleList.length-1];
    const gap = strongest.score - weakest.score;
    const confidence = gap>=8?'Very High':gap>=5?'High':gap>=3?'Moderate':'—';
    pairResult = { status: gap>=3?'candidate':'no-trade', strongest, weakest, gap, confidence };
  }
  const TABS = [{id:'calendar',label:'Calendar'},{id:'evidence',label:'Evidence'},{id:'rankings',label:'Rankings'},{id:'pair',label:'Pair Select'}];
  const chain = data[ccy][chainId];
  const chainStatus = computed[ccy].statuses[chainId];

  return (
    <div style={{position:'absolute',top:58,left:0,right:0,bottom:64,overflowY:'auto',padding:16}}>
      <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:2}}>
        <div style={{color:'var(--accent-primary)',fontSize:18,fontWeight:800}}>Economic Ranking 🌐</div>
        <select value={month} onChange={e=>setMonth(e.target.value)} style={{padding:'5px 8px',background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:8,color:'var(--accent-primary)',fontSize:11,fontWeight:700,fontFamily:'var(--font-mono)'}}>
          {['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'].map(m=><option key={m} value={m}>{m}</option>)}
        </select>
      </div>
      <div style={{color:'var(--text-muted)',fontSize:11,marginBottom:4}}>Evidence-based currency ranking & pair selection engine</div>
      <div style={{color:'var(--text-muted)',fontSize:10,marginBottom:12,fontStyle:'italic'}}>From your PMTS Economic Ranking workbook — not part of the original app</div>
      <div style={{display:'flex',gap:6,marginBottom:14}}>
        {TABS.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{flex:1,padding:'8px 6px',borderRadius:8,fontSize:11,fontWeight:700,cursor:'pointer',
            background: tab===t.id ? 'var(--accent-primary)' : 'var(--bg-surface-alt)', color: tab===t.id ? '#0a0800' : 'var(--text-muted)', border:'1px solid var(--border-default)'}}>{t.label}</button>
        ))}
      </div>

      {tab==='calendar' && (
        <div>
          <div style={{fontSize:10,color:'var(--text-muted)',marginBottom:10,lineHeight:1.5}}>All logged anchor events across every currency, in date order. Enter the Actual value as soon as a print comes out — it updates the same record shown on the Evidence tab.</div>
          <div style={{display:'flex',gap:6,marginBottom:8}}>
            {[{id:'pair',label:'This Pair ('+pairCcys.join('/')+')'},{id:'all',label:'All Currencies'}].map(s=>(
              <button key={s.id} onClick={()=>setCalScope(s.id)} style={{flex:1,padding:'7px 8px',borderRadius:8,fontSize:10,fontWeight:700,cursor:'pointer',
                background: calScope===s.id ? 'var(--surface-gold-tint)' : 'var(--bg-surface-alt)', color: calScope===s.id ? 'var(--accent-primary)' : 'var(--text-muted)', border:'1px solid '+(calScope===s.id?'var(--border-gold)':'var(--border-default)')}}>{s.label}</button>
            ))}
          </div>
          <div style={{display:'flex',gap:6,marginBottom:12}}>
            {[{id:'all',label:'All'},{id:'pending',label:'Pending'},{id:'released',label:'Released'}].map(f=>(
              <button key={f.id} onClick={()=>setCalFilter(f.id)} style={{flex:1,padding:'7px 8px',borderRadius:8,fontSize:11,fontWeight:700,cursor:'pointer',
                background: calFilter===f.id ? 'var(--accent-primary)' : 'var(--bg-surface-alt)', color: calFilter===f.id ? '#0a0800' : 'var(--text-muted)', border:'1px solid var(--border-default)'}}>{f.label}</button>
            ))}
          </div>
          <div style={{display:'flex',flexDirection:'column',gap:6}}>
            {calEvents.length===0 && <div style={{fontSize:11,color:'var(--text-muted)',textAlign:'center',padding:20}}>No events match this filter.</div>}
            {calEvents.map((e,i)=>{
              const key = e.ccy+'-'+e.chainId+'-'+e.idx;
              const released = !!e.actual;
              return (
                <div key={key} style={{background:'var(--bg-surface)',border:'1px solid var(--border-default)',borderRadius:10,padding:10}}>
                  <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:4}}>
                    <div style={{fontSize:10,color:'var(--text-muted)',fontFamily:'var(--font-mono)'}}>{e.date} · {e.ccy} · {e.chainLabel}</div>
                    <Badge tone={released?'green':'amber'}>{released?'RELEASED':'PENDING'}</Badge>
                  </div>
                  <div style={{fontSize:13,color:'var(--text-hi)',fontWeight:600,marginBottom:released?6:8}}>{e.news}</div>
                  {released ? (
                    <div style={{fontSize:11,color:'var(--text-dim)',fontFamily:'var(--font-mono)',display:'flex',gap:12}}>
                      <span>Actual: <b style={{color:'var(--accent-primary)'}}>{e.actual}</b></span>
                      {e.forecast && <span>Forecast: {e.forecast}</span>}
                      {e.verdict && <span style={{color: e.verdict==='Supports Thesis'?'var(--accent-success)':e.verdict==='Rejects Thesis'?'var(--accent-danger)':'var(--text-muted)'}}>{e.verdict}</span>}
                    </div>
                  ) : expandedEvent===key ? (
                    <div style={{display:'flex',flexDirection:'column',gap:6}}>
                      <input autoFocus placeholder="Enter actual value" value={e.actual} onChange={ev=>updateAnchorField(e.ccy,e.chainId,e.idx,'actual',ev.target.value)}
                        style={{padding:'7px 8px',background:'var(--bg-page)',border:'1px solid var(--border-gold)',borderRadius:6,color:'var(--text-hi)',fontSize:11,boxSizing:'border-box'}}/>
                      <select value={e.verdict} onChange={ev=>updateAnchorField(e.ccy,e.chainId,e.idx,'verdict',ev.target.value)} style={{padding:'7px 8px',background:'var(--bg-page)',border:'1px solid var(--border-default)',borderRadius:6,fontSize:11,color:'var(--text-hi)'}}>
                        {VERDICTS.map(v=><option key={v} value={v}>{v||'— Operator Verdict —'}</option>)}
                      </select>
                      <div style={{display:'flex',gap:6}}>
                        <button onClick={()=>setExpandedEvent(null)} style={{flex:1,padding:8,background:'var(--accent-primary)',border:'none',borderRadius:6,color:'#0a0800',fontWeight:700,fontSize:11,cursor:'pointer'}}>Done</button>
                      </div>
                    </div>
                  ) : (
                    <button onClick={()=>setExpandedEvent(key)} style={{padding:'6px 10px',background:'var(--bg-surface-alt)',border:'1px dashed var(--border-gold)',borderRadius:6,color:'var(--accent-primary)',fontSize:11,fontWeight:700,cursor:'pointer'}}>Enter Actual →</button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      )}

      {tab==='evidence' && (
        <div>
          <div className="pm-hscroll" style={{display:'flex',gap:6,marginBottom:10,overflowX:'auto'}}>
            {CCYS.map(c=>(
              <button key={c} onClick={()=>setCcy(c)} style={{padding:'6px 12px',borderRadius:20,fontSize:11,fontWeight:700,cursor:'pointer',flexShrink:0,
                background: ccy===c ? 'var(--accent-primary)' : 'var(--bg-surface-alt)', color: ccy===c ? '#0a0800' : 'var(--text-muted)', border:'1px solid var(--border-default)'}}>{c}</button>
            ))}
          </div>
          <div className="pm-hscroll" style={{display:'flex',gap:6,marginBottom:12,overflowX:'auto'}}>
            {CHAINS.map(c=>(
              <button key={c.id} onClick={()=>setChainId(c.id)} style={{padding:'6px 10px',borderRadius:8,fontSize:10,fontWeight:700,cursor:'pointer',flexShrink:0,
                background: chainId===c.id ? 'var(--surface-gold-tint)' : 'var(--bg-surface-alt)', color: chainId===c.id ? 'var(--accent-primary)' : 'var(--text-muted)', border:'1px solid '+(chainId===c.id?'var(--border-gold)':'var(--border-default)')}}>{c.label}</button>
            ))}
          </div>
          <div style={{background:'var(--bg-surface)',border:'1px solid var(--border-default)',borderRadius:10,padding:12,marginBottom:10}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:6}}>
              <div style={{fontSize:13,fontWeight:700,color:'var(--text-hi)'}}>{CHAINS.find(c=>c.id===chainId).label}</div>
              <Badge tone={CORE.includes(chainId)?'amber':'muted'}>{CORE.includes(chainId)?'CORE':'SUPPORT'}</Badge>
            </div>
            <div style={{fontSize:10,color:'var(--text-muted)',marginBottom:10,lineHeight:1.4}}>{chain.question}</div>
            <div style={{display:'flex',gap:8,alignItems:'center',marginBottom:4}}>
              <span style={{fontSize:10,color:'var(--text-muted)'}}>Chain Thesis:</span>
              <select value={chain.thesis} onChange={e=>updateThesis(ccy,chainId,e.target.value)} style={{flex:1,padding:'6px 8px',background:'var(--bg-page)',border:'1px solid var(--border-gold)',borderRadius:8,color:'var(--text-hi)',fontSize:11}}>
                {THESES.map(s=><option key={s} value={s}>{s}</option>)}
              </select>
              <Badge tone={chainStatus==='Thesis Complete'?'green':chainStatus==='Collecting Evidence'?'amber':'muted'}>{chainStatus.toUpperCase()}</Badge>
            </div>
            {(()=>{ const suggestion = suggestThesis(chain); return suggestion && suggestion!==chain.thesis && (
              <div style={{marginTop:6,display:'flex',alignItems:'center',gap:6,fontSize:10,color:'var(--text-muted)'}}>
                Suggested from verdicts: <b style={{color:'var(--accent-primary)'}}>{suggestion}</b>
                <button onClick={()=>updateThesis(ccy,chainId,suggestion)} style={{padding:'3px 8px',background:'var(--surface-gold-tint)',border:'1px solid var(--border-gold)',borderRadius:12,color:'var(--accent-primary)',fontSize:10,fontWeight:700,cursor:'pointer'}}>Use</button>
              </div>
            ); })()}
          </div>
          <div style={{fontSize:10,color:'var(--text-muted)',marginBottom:6,fontWeight:700,letterSpacing:'.05em'}}>ANCHOR REPORTS ({month})</div>
          <div style={{display:'flex',flexDirection:'column',gap:6,marginBottom:10}}>
            {chain.anchors.length===0 && <div style={{fontSize:11,color:'var(--text-muted)',padding:10,textAlign:'center'}}>No anchor reports logged yet.</div>}
            {chain.anchors.map((a,i)=>(
              <div key={i} style={{background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:8,padding:10}}>
                <div style={{display:'flex',justifyContent:'space-between',fontSize:10,color:'var(--text-muted)',fontFamily:'var(--font-mono)',marginBottom:3}}>
                  <span>{a.date} · {a.impact}</span>
                  {a.actual && <span>Actual: <b style={{color:'var(--text-hi)'}}>{a.actual}</b></span>}
                </div>
                <div style={{fontSize:12,color:'var(--text-hi)',fontWeight:600,marginBottom:6}}>{a.news}</div>
                {(a.forecast || a.previous) && (
                  <div style={{display:'flex',gap:12,fontSize:10,color:'var(--text-muted)',fontFamily:'var(--font-mono)',marginBottom:6}}>
                    {a.forecast && <span>Forecast: {a.forecast}</span>}
                    {a.previous && <span>Previous: {a.previous}</span>}
                  </div>
                )}
                <div style={{display:'flex',gap:6}}>
                  <select value={a.verdict} onChange={e=>updateAnchorVerdict(ccy,chainId,i,e.target.value)} style={{flex:1,padding:'6px 8px',background:'var(--bg-page)',border:'1px solid var(--border-default)',borderRadius:6,fontSize:11,
                    color: a.verdict==='Supports Thesis'?'var(--accent-success)':a.verdict==='Rejects Thesis'?'var(--accent-danger)':'var(--text-muted)'}}>
                    {VERDICTS.map(v=><option key={v} value={v}>{v||'— Operator Verdict —'}</option>)}
                  </select>
                  <button onClick={()=>removeAnchor(ccy,chainId,i)} style={{padding:'6px 10px',background:'transparent',border:'1px solid var(--border-default)',borderRadius:6,color:'var(--text-muted)',cursor:'pointer',fontSize:12}}>🗑️</button>
                </div>
              </div>
            ))}
          </div>
          {!showAddForm ? (
            <button onClick={()=>setShowAddForm(true)} style={{width:'100%',padding:10,background:'var(--bg-surface-alt)',border:'1.5px dashed var(--border-gold)',borderRadius:8,color:'var(--accent-primary)',fontSize:11,fontWeight:700,cursor:'pointer'}}>+ Add Anchor Report</button>
          ) : (
            <div style={{background:'var(--bg-surface)',border:'1.5px solid var(--border-gold)',borderRadius:10,padding:12,display:'flex',flexDirection:'column',gap:8}}>
              <div style={{fontSize:11,fontWeight:700,color:'var(--text-hi)',marginBottom:2}}>New Anchor Report</div>
              <div style={{display:'flex',gap:8}}>
                <div style={{flex:1}}>
                  <div style={{fontSize:9,color:'var(--text-muted)',marginBottom:3}}>Date</div>
                  <input value={draft.date} onChange={e=>setDraft({...draft,date:e.target.value})} placeholder={month+' 12'} style={{width:'100%',padding:'7px 8px',background:'var(--bg-page)',border:'1px solid var(--border-default)',borderRadius:6,color:'var(--text-hi)',fontSize:11,boxSizing:'border-box'}}/>
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:9,color:'var(--text-muted)',marginBottom:3}}>Impact</div>
                  <select value={draft.impact} onChange={e=>setDraft({...draft,impact:e.target.value})} style={{width:'100%',padding:'7px 8px',background:'var(--bg-page)',border:'1px solid var(--border-default)',borderRadius:6,color:'var(--text-hi)',fontSize:11}}>
                    <option value="Red">Red</option><option value="Orange">Orange</option><option value="Yellow">Yellow</option>
                  </select>
                </div>
              </div>
              <div>
                <div style={{fontSize:9,color:'var(--text-muted)',marginBottom:3}}>News Event</div>
                <input value={draft.news} onChange={e=>setDraft({...draft,news:e.target.value})} placeholder="e.g. ISM Manufacturing PMI" style={{width:'100%',padding:'7px 8px',background:'var(--bg-page)',border:'1px solid var(--border-default)',borderRadius:6,color:'var(--text-hi)',fontSize:11,boxSizing:'border-box'}}/>
              </div>
              <div style={{display:'flex',gap:8}}>
                <div style={{flex:1}}>
                  <div style={{fontSize:9,color:'var(--text-muted)',marginBottom:3}}>Forecast</div>
                  <input value={draft.forecast} onChange={e=>setDraft({...draft,forecast:e.target.value})} style={{width:'100%',padding:'7px 8px',background:'var(--bg-page)',border:'1px solid var(--border-default)',borderRadius:6,color:'var(--text-hi)',fontSize:11,boxSizing:'border-box'}}/>
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:9,color:'var(--text-muted)',marginBottom:3}}>Previous</div>
                  <input value={draft.previous} onChange={e=>setDraft({...draft,previous:e.target.value})} style={{width:'100%',padding:'7px 8px',background:'var(--bg-page)',border:'1px solid var(--border-default)',borderRadius:6,color:'var(--text-hi)',fontSize:11,boxSizing:'border-box'}}/>
                </div>
                <div style={{flex:1}}>
                  <div style={{fontSize:9,color:'var(--text-muted)',marginBottom:3}}>Actual</div>
                  <input value={draft.actual} onChange={e=>setDraft({...draft,actual:e.target.value})} style={{width:'100%',padding:'7px 8px',background:'var(--bg-page)',border:'1px solid var(--border-default)',borderRadius:6,color:'var(--text-hi)',fontSize:11,boxSizing:'border-box'}}/>
                </div>
              </div>
              <div style={{display:'flex',gap:8,marginTop:4}}>
                <button onClick={()=>{ if(!draft.news.trim()) return; addAnchor(ccy,chainId,draft); setShowAddForm(false); setDraft({date:'',impact:'Orange',news:'',forecast:'',previous:'',actual:''}); }} style={{flex:1,padding:10,background:'var(--accent-primary)',border:'none',borderRadius:8,color:'#0a0800',fontWeight:800,fontSize:12,cursor:'pointer'}}>Add Report</button>
                <button onClick={()=>setShowAddForm(false)} style={{padding:10,background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:8,color:'var(--text-muted)',fontWeight:700,fontSize:12,cursor:'pointer'}}>Cancel</button>
              </div>
            </div>
          )}
        </div>
      )}

      {tab==='rankings' && (
        <div style={{display:'flex',flexDirection:'column',gap:8}}>
          <div style={{fontSize:10,color:'var(--text-muted)',marginBottom:2}}>Strong=+1 · Mixed=0 · Weak=-1 · Eligible requires all 3 core chains + at least 1 support chain "Thesis Complete" for {month}</div>
          {CCYS.slice().sort((a,b)=>computed[b].total-computed[a].total).map(c=>(
            <div key={c} style={{background:'var(--bg-surface)',border:'1px solid var(--border-default)',borderRadius:10,padding:'10px 12px',display:'flex',justifyContent:'space-between',alignItems:'center'}}>
              <div>
                <div style={{fontSize:13,fontWeight:700,color:'var(--text-hi)'}}>{c}</div>
                <div style={{fontSize:10,color:'var(--text-muted)'}}>{computed[c].chainsComplete}/6 chains complete</div>
              </div>
              <div style={{display:'flex',alignItems:'center',gap:10}}>
                <div style={{fontFamily:'var(--font-mono)',fontSize:14,fontWeight:800,color: computed[c].total>0?'var(--accent-success)':computed[c].total<0?'var(--accent-danger)':'var(--text-muted)'}}>{computed[c].total>0?'+':''}{computed[c].total}</div>
                <Badge tone={computed[c].eligible?'green':'muted'}>{computed[c].eligible?'ELIGIBLE':'—'}</Badge>
              </div>
            </div>
          ))}
        </div>
      )}

      {tab==='pair' && (
        <div>
          <div style={{fontSize:11,color:'var(--text-muted)',marginBottom:12}}>{eligibleList.length} of {CCYS.length} currencies meet the PMTS Eligibility Rule for {month}</div>
          {pairResult.status==='insufficient' ? (
            <div style={{padding:16,borderRadius:12,background:'var(--surface-red-tint)',border:'1px solid var(--border-red)',color:'var(--accent-danger)',fontSize:13,fontWeight:700,textAlign:'center',lineHeight:1.5}}>🚫 {pairResult.text}</div>
          ) : (
            <React.Fragment>
              <div style={{display:'flex',gap:8,marginBottom:12}}>
                <div style={{flex:1,background:'var(--surface-green-tint)',border:'1px solid var(--border-green)',borderRadius:10,padding:12,textAlign:'center'}}>
                  <div style={{fontSize:10,color:'var(--text-muted)',marginBottom:4}}>STRONGEST</div>
                  <div style={{fontSize:18,fontWeight:800,color:'var(--accent-success)'}}>{pairResult.strongest.c}</div>
                  <div style={{fontSize:11,fontFamily:'var(--font-mono)',color:'var(--text-dim)'}}>score {pairResult.strongest.score}</div>
                </div>
                <div style={{flex:1,background:'var(--surface-red-tint)',border:'1px solid var(--border-red)',borderRadius:10,padding:12,textAlign:'center'}}>
                  <div style={{fontSize:10,color:'var(--text-muted)',marginBottom:4}}>WEAKEST</div>
                  <div style={{fontSize:18,fontWeight:800,color:'var(--accent-danger)'}}>{pairResult.weakest.c}</div>
                  <div style={{fontSize:11,fontFamily:'var(--font-mono)',color:'var(--text-dim)'}}>score {pairResult.weakest.score}</div>
                </div>
              </div>
              <div style={{padding:16,borderRadius:12,textAlign:'center',marginBottom:12,
                background: pairResult.status==='candidate' ? 'var(--surface-green-tint)':'var(--surface-red-tint)',
                border: '1px solid '+(pairResult.status==='candidate'?'var(--border-green)':'var(--border-red)')}}>
                <div style={{fontSize:15,fontWeight:800,color: pairResult.status==='candidate'?'var(--accent-success)':'var(--accent-danger)',marginBottom:4}}>
                  {pairResult.status==='candidate' ? '✅ '+pairResult.strongest.c+'/'+pairResult.weakest.c : '🚫 NO TRADE'}
                </div>
                <div style={{fontSize:11,color:'var(--text-muted)'}}>Gap {pairResult.gap} · Confidence: {pairResult.confidence}</div>
                {pairResult.status==='candidate' && setPair && (
                  <button onClick={()=>{ setPair(toPairSymbol(pairResult.strongest.c, pairResult.weakest.c)); if(props.navigate) props.navigate('analysis'); }} style={{marginTop:10,padding:'8px 14px',background:'var(--accent-primary)',border:'none',borderRadius:8,color:'#0a0800',fontWeight:800,fontSize:11,cursor:'pointer'}}>Use {toPairSymbol(pairResult.strongest.c, pairResult.weakest.c)} → Go to Analysis</button>
                )}
              </div>
            </React.Fragment>
          )}
          <div style={{fontSize:10,color:'var(--text-muted)',lineHeight:1.6,padding:'0 2px'}}>Operator rule: Gap &lt; 3 = No Trade. Gap ≥ 3 = Candidate Pair, continue to PMTS technical analysis. This tab selects WHICH pair to study — it does not authorize a trade.</div>
        </div>
      )}
    </div>
  );
}
window.EconomyScreen = EconomyScreen;
