const { TopBar, BottomNav, Chip } = window.PumallenOSDesignSystem_ac653c;
const NAV_ITEMS = [
  {id:'analysis',icon:'🔬',label:'Analysis'},
  {id:'chat',icon:'💬',label:'AI Chat'},
  {id:'checklist',icon:'✅',label:'Checks'},
  {id:'calc',icon:'🧮',label:'Calc'},
  {id:'journal',icon:'📒',label:'Journal'},
  {id:'more',icon:'⋯',label:'More'}
];
const SCREENS = {analysis:window.AnalysisScreen, chat:window.ChatScreen, checklist:window.ChecklistScreen, calc:window.CalcScreen, journal:window.JournalScreen, settings:window.SettingsScreen, stats:window.StatsScreen, planner:window.PlannerScreen, narrative:window.NarrativeScreen, history:window.HistoryScreen, economy:window.EconomyScreen, brief:window.BriefScreen};
const DEFAULT_STATE = {
  analysis: {states:{MO:'active',W:'locked',D:'locked',H4:'locked',H1:'locked'}, results:{}, verdict:null},
  checklist: Array(9).fill(false),
  chat: [
    {role:'assistant',content:'PMTS chain of authority loaded. Ask about the current analysis or the 9 conditions.'},
    {role:'user',content:'why did daily stand down?'},
    {role:'assistant',content:'Daily stood down because the weekly plan conflicted with the monthly mission — no permission was granted, so H4/H1 stay locked until it clears.'}
  ],
  journal: [
    {dir:'Long',date:'2026-07-28',entry:'1.0842',sl:'1.0810',tp:'1.0910',result:'Win'},
    {dir:'Short',date:'2026-07-22',entry:'1.0921',sl:'1.0955',tp:'1.0860',result:'Win'},
    {dir:'Long',date:'2026-07-15',entry:'1.0788',sl:'1.0760',tp:'1.0840',result:'Loss'}
  ],
  narrative: [{date:'2026-08-03',body:'EURUSD holding monthly discount, weekly reaction from demand. Watching for daily BOS to confirm.'}],
  pair: 'EURUSD',
  economy: {
    reportingMonth: 'Jul',
    data: {
    USD: {
      BA: {question:'Is business activity expanding or contracting?', thesis:'Strong', anchors:[
        {date:'Jul 1',impact:'Red',news:'ISM Manufacturing PMI',forecast:'',previous:'',actual:'53.3',verdict:'Supports Thesis'},
        {date:'Jul 6',impact:'Red',news:'ISM Services PMI',forecast:'',previous:'',actual:'54.0',verdict:'Supports Thesis'},
        {date:'Aug 3',impact:'Red',news:'ISM Manufacturing PMI',forecast:'',previous:'',actual:'',verdict:''},
        {date:'Aug 5',impact:'Orange',news:'ISM Services PMI',forecast:'',previous:'',actual:'',verdict:''}
      ]},
      LM: {question:'Is the labour market strengthening or weakening?', thesis:'Mixed', anchors:[
        {date:'Jul 1',impact:'Orange',news:'ADP Non-Farm Employment Change',forecast:'',previous:'',actual:'98K',verdict:'Rejects Thesis'},
        {date:'Jul 2',impact:'Red',news:'Average Hourly Earnings m/m',forecast:'0.3%',previous:'0.3%',actual:'0.3%',verdict:'Supports Thesis'},
        {date:'Jul 2',impact:'Red',news:'Non-Farm Employment Change',forecast:'110K',previous:'172K',actual:'57K',verdict:'Rejects Thesis'},
        {date:'Jul 2',impact:'Red',news:'Unemployment Rate',forecast:'4.3%',previous:'4.3%',actual:'4.2%',verdict:'Supports Thesis'},
        {date:'Aug 5',impact:'Orange',news:'ADP Non-Farm Employment Change',forecast:'',previous:'',actual:'',verdict:''},
        {date:'Aug 7',impact:'Red',news:'Average Hourly Earnings m/m',forecast:'',previous:'',actual:'',verdict:''},
        {date:'Aug 7',impact:'Red',news:'Non-Farm Employment Change',forecast:'',previous:'',actual:'',verdict:''},
        {date:'Aug 7',impact:'Red',news:'Unemployment Rate',forecast:'',previous:'',actual:'',verdict:''}
      ]},
      INF: {question:'Is inflation accelerating or cooling?', thesis:'Weak', anchors:[
        {date:'Jul 14',impact:'Red',news:'Core CPI m/m',forecast:'0.2%',previous:'0.2%',actual:'0.0%',verdict:'Rejects Thesis'},
        {date:'Jul 14',impact:'Red',news:'Core CPI y/y',forecast:'2.8%',previous:'2.9%',actual:'2.6%',verdict:'Rejects Thesis'},
        {date:'Jul 14',impact:'Red',news:'CPI m/m',forecast:'-0.1%',previous:'0.5%',actual:'-0.4%',verdict:'Rejects Thesis'},
        {date:'Jul 14',impact:'Red',news:'CPI y/y',forecast:'3.8%',previous:'4.2%',actual:'3.5%',verdict:'Rejects Thesis'},
        {date:'Jul 30',impact:'Red',news:'Core PCE Price Index m/m',forecast:'0.2%',previous:'0.3%',actual:'0.1%',verdict:'Rejects Thesis'},
        {date:'Aug 12',impact:'Red',news:'Core CPI m/m',forecast:'',previous:'',actual:'',verdict:''},
        {date:'Aug 12',impact:'Red',news:'Core CPI y/y',forecast:'',previous:'',actual:'',verdict:''},
        {date:'Aug 12',impact:'Red',news:'CPI m/m',forecast:'',previous:'',actual:'',verdict:''},
        {date:'Aug 12',impact:'Red',news:'CPI y/y',forecast:'',previous:'',actual:'',verdict:''},
        {date:'Aug 26',impact:'Red',news:'Core PCE Price Index m/m',forecast:'',previous:'',actual:'',verdict:''}
      ]},
      CON: {question:'Is the consumer becoming stronger or weaker?', thesis:'Mixed', anchors:[
        {date:'Jul 16',impact:'Orange',news:'Core Retail Sales m/m',forecast:'0.0%',previous:'1.0%',actual:'-0.2%',verdict:'Rejects Thesis'},
        {date:'Jul 16',impact:'Orange',news:'Retail Sales m/m',forecast:'0.2%',previous:'1.0%',actual:'0.2%',verdict:'Supports Thesis'},
        {date:'Jul 28',impact:'Orange',news:'CB Consumer Confidence',forecast:'',previous:'',actual:'90.8',verdict:'Rejects Thesis'},
        {date:'Aug 25',impact:'Orange',news:'CB Consumer Confidence',forecast:'',previous:'',actual:'',verdict:''}
      ]},
      GRO: {question:'Is economic growth improving or slowing?', thesis:'Weak', anchors:[
        {date:'Jul 30',impact:'Red',news:'Advance GDP q/q',forecast:'2.1%',previous:'2.1%',actual:'1.5%',verdict:'Rejects Thesis'},
        {date:'Aug 26',impact:'Red',news:'Prelim GDP q/q',forecast:'',previous:'',actual:'',verdict:''}
      ]},
      CB: {question:'Based on the completed economic chains, is monetary policy likely to become more hawkish, more dovish, or remain unchanged?', thesis:'Mixed', anchors:[
        {date:'Jul 29',impact:'Red',news:'Federal Funds Rate',forecast:'3.75%',previous:'3.75%',actual:'3.75%',verdict:'Supports Thesis'}
      ]}
    },
    EUR: {
      BA: {question:'Is business activity expanding or contracting?', thesis:'Mixed', anchors:[{date:'Aug 21',impact:'Orange',news:'French Flash Manufacturing PMI',forecast:'',previous:'',actual:'',verdict:''},{date:'Aug 21',impact:'Orange',news:'French Flash Services PMI',forecast:'',previous:'',actual:'',verdict:''},{date:'Aug 21',impact:'Orange',news:'German Flash Manufacturing PMI',forecast:'',previous:'',actual:'',verdict:''},{date:'Aug 21',impact:'Orange',news:'German Flash Services PMI',forecast:'',previous:'',actual:'',verdict:''}]},
      LM: {question:'Is the labour market strengthening or weakening?', thesis:'Mixed', anchors:[]},
      INF: {question:'Is inflation accelerating or cooling?', thesis:'Mixed', anchors:[]},
      CON: {question:'Is the consumer becoming stronger or weaker?', thesis:'Mixed', anchors:[]},
      GRO: {question:'Is economic growth improving or slowing?', thesis:'Mixed', anchors:[]},
      CB: {question:'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?', thesis:'Mixed', anchors:[]}
    },
    GBP: {
      BA: {question:'Is business activity expanding or contracting?', thesis:'Mixed', anchors:[{date:'Jul 24',impact:'Orange',news:'Flash Manufacturing PMI',forecast:'',previous:'',actual:'52.8',verdict:''},{date:'Jul 24',impact:'Orange',news:'Flash Services PMI',forecast:'',previous:'',actual:'51.8',verdict:''},{date:'Aug 21',impact:'Orange',news:'Flash Manufacturing PMI',forecast:'',previous:'',actual:'',verdict:''},{date:'Aug 21',impact:'Orange',news:'Flash Services PMI',forecast:'',previous:'',actual:'',verdict:''}]},
      LM: {question:'Is the labour market strengthening or weakening?', thesis:'Mixed', anchors:[]},
      INF: {question:'Is inflation accelerating or cooling?', thesis:'Mixed', anchors:[]},
      CON: {question:'Is the consumer becoming stronger or weaker?', thesis:'Mixed', anchors:[]},
      GRO: {question:'Is economic growth improving or slowing?', thesis:'Mixed', anchors:[]},
      CB: {question:'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?', thesis:'Mixed', anchors:[]}
    },
    JPY: {
      BA: {question:'Is business activity expanding or contracting?', thesis:'Mixed', anchors:[]},
      LM: {question:'Is the labour market strengthening or weakening?', thesis:'Mixed', anchors:[]},
      INF: {question:'Is inflation accelerating or cooling?', thesis:'Mixed', anchors:[]},
      CON: {question:'Is the consumer becoming stronger or weaker?', thesis:'Mixed', anchors:[]},
      GRO: {question:'Is economic growth improving or slowing?', thesis:'Mixed', anchors:[]},
      CB: {question:'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?', thesis:'Mixed', anchors:[{date:'Jul 31',impact:'Red',news:'BOJ Policy Rate',forecast:'',previous:'',actual:'',verdict:''}]}
    },
    AUD: {
      BA: {question:'Is business activity expanding or contracting?', thesis:'Mixed', anchors:[]},
      LM: {question:'Is the labour market strengthening or weakening?', thesis:'Strong', anchors:[{date:'Jul 17',impact:'Red',news:'Employment Change',forecast:'',previous:'',actual:'',verdict:'Supports Thesis'}]},
      INF: {question:'Is inflation accelerating or cooling?', thesis:'Weak', anchors:[{date:'Jul 30',impact:'Red',news:'CPI q/q',forecast:'',previous:'',actual:'',verdict:'Rejects Thesis'}]},
      CON: {question:'Is the consumer becoming stronger or weaker?', thesis:'Mixed', anchors:[]},
      GRO: {question:'Is economic growth improving or slowing?', thesis:'Mixed', anchors:[]},
      CB: {question:'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?', thesis:'Mixed', anchors:[]}
    },
    CAD: {
      BA: {question:'Is business activity expanding or contracting?', thesis:'Mixed', anchors:[{date:'Jul 7',impact:'Orange',news:'Ivey PMI',forecast:'',previous:'',actual:'56.2',verdict:''},{date:'Aug 7',impact:'Orange',news:'Ivey PMI',forecast:'',previous:'',actual:'',verdict:''}]},
      LM: {question:'Is the labour market strengthening or weakening?', thesis:'Mixed', anchors:[]},
      INF: {question:'Is inflation accelerating or cooling?', thesis:'Mixed', anchors:[]},
      CON: {question:'Is the consumer becoming stronger or weaker?', thesis:'Mixed', anchors:[]},
      GRO: {question:'Is economic growth improving or slowing?', thesis:'Mixed', anchors:[]},
      CB: {question:'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?', thesis:'Mixed', anchors:[]}
    },
    CHF: {
      BA: {question:'Is business activity expanding or contracting?', thesis:'Mixed', anchors:[]},
      LM: {question:'Is the labour market strengthening or weakening?', thesis:'Mixed', anchors:[]},
      INF: {question:'Is inflation accelerating or cooling?', thesis:'Mixed', anchors:[{date:'Jul 3',impact:'Orange',news:'CPI m/m',forecast:'',previous:'',actual:'',verdict:''}]},
      CON: {question:'Is the consumer becoming stronger or weaker?', thesis:'Mixed', anchors:[]},
      GRO: {question:'Is economic growth improving or slowing?', thesis:'Mixed', anchors:[]},
      CB: {question:'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?', thesis:'Mixed', anchors:[]}
    },
    NZD: {
      BA: {question:'Is business activity expanding or contracting?', thesis:'Mixed', anchors:[]},
      LM: {question:'Is the labour market strengthening or weakening?', thesis:'Mixed', anchors:[]},
      INF: {question:'Is inflation accelerating or cooling?', thesis:'Mixed', anchors:[{date:'Jul 21',impact:'Orange',news:'CPI q/q',forecast:'',previous:'',actual:'',verdict:''}]},
      CON: {question:'Is the consumer becoming stronger or weaker?', thesis:'Mixed', anchors:[]},
      GRO: {question:'Is economic growth improving or slowing?', thesis:'Mixed', anchors:[]},
      CB: {question:'Is monetary policy likely to become more hawkish, more dovish, or remain unchanged?', thesis:'Mixed', anchors:[{date:'Aug 20',impact:'Red',news:'RBNZ Official Cash Rate',forecast:'',previous:'',actual:'',verdict:''}]}
    }
    }
  }
};
const STORAGE_KEY = 'pmallen_os_demo_state';
function loadInitial(){
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if(raw){
      const parsed = JSON.parse(raw);
      const economy = (parsed.economy && parsed.economy.data)
        ? {reportingMonth: parsed.economy.reportingMonth||DEFAULT_STATE.economy.reportingMonth, data:{...DEFAULT_STATE.economy.data, ...parsed.economy.data}}
        : DEFAULT_STATE.economy;
      return {...DEFAULT_STATE, ...parsed, economy};
    }
  } catch(e){}
  return DEFAULT_STATE;
}
function App(){
  const [tab,setTab] = React.useState('analysis');
  const [moreOpen,setMoreOpen] = React.useState(false);
  const [appState,setAppState] = React.useState(loadInitial);
  React.useEffect(()=>{
    try { localStorage.setItem(STORAGE_KEY, JSON.stringify(appState)); } catch(e){}
  },[appState]);
  const patch = (key, val) => setAppState(s=>({...s,[key]: typeof val==='function' ? val(s[key]) : val}));
  function resetAll(){
    try { localStorage.removeItem(STORAGE_KEY); } catch(e){}
    setAppState(DEFAULT_STATE);
  }
  const ACCENTS = { gold:{primary:'#f0c040',deep:'#d4a017'}, silver:{primary:'#c7cdd6',deep:'#9aa2ac'}, green:{primary:'#00e87a',deep:'#00b862'} };
  React.useEffect(()=>{
    const a = ACCENTS[appState.accent||'gold'];
    document.documentElement.style.setProperty('--gold', a.primary);
    document.documentElement.style.setProperty('--gold-deep', a.deep);
  },[appState.accent]);
  const day = new Date().getDay();
  const dayNames = ['SUN','MON','TUE','WED','THU','FRI','SAT'];
  const dayLabel = dayNames[day] + (day>=2&&day<=4?' · EXECUTE':day===1?' · ANALYSIS':' · NO TRADE');
  const dayTone = day>=2&&day<=4 ? 'exec' : (day===5||day===0||day===6) ? 'warn' : 'default';
  const [now,setNow] = React.useState(new Date());
  React.useEffect(()=>{ const t=setInterval(()=>setNow(new Date()),1000); return ()=>clearInterval(t); },[]);
  const sast = new Date(now.getTime() + 2*60*60*1000);
  const sastMinutes = sast.getUTCHours()*60 + sast.getUTCMinutes();
  const sastTime = String(sast.getUTCHours()).padStart(2,'0')+':'+String(sast.getUTCMinutes()).padStart(2,'0')+':'+String(sast.getUTCSeconds()).padStart(2,'0');
  const SESSION_DEFS = [{n:'London',o:540,c:1080,e:true},{n:'NY',o:840,c:1380,e:true},{n:'Asian',o:0,c:540,e:false}];
  const sessions = SESSION_DEFS.map(s=>{
    const isOpen = sastMinutes>=s.o && sastMinutes<s.c;
    return {n:s.n, tone: isOpen ? (s.e?'open':'obs') : 'default', label: isOpen?'OPEN':'CLOSED'};
  });
  function select(id){
    if(id==='more'){ setMoreOpen(v=>!v); return; }
    setMoreOpen(false);
    setTab(id);
  }
  const Screen = SCREENS[tab] || window.AnalysisScreen;
  return (
    <div style={{position:'absolute',inset:0,background:'var(--bg-page)',color:'var(--text-hi)'}}>
      <TopBar title="PUMALLEN OS" subtitle={'Master Trading System · '+(appState.pair||'EURUSD')}>
        <div style={{display:'flex',alignItems:'center',gap:6}}>
          <Chip tone={dayTone}>{dayLabel}</Chip>
          <Chip tone="obs" dense dot={false}>SAST {sastTime}</Chip>
        </div>
      </TopBar>
      {tab==='analysis' && (
        <div className="pm-hscroll" style={{position:'absolute',top:58,left:0,right:0,zIndex:100,display:'flex',gap:4,padding:'5px 8px',overflowX:'auto',background:'rgba(10,8,0,.9)',borderBottom:'1px solid var(--bg-surface-alt)'}}>
          {sessions.map(s=><Chip key={s.n} tone={s.tone} dense>{s.n} {s.label}</Chip>)}
        </div>
      )}
      <div key={tab} className="pm-screen" style={{position:'absolute',inset:0}}>
        <Screen
          analysis={appState.analysis} setAnalysis={v=>patch('analysis',v)}
          checklist={appState.checklist} setChecklist={v=>patch('checklist',v)}
          chat={appState.chat} setChat={v=>patch('chat',v)}
          journal={appState.journal} setJournal={v=>patch('journal',v)}
          narrative={appState.narrative} setNarrative={v=>patch('narrative',v)}
          resetAll={resetAll} accent={appState.accent||'gold'} setAccent={v=>patch('accent',v)}
          navigate={select} pair={appState.pair||'EURUSD'} setPair={v=>patch('pair',v)}
          economy={appState.economy} setEconomy={v=>patch('economy',v)}
        />
      </div>
      {moreOpen && (
        <div style={{position:'absolute',bottom:64,left:0,right:0,background:'var(--bg-surface)',borderTop:'1px solid var(--border-default)',padding:12,zIndex:9998}}>
          <div style={{display:'grid',gridTemplateColumns:'repeat(4,1fr)',gap:8}}>
            {[{id:'stats',icon:'📊',label:'Stats'},{id:'planner',icon:'📅',label:'Planner'},{id:'narrative',icon:'📝',label:'Narrative'},{id:'history',icon:'🗂',label:'History'},{id:'economy',icon:'🌐',label:'Economy'},{id:'brief',icon:'🧾',label:'Brief'},{id:'settings',icon:'⚙️',label:'Settings'}].map(it=>(
              <div key={it.id} onClick={()=>{setMoreOpen(false);setTab(it.id);}} style={{display:'flex',flexDirection:'column',alignItems:'center',gap:5,padding:'12px 6px',background:'var(--bg-surface-alt)',borderRadius:10,cursor:'pointer',fontSize:10,color:'var(--text-dim)'}}>
                <span style={{fontSize:22}}>{it.icon}</span>{it.label}
              </div>
            ))}
          </div>
        </div>
      )}
      <BottomNav items={NAV_ITEMS} active={tab} onSelect={select} />
    </div>
  );
}
ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
