const { TextField, Select } = window.PumallenOSDesignSystem_ac653c;
const JR_CHAINS = ['BA','LM','INF','CON','GRO','CB'];
const JR_CORE = ['BA','LM','INF']; const JR_SUPPORT = ['CON','GRO','CB'];
const JR_SCORE = {Strong:1, Mixed:0, Weak:-1};
const JR_USD_ORDER = ['EUR','GBP','AUD','NZD'];
function jrPairSymbol(a,b){
  if(a==='USD' && JR_USD_ORDER.includes(b)) return b+'USD';
  if(b==='USD' && JR_USD_ORDER.includes(a)) return a+'USD';
  if(a==='USD') return 'USD'+b;
  if(b==='USD') return 'USD'+a;
  return a+b;
}
function computeEconomyCandidate(economy){
  if(!economy || !economy.data) return null;
  const month = economy.reportingMonth || 'Jul';
  const results = Object.keys(economy.data).map(c=>{
    const cd = economy.data[c];
    let total=0; const complete={};
    JR_CHAINS.forEach(id=>{
      total += JR_SCORE[cd[id].thesis];
      const anchors = cd[id].anchors||[];
      const monthAnchors = anchors.filter(a=>a.date && a.date.slice(0,3)===month);
      const answered = monthAnchors.filter(a=>a.verdict);
      complete[id] = monthAnchors.length>0 && answered.length===monthAnchors.length;
    });
    const eligible = JR_CORE.every(id=>complete[id]) && JR_SUPPORT.some(id=>complete[id]);
    return {c, total, eligible};
  }).filter(r=>r.eligible).sort((a,b)=>b.total-a.total);
  if(results.length<2) return null;
  const strongest = results[0], weakest = results[results.length-1];
  const gap = strongest.total - weakest.total;
  if(gap<3) return null;
  return { pairSymbol: jrPairSymbol(strongest.c, weakest.c), strongest: strongest.c, weakest: weakest.c, gap };
}
function JournalScreen(props){
  const { journal, setJournal, pair, economy } = props;
  const candidate = computeEconomyCandidate(economy);
  const [linkEconomy,setLinkEconomy] = React.useState(false);
  const [dir,setDir] = React.useState('Long');
  const [date,setDate] = React.useState('');
  const [entry,setEntry] = React.useState('');
  const [sl,setSl] = React.useState('');
  const [tp,setTp] = React.useState('');
  const [result,setResult] = React.useState('Open');
  function add(){
    if(!entry.trim()) return;
    const source = (linkEconomy && candidate) ? `Economic Ranking: ${candidate.strongest}/${candidate.weakest} (gap ${candidate.gap})` : null;
    setJournal([{dir,date:date||new Date().toISOString().slice(0,10),entry,sl,tp,result,pair:pair||'EURUSD',source},...journal]);
    setDate('');setEntry('');setSl('');setTp('');setResult('Open');setLinkEconomy(false);
  }
  function remove(i){ setJournal(journal.filter((_,j)=>j!==i)); }
  function updateResult(i, val){ setJournal(journal.map((e,j)=>j===i?{...e,result:val}:e)); }
  function exportSummary(){
    const text = journal.map(e=>`${e.date} · ${e.dir} · Entry ${e.entry} SL ${e.sl} TP ${e.tp} · ${e.result}`).join('\n');
    navigator.clipboard && navigator.clipboard.writeText(text).catch(()=>{});
    alert('Journal summary copied to clipboard:\n\n'+text);
  }
  return (
    <div style={{position:'absolute',top:58,left:0,right:0,bottom:64,overflowY:'auto',padding:16}}>
      <div style={{color:'var(--accent-primary)',fontSize:18,fontWeight:800,marginBottom:2}}>Trade Journal 📒</div>
      <div style={{color:'var(--text-muted)',fontSize:11,marginBottom:14}}>Log every trade per PMTS governance · new entries tagged {pair||'EURUSD'}</div>
      <div style={{background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:12,padding:14,marginBottom:14,display:'flex',flexDirection:'column',gap:8}}>
        <div style={{display:'flex',gap:8}}><Select options={['Long','Short']} value={dir} onChange={e=>setDir(e.target.value)} /><TextField placeholder="Date" value={date} onChange={e=>setDate(e.target.value)} /></div>
        <div style={{display:'flex',gap:8}}><TextField placeholder="Entry" value={entry} onChange={e=>setEntry(e.target.value)} /><TextField placeholder="SL" value={sl} onChange={e=>setSl(e.target.value)} /><TextField placeholder="TP" value={tp} onChange={e=>setTp(e.target.value)} /></div>
        <Select options={['Open','Win','Loss','Breakeven']} value={result} onChange={e=>setResult(e.target.value)} />
        <TextField type="textarea" placeholder="Notes..." />
        {candidate && (
          <label style={{display:'flex',alignItems:'center',gap:8,fontSize:11,color:'var(--text-muted)',cursor:'pointer'}}>
            <input type="checkbox" checked={linkEconomy} onChange={e=>setLinkEconomy(e.target.checked)} />
            🌐 Tag with current Economic Ranking pick ({candidate.strongest}/{candidate.weakest}, gap {candidate.gap})
          </label>
        )}
        <button onClick={add} style={{width:'100%',marginTop:2,padding:11,background:'var(--accent-primary)',border:'none',borderRadius:10,color:'#0a0800',fontWeight:800,fontSize:13,cursor:'pointer'}}>+ Add Entry</button>
      </div>
      <div style={{display:'flex',justifyContent:'flex-end',marginBottom:8}}>
        <button onClick={exportSummary} style={{padding:'7px 12px',background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:8,color:'var(--text-muted)',fontSize:11,fontWeight:700,cursor:'pointer'}}>📋 Export Summary</button>
      </div>
      {journal.map((e,i)=>(
        <div key={i} style={{background:'var(--bg-surface)',border:'1px solid var(--border-default)',borderRadius:10,padding:12,marginBottom:8,fontSize:12,color:'var(--text-dim)',fontFamily:'var(--font-mono)'}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:4}}>
            <div style={{color:'var(--text-hi)',fontWeight:700}}>{e.dir} · {e.pair||'EURUSD'} · {e.date}</div>
            <button onClick={()=>remove(i)} style={{background:'none',border:'none',color:'var(--text-muted)',cursor:'pointer',fontSize:13,padding:2}}>🗑️</button>
          </div>
          {e.source && <div style={{fontSize:10,color:'var(--accent-primary)',marginBottom:4}}>🌐 {e.source}</div>}
          Entry {e.entry} · SL {e.sl} · TP {e.tp} ·{' '}
          <select value={e.result} onChange={ev=>updateResult(i,ev.target.value)} style={{background:'transparent',border:'none',fontFamily:'var(--font-mono)',fontSize:12,fontWeight:700,cursor:'pointer',color:e.result==='Win'?'var(--accent-success)':e.result==='Loss'?'var(--accent-danger)':'var(--text-muted)'}}>
            <option value="Open">Open</option><option value="Win">Win</option><option value="Loss">Loss</option><option value="Breakeven">Breakeven</option>
          </select>
        </div>
      ))}
    </div>
  );
}
window.JournalScreen = JournalScreen;
