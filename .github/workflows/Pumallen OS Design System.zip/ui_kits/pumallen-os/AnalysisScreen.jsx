const { TopBar, BottomNav, Chip, TimeframeCard, VerdictBanner, Button, LoadingDots, Badge } = window.PumallenOSDesignSystem_ac653c;
const TF_ORDER = ['MO','W','D','H4','H1'];
const TF_META = {
  MO:{label:'Monthly',role:'Mission Timeframe · Supreme Authority'},
  W:{label:'Weekly',role:'Strategic Planning · Refine the Mission'},
  D:{label:'Daily',role:'Permission Timeframe · Confirm Direction'},
  H4:{label:'H4',role:'Engineering · Build the Execution Environment'},
  H1:{label:'H1',role:'Execution Engine · Final Trigger'}
};
const MOCK_RESULT = {};
const AN_CHAINS = ['BA','LM','INF','CON','GRO','CB'];
const AN_CORE = ['BA','LM','INF']; const AN_SUPPORT = ['CON','GRO','CB'];
const AN_SCORE = {Strong:1, Mixed:0, Weak:-1};
function computeEconomyCandidate(economy){
  if(!economy || !economy.data) return null;
  const month = economy.reportingMonth || 'Jul';
  const results = Object.keys(economy.data).map(c=>{
    const cd = economy.data[c];
    let total=0; const complete={};
    AN_CHAINS.forEach(id=>{
      total += AN_SCORE[cd[id].thesis];
      const anchors = cd[id].anchors||[];
      const monthAnchors = anchors.filter(a=>a.date && a.date.slice(0,3)===month);
      const answered = monthAnchors.filter(a=>a.verdict);
      complete[id] = monthAnchors.length>0 && answered.length===monthAnchors.length;
    });
    const eligible = AN_CORE.every(id=>complete[id]) && AN_SUPPORT.some(id=>complete[id]);
    return {c, total, eligible};
  }).filter(r=>r.eligible).sort((a,b)=>b.total-a.total);
  if(results.length<2) return { status:'insufficient', count: results.length };
  const gap = results[0].total - results[results.length-1].total;
  return { status: gap>=3?'candidate':'no-trade', gap, strongest:results[0].c, weakest:results[results.length-1].c };
}
function buildPrompts(pair){
  return {
    MO: 'Analyze this MONTHLY '+pair+' chart per PMTS rules. Identify: 1) Long-term bias BULLISH/BEARISH/RANGING 2) Major liquidity objective 3) Key structural levels 4) Premium/discount areas. This is the mission timeframe — no entries. Conclude with a line starting "MONTHLY MISSION:".',
    W: 'Analyze this WEEKLY '+pair+' chart. Monthly mission confirmed above. Identify bias, liquidity zones, structure, and whether this plan aligns with the Monthly mission. Conclude with a line starting "WEEKLY PLAN:" and state ALIGNED WITH MONTHLY: YES or NO.',
    D: 'Analyze this DAILY '+pair+' chart. Higher timeframes aligned. Check reaction from the weekly zone and BOS in the weekly direction. Conclude with a line starting "DAILY PERMISSION:" GRANTED or DENIED.',
    H4: 'Analyze this H4 '+pair+' chart. Higher timeframes aligned. Identify the Level (L1 pullback / L2 expansion / L3 distribution), current leg, and whether structure still serves the Monthly mission. Conclude with a line starting "H4 STRUCTURE:" ALIGNED or NOT ALIGNED.',
    H1: 'Analyze this H1 '+pair+' chart. All higher timeframes aligned. Check for a liquidity sweep, BOS/CHoCH after the sweep, and a clean pullback entry. Conclude with a line starting "H1 ENTRY SIGNAL:" CONFIRMED or NOT CONFIRMED, and EXECUTE or STAND DOWN.'
  };
}
function AnalysisScreen(props){
  const { analysis, setAnalysis, checklist, navigate, pair, economy } = props;
  const { states, results, verdict } = analysis;
  const AF_PROMPTS = buildPrompts(pair || 'EURUSD');
  const economyCandidate = computeEconomyCandidate(economy) || {status:'insufficient'};
  const checklistDone = checklist.every(Boolean);
  const checklistCount = checklist.filter(Boolean).length;
  const slotRefs = React.useRef({});
  function patch(fn){ setAnalysis(a=>fn(a)); }
  async function beginAnalysis(tf){
    patch(a=>({...a, states:{...a.states,[tf]:'analyzing'}}));
    try {
      const slotEl = slotRefs.current[tf];
      const imgEl = slotEl && slotEl.shadowRoot && slotEl.shadowRoot.querySelector('.frame img');
      const dataUrl = imgEl && imgEl.src;
      if(!dataUrl || dataUrl.indexOf('data:') !== 0) throw new Error('No chart image found');
      const mediaType = dataUrl.slice(5, dataUrl.indexOf(';'));
      const base64 = dataUrl.slice(dataUrl.indexOf(',')+1);
      const text = await window.claude.complete({
        messages: [{ role: 'user', content: [
          { type: 'image', source: { type: 'base64', media_type: mediaType, data: base64 } },
          { type: 'text', text: AF_PROMPTS[tf] }
        ]}]
      });
      patch(a=>({...a, results:{...a.results,[tf]:text}, states:{...a.states,[tf]:'ready'}}));
    } catch(err){
      patch(a=>({...a, results:{...a.results,[tf]:'⚠ '+(err && err.message ? err.message : 'Analysis failed. Try again.')}, states:{...a.states,[tf]:'ready'}}));
    }
  }
  React.useEffect(()=>{
    const observers = [];
    TF_ORDER.forEach(tf=>{
      const el = slotRefs.current[tf];
      if(!el || states[tf]!=='active') return;
      const obs = new MutationObserver(()=>{ if(el.hasAttribute('data-filled')) beginAnalysis(tf); });
      obs.observe(el,{attributes:true, attributeFilter:['data-filled']});
      observers.push(obs);
    });
    return ()=>observers.forEach(o=>o.disconnect());
  },[states]);
  function grant(tf, ok){
    const idx = TF_ORDER.indexOf(tf);
    if(!ok){ patch(a=>({...a, states:{...a.states,[tf]:'rejected'}, verdict:'stand-down'})); return; }
    const next = {...states, [tf]:'aligned'};
    if(TF_ORDER[idx+1]) next[TF_ORDER[idx+1]] = 'active';
    if(tf === 'H1' && !checklistDone) return;
    patch(a=>({...a, states:next, verdict: tf==='H1' ? 'execute' : a.verdict}));
  }
  function reset(){
    setAnalysis({states:{MO:'active',W:'locked',D:'locked',H4:'locked',H1:'locked'}, results:{}, verdict:null});
  }
  const cardState = (tf)=> ['aligned','rejected'].includes(states[tf]) ? states[tf] : (states[tf]==='locked' ? 'locked' : 'active');
  return (
    <div style={{position:'absolute',top:92,left:0,right:0,bottom:64,overflowY:'auto',padding:'12px 14px 20px'}}>
      <div style={{display:'flex',gap:8,marginBottom:12}}>
        <div style={{flex:1,padding:'10px 14px',background:'var(--bg-surface)',border:'1px solid var(--border-default)',borderRadius:10,fontSize:13,fontWeight:700,fontFamily:'var(--font-mono)',color:'var(--text-hi)'}}>SYSTEM READY</div>
        <Badge tone={economyCandidate.status==='candidate'?'green':economyCandidate.status==='no-trade'?'red':'muted'}>
          {economyCandidate.status==='candidate' ? '🌐 '+economyCandidate.strongest+'/'+economyCandidate.weakest : economyCandidate.status==='no-trade' ? '🌐 GAP<3' : '🌐 —'}
        </Badge>
        <Badge tone={checklistDone?'green':'muted'}>CHECKLIST {checklistCount}/9</Badge>
      </div>
      {TF_ORDER.map((tf,i)=>(
        <React.Fragment key={tf}>
          <TimeframeCard code={tf} label={TF_META[tf].label} role={TF_META[tf].role} state={cardState(tf)} showUpload={false}>
            {states[tf]==='active' && (
              <div style={{marginTop:8}} ref={el=>{ if(el) slotRefs.current[tf]=el.querySelector('image-slot'); }}>
                <image-slot id={'chart-'+tf} shape="rounded" radius="10" placeholder={'Drop ' + TF_META[tf].label + ' chart'} style={{width:'100%',height:90,display:'block'}}></image-slot>
              </div>
            )}
            {states[tf]==='analyzing' && <div style={{marginTop:8}}><LoadingDots>Analyzing {TF_META[tf].label}...</LoadingDots></div>}
            {states[tf]==='ready' && (
              <div style={{display:'flex',flexDirection:'column',gap:8,marginTop:8}}>
              <div style={{padding:12,background:'rgba(0,0,0,.4)',borderRadius:10,border:'1px solid var(--border-default)',fontSize:12,lineHeight:1.75,color:'var(--text-dim)',whiteSpace:'pre-wrap'}}>{results[tf]}</div>
                {tf==='H1' && !checklistDone && <div style={{fontSize:11,color:'var(--accent-danger)',padding:'8px 10px',background:'var(--surface-red-tint)',borderRadius:8,border:'1px solid var(--border-red)'}}>⚠️ Complete the 9-condition checklist before execution is allowed.</div>}
                <Button variant="success" size="sm" disabled={tf==='H1' && !checklistDone} onClick={()=>grant(tf,true)}>✅ Confirmed — Unlock Next</Button>
                <Button variant="danger" size="sm" onClick={()=>grant(tf,false)}>🚫 Stand Down</Button>
              </div>
            )}
          </TimeframeCard>
          {i<TF_ORDER.length-1 && <div style={{height:16,display:'flex',alignItems:'center',justifyContent:'center'}}><div style={{width:1,height:'100%',background:'var(--border-default)'}}></div></div>}
        </React.Fragment>
      ))}
      {verdict && (
        <div style={{marginTop:12}}>
          <VerdictBanner verdict={verdict} title={verdict==='execute'?'Execute':'Stand Down'} subtitle={verdict==='execute'?'All 9 conditions met. H1 entry clear.':'A required condition failed upstream.'} />
          <Button variant="gold" style={{width:'100%',marginTop:10}} onClick={()=>navigate('chat')}>💬 Continue in AI Chat</Button>
        </div>
      )}
      <Button variant="ghost" style={{width:'100%',marginTop:16}} onClick={reset}>↺ Reset Analysis</Button>
    </div>
  );
}
window.AnalysisScreen = AnalysisScreen;
