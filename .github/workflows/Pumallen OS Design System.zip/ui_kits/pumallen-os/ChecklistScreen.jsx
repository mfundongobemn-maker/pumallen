const { ChecklistItem, Button } = window.PumallenOSDesignSystem_ac653c;
const CHECKLIST_ITEMS = [
  'Tuesday–Thursday only','London or New York session active','Monthly mission confirmed',
  'Weekly plan aligned with Monthly','Daily permission granted','H4 structure aligned',
  'H1 liquidity sweep occurred','H1 break of structure confirmed','Clean pullback entry available'
];
function ChecklistScreen(props){
  const { checklist, setChecklist } = props;
  const count = checklist.filter(Boolean).length;
  const all = count === 9;
  return (
    <div style={{position:'absolute',top:58,left:0,right:0,bottom:64,overflowY:'auto',padding:16}}>
      <div style={{color:'var(--accent-primary)',fontSize:18,fontWeight:800,marginBottom:2}}>Pre-Trade Checklist ✅</div>
      <div style={{color:'var(--text-muted)',fontSize:11,marginBottom:16}}>PMTS 9-Condition Gate — feeds the Analysis screen's execution gate</div>
      <div style={{display:'flex',flexDirection:'column',gap:8}}>
        {CHECKLIST_ITEMS.map((label,i)=>(
          <ChecklistItem key={i} label={label} checked={checklist[i]} onToggle={()=>setChecklist(checklist.map((v,j)=>j===i?!v:v))} />
        ))}
      </div>
      <div style={{marginTop:16,padding:16,borderRadius:12,textAlign:'center',fontWeight:800,fontSize:15,
        background: all ? 'var(--surface-green-tint)':'var(--surface-red-tint)',
        border: '1px solid '+(all?'var(--accent-success)':'var(--accent-danger)'),
        color: all ? 'var(--accent-success)':'var(--accent-danger)'}}>
        {all ? '✅ ALL CONDITIONS MET — EXECUTE' : '🚫 STAND DOWN ('+count+'/9 conditions met)'}
      </div>
      <Button variant="ghost" style={{width:'100%',marginTop:12}} onClick={()=>setChecklist(Array(9).fill(false))}>↺ Reset Checklist</Button>
    </div>
  );
}
window.ChecklistScreen = ChecklistScreen;
