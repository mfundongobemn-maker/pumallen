const { Badge, VerdictBanner } = window.PumallenOSDesignSystem_ac653c;
const BR_CHAINS = ['BA','LM','INF','CON','GRO','CB'];
const BR_CORE = ['BA','LM','INF']; const BR_SUPPORT = ['CON','GRO','CB'];
const BR_SCORE = {Strong:1, Mixed:0, Weak:-1};
function computeCandidate(economy){
  if(!economy || !economy.data) return null;
  const month = economy.reportingMonth || 'Jul';
  const results = Object.keys(economy.data).map(c=>{
    const cd = economy.data[c];
    let total=0; const complete={};
    BR_CHAINS.forEach(id=>{
      total += BR_SCORE[cd[id].thesis];
      const anchors = cd[id].anchors||[];
      const monthAnchors = anchors.filter(a=>a.date && a.date.slice(0,3)===month);
      const answered = monthAnchors.filter(a=>a.verdict);
      complete[id] = monthAnchors.length>0 && answered.length===monthAnchors.length;
    });
    const eligible = BR_CORE.every(id=>complete[id]) && BR_SUPPORT.some(id=>complete[id]);
    return {c, total, eligible};
  }).filter(r=>r.eligible).sort((a,b)=>b.total-a.total);
  if(results.length<2) return { status:'insufficient' };
  const gap = results[0].total - results[results.length-1].total;
  return { status: gap>=3?'candidate':'no-trade', gap, strongest:results[0].c, weakest:results[results.length-1].c };
}
function BriefScreen(props){
  const { economy, checklist, analysis, pair } = props;
  const candidate = computeCandidate(economy);
  const checklistCount = (checklist||[]).filter(Boolean).length;
  const checklistDone = checklistCount===9;
  const verdict = analysis && analysis.verdict;
  return (
    <div style={{position:'absolute',top:58,left:0,right:0,bottom:64,overflowY:'auto',padding:16}}>
      <div style={{color:'var(--accent-primary)',fontSize:18,fontWeight:800,marginBottom:2}}>Session Brief 🧾</div>
      <div style={{color:'var(--text-muted)',fontSize:11,marginBottom:16}}>Everything gating today's trade, in one view</div>

      <div style={{display:'flex',flexDirection:'column',gap:10}}>
        <div style={{background:'var(--bg-surface)',border:'1px solid var(--border-default)',borderRadius:12,padding:14}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:6}}>
            <div style={{fontSize:12,fontWeight:700,color:'var(--text-hi)'}}>🌐 Economic Ranking</div>
            {candidate && <Badge tone={candidate.status==='candidate'?'green':candidate.status==='no-trade'?'red':'muted'}>{candidate.status==='candidate'?'CANDIDATE':candidate.status==='no-trade'?'GAP < 3':'INSUFFICIENT'}</Badge>}
          </div>
          <div style={{fontSize:12,color:'var(--text-dim)',lineHeight:1.6}}>
            {candidate && candidate.status==='candidate' && `Strongest vs weakest eligible economy: ${candidate.strongest}/${candidate.weakest}, gap ${candidate.gap}.`}
            {candidate && candidate.status==='no-trade' && `Strongest/weakest gap (${candidate.gap}) is below the 3-point trade threshold.`}
            {(!candidate || candidate.status==='insufficient') && `Fewer than 2 currencies meet the PMTS eligibility rule yet.`}
          </div>
        </div>

        <div style={{background:'var(--bg-surface)',border:'1px solid var(--border-default)',borderRadius:12,padding:14}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:6}}>
            <div style={{fontSize:12,fontWeight:700,color:'var(--text-hi)'}}>✅ Pre-Trade Checklist</div>
            <Badge tone={checklistDone?'green':'muted'}>{checklistCount}/9</Badge>
          </div>
          <div style={{fontSize:12,color:'var(--text-dim)',lineHeight:1.6}}>{checklistDone ? 'All 9 conditions confirmed.' : `${9-checklistCount} condition(s) still unconfirmed.`}</div>
        </div>

        <div style={{background:'var(--bg-surface)',border:'1px solid var(--border-default)',borderRadius:12,padding:14}}>
          <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:6}}>
            <div style={{fontSize:12,fontWeight:700,color:'var(--text-hi)'}}>🔬 Analysis Chain — {pair||'EURUSD'}</div>
            {verdict && <Badge tone={verdict==='execute'?'green':'red'}>{verdict.toUpperCase()}</Badge>}
          </div>
          <div style={{fontSize:12,color:'var(--text-dim)',lineHeight:1.6}}>{verdict ? (verdict==='execute' ? 'Chain of authority reached EXECUTE.' : 'Chain of authority reached STAND DOWN.') : 'No verdict yet — timeframe chain in progress.'}</div>
        </div>
      </div>

      {verdict && (
        <div style={{marginTop:16}}>
          <VerdictBanner verdict={verdict} title={verdict==='execute'?'Ready to Execute':'Stand Down'} subtitle={checklistDone ? 'All gates aligned.' : 'Checklist incomplete — resolve before execution.'} />
        </div>
      )}
    </div>
  );
}
window.BriefScreen = BriefScreen;
