const { Badge } = window.PumallenOSDesignSystem_ac653c;
function HistoryScreen(){
  const items = [
    {date:'2026-08-03',tf:'H1',verdict:'execute',summary:'Sweep + BOS + pullback at 1.0862'},
    {date:'2026-08-01',tf:'D',verdict:'stand-down',summary:'Daily conflicted with weekly plan'},
    {date:'2026-07-29',tf:'H1',verdict:'execute',summary:'Clean London session entry'}
  ];
  const [filter,setFilter] = React.useState('all');
  const filtered = items.filter(it=> filter==='all' ? true : it.verdict===filter);
  function exportSummary(){
    const text = filtered.map(it=>`${it.date} · ${it.tf} · ${it.verdict==='execute'?'EXECUTE':'STAND DOWN'} — ${it.summary}`).join('\n');
    navigator.clipboard && navigator.clipboard.writeText(text).catch(()=>{});
    alert('History summary copied to clipboard:\n\n'+text);
  }
  const FILTERS = [{id:'all',label:'All'},{id:'execute',label:'Execute'},{id:'stand-down',label:'Stand Down'}];
  return (
    <div style={{position:'absolute',top:58,left:0,right:0,bottom:64,overflowY:'auto',padding:16}}>
      <div style={{color:'var(--accent-primary)',fontSize:18,fontWeight:800,marginBottom:2}}>Analysis History 🕐</div>
      <div style={{color:'var(--text-muted)',fontSize:11,marginBottom:12}}>Past PMTS chart analyses, saved automatically</div>
      <div style={{display:'flex',gap:6,marginBottom:12}}>
        {FILTERS.map(f=>(
          <button key={f.id} onClick={()=>setFilter(f.id)} style={{flex:1,padding:'7px 8px',borderRadius:8,fontSize:11,fontWeight:700,cursor:'pointer',
            background: filter===f.id ? 'var(--accent-primary)' : 'var(--bg-surface-alt)', color: filter===f.id ? '#0a0800' : 'var(--text-muted)', border:'1px solid var(--border-default)'}}>{f.label}</button>
        ))}
        <button onClick={exportSummary} style={{padding:'7px 10px',background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:8,color:'var(--text-muted)',fontSize:14,cursor:'pointer'}}>📋</button>
      </div>
      <div style={{display:'flex',flexDirection:'column',gap:8}}>
        {filtered.map((it,i)=>(
          <div key={i} style={{background:'var(--bg-surface)',border:'1px solid var(--border-default)',borderRadius:10,padding:12}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:6}}>
              <div style={{fontSize:11,color:'var(--text-muted)',fontFamily:'var(--font-mono)'}}>{it.date} · {it.tf}</div>
              <Badge tone={it.verdict==='execute'?'green':'red'}>{it.verdict==='execute'?'EXECUTE':'STAND DOWN'}</Badge>
            </div>
            <div style={{fontSize:12,color:'var(--text-dim)',lineHeight:1.5}}>{it.summary}</div>
          </div>
        ))}
        {filtered.length===0 && <div style={{fontSize:12,color:'var(--text-muted)',textAlign:'center',padding:20}}>No entries match this filter.</div>}
      </div>
    </div>
  );
}
window.HistoryScreen = HistoryScreen;
