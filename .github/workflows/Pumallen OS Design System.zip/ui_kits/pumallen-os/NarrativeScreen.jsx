function NarrativeScreen(props){
  const { narrative, setNarrative } = props;
  const [text,setText] = React.useState('');
  const [saving,setSaving] = React.useState(false);
  async function save(){
    if(!text.trim()) return;
    setSaving(true);
    let tag = '';
    try {
      tag = await window.claude.complete('Summarize this trading market narrative in 5 words or fewer, no punctuation at the end:\n\n'+text);
    } catch(e){}
    setNarrative([{date:new Date().toISOString().slice(0,10),body:text,tag:tag.trim()},...narrative]);
    setText('');
    setSaving(false);
  }
  return (
    <div style={{position:'absolute',top:58,left:0,right:0,bottom:64,overflowY:'auto',padding:16}}>
      <div style={{color:'var(--accent-primary)',fontSize:18,fontWeight:800,marginBottom:2}}>Market Narrative 📝</div>
      <div style={{color:'var(--text-muted)',fontSize:11,marginBottom:12}}>Freeform session notes and market read</div>
      <textarea value={text} onChange={e=>setText(e.target.value)} placeholder="Today's market narrative..."
        style={{width:'100%',minHeight:120,padding:12,background:'var(--bg-surface-alt)',border:'1.5px solid var(--border-gold)',borderRadius:10,color:'var(--text-hi)',fontSize:13,boxSizing:'border-box',fontFamily:'var(--font-body)'}}></textarea>
      <button onClick={save} disabled={saving} style={{width:'100%',marginTop:10,padding:11,background:'var(--accent-primary)',border:'none',borderRadius:10,color:'#0a0800',fontWeight:800,fontSize:13,cursor:saving?'default':'pointer',opacity:saving?.6:1}}>{saving ? 'Saving…' : '💾 Save Entry'}</button>
      <div style={{marginTop:16,display:'flex',flexDirection:'column',gap:8}}>
        {narrative.map((e,i)=>(
          <div key={i} style={{background:'var(--bg-surface)',border:'1px solid var(--border-default)',borderRadius:10,padding:12}}>
            <div style={{display:'flex',justifyContent:'space-between',alignItems:'center',marginBottom:5}}>
              <div style={{fontSize:10,color:'var(--text-muted)',fontFamily:'var(--font-mono)'}}>{e.date}</div>
              {e.tag && <div style={{fontSize:9,color:'var(--accent-primary)',fontFamily:'var(--font-mono)',fontWeight:700,textTransform:'uppercase'}}>{e.tag}</div>}
            </div>
            <div style={{fontSize:12,color:'var(--text-dim)',lineHeight:1.6}}>{e.body}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
window.NarrativeScreen = NarrativeScreen;
