const { TextField } = window.PumallenOSDesignSystem_ac653c;
function PlannerScreen(){
  const [current,setCurrent] = React.useState('256.63');
  const [target,setTarget] = React.useState('500');
  const [monthly,setMonthly] = React.useState('125');
  const [result,setResult] = React.useState(null);
  function calc(){
    const c=parseFloat(current),t=parseFloat(target),m=parseFloat(monthly);
    if(!t||!m) return;
    const remaining = Math.max(t-(c||0),0);
    const months = Math.ceil(remaining/m);
    setResult({months, remaining: remaining.toFixed(2)});
  }
  return (
    <div style={{position:'absolute',top:58,left:0,right:0,bottom:64,overflowY:'auto',padding:16}}>
      <div style={{color:'var(--accent-primary)',fontSize:18,fontWeight:800,marginBottom:2}}>Funding Planner 🎯</div>
      <div style={{color:'var(--text-muted)',fontSize:11,marginBottom:16}}>Track progress toward your PMTS Level ceiling</div>
      <div style={{background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:12,padding:16,display:'flex',flexDirection:'column',gap:10}}>
        <TextField label="Current Balance ($)" type="number" placeholder="256.63" value={current} onChange={e=>setCurrent(e.target.value)} />
        <TextField label="Level Ceiling Target ($)" type="number" placeholder="500" value={target} onChange={e=>setTarget(e.target.value)} />
        <TextField label="Planned Monthly Funding ($)" type="number" placeholder="125" value={monthly} onChange={e=>setMonthly(e.target.value)} />
        <button onClick={calc} style={{width:'100%',padding:12,background:'var(--accent-primary)',border:'none',borderRadius:10,color:'#0a0800',fontWeight:800,fontSize:13,cursor:'pointer'}}>Calculate Timeline</button>
        {result && (
          <div style={{padding:12,background:'rgba(0,0,0,.4)',borderRadius:10,border:'1px solid var(--border-default)',fontSize:12,lineHeight:1.75,color:'var(--text-dim)',fontFamily:'var(--font-mono)'}}>
            Remaining: <b style={{color:'var(--accent-primary)'}}>${result.remaining}</b><br/>
            Est. timeline: <b style={{color:'var(--accent-primary)'}}>{result.months} month{result.months===1?'':'s'}</b>
          </div>
        )}
      </div>
    </div>
  );
}
window.PlannerScreen = PlannerScreen;
