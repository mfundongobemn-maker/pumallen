function StatsScreen(props){
  const { journal } = props;
  const total = journal.length;
  const wins = journal.filter(e=>e.result==='Win').length;
  const losses = journal.filter(e=>e.result==='Loss').length;
  const decided = wins+losses;
  const winRate = decided ? Math.round(wins/decided*100)+'%' : '—';
  let streak=0, bestStreak=0, cur=0;
  journal.slice().reverse().forEach(e=>{
    if(e.result==='Win'){ cur++; bestStreak=Math.max(bestStreak,cur); } else if(e.result==='Loss'){ cur=0; }
  });
  const stats = [
    {l:'Total Trades',v:String(total)},{l:'Win Rate',v:winRate},{l:'Wins / Losses',v:wins+' / '+losses},
    {l:'Best Streak',v:bestStreak+' wins'},{l:'Open Trades',v:String(journal.filter(e=>e.result==='Open').length)},{l:'Breakevens',v:String(journal.filter(e=>e.result==='Breakeven').length)}
  ];
  return (
    <div style={{position:'absolute',top:58,left:0,right:0,bottom:64,overflowY:'auto',padding:16}}>
      <div style={{color:'var(--accent-primary)',fontSize:18,fontWeight:800,marginBottom:2}}>Stats 📊</div>
      <div style={{color:'var(--text-muted)',fontSize:11,marginBottom:14}}>Computed live from your Journal entries</div>
      <div style={{display:'grid',gridTemplateColumns:'1fr 1fr',gap:8}}>
        {stats.map((s,i)=>(
          <div key={i} style={{background:'var(--bg-surface)',border:'1px solid var(--border-default)',borderRadius:12,padding:14}}>
            <div style={{fontSize:20,fontWeight:800,color:'var(--text-hi)',fontFamily:'var(--font-mono)'}}>{s.v}</div>
            <div style={{fontSize:10,color:'var(--text-muted)',marginTop:4}}>{s.l}</div>
          </div>
        ))}
      </div>
      {total===0 && <div style={{marginTop:16,fontSize:12,color:'var(--text-muted)',textAlign:'center',padding:20}}>Log trades in the Journal to see stats here.</div>}
    </div>
  );
}
window.StatsScreen = StatsScreen;
