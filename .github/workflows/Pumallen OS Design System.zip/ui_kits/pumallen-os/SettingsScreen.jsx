function SettingsScreen(props){
  const { resetAll, accent, setAccent, pair, setPair } = props;
  const [key,setKey] = React.useState('');
  const [status,setStatus] = React.useState('');
  const [confirmReset,setConfirmReset] = React.useState(false);
  const ACCENTS = [{id:'gold',label:'Gold',c:'#f0c040'},{id:'silver',label:'Silver',c:'#c7cdd6'},{id:'green',label:'Green',c:'#00e87a'}];
  const PAIRS = ['EURUSD','GBPUSD','USDJPY','AUDUSD','USDCHF'];
  return (
    <div style={{position:'absolute',top:58,left:0,right:0,bottom:64,overflowY:'auto',padding:'20px 16px'}}>
      <div style={{color:'var(--accent-primary)',fontSize:18,fontWeight:800,marginBottom:12}}>Settings ⚙️</div>
      <div style={{background:'var(--surface-gold-tint)',border:'1px solid var(--border-gold)',borderRadius:10,padding:'10px 12px',fontSize:11,color:'var(--accent-primary)',lineHeight:1.5,marginBottom:14}}>🧪 AI Chat and chart analysis call Claude live in this demo. The key field below is cosmetic only — no key is sent anywhere.</div>
      <div style={{background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:12,padding:16,marginBottom:14}}>
        <div style={{color:'var(--text-hi)',fontSize:14,fontWeight:700,marginBottom:6}}>Currency Pair</div>
        <div style={{color:'var(--text-muted)',fontSize:11,lineHeight:1.5,marginBottom:10}}>The source app is EURUSD-only — other pairs are an intentional addition, used for the topbar label and Calculator's pip value.</div>
        <select value={pair} onChange={e=>setPair(e.target.value)} style={{width:'100%',padding:'11px 13px',background:'var(--bg-page)',border:'1.5px solid var(--border-gold)',borderRadius:10,color:'var(--text-hi)',fontFamily:'var(--font-mono)',fontSize:13}}>
          {PAIRS.map(p=><option key={p} value={p}>{p}</option>)}
        </select>
      </div>
      <div style={{background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:12,padding:16,marginBottom:14}}>
        <div style={{color:'var(--text-hi)',fontSize:14,fontWeight:700,marginBottom:10}}>Accent Color</div>
        <div style={{display:'flex',gap:8}}>
          {ACCENTS.map(a=>(
            <button key={a.id} onClick={()=>setAccent(a.id)} style={{flex:1,padding:'10px 8px',borderRadius:10,cursor:'pointer',display:'flex',flexDirection:'column',alignItems:'center',gap:6,background: accent===a.id ? 'var(--bg-page)' : 'transparent',border:'1.5px solid '+(accent===a.id?a.c:'var(--border-default)')}}>
              <div style={{width:20,height:20,borderRadius:'50%',background:a.c}}></div>
              <span style={{fontSize:10,color:accent===a.id?a.c:'var(--text-muted)',fontWeight:700}}>{a.label}</span>
            </button>
          ))}
        </div>
      </div>
      <div style={{background:'var(--bg-surface-alt)',border:'1px solid var(--border-default)',borderRadius:12,padding:16,marginBottom:14}}>
        <div style={{color:'var(--text-hi)',fontSize:14,fontWeight:700,marginBottom:6}}>Anthropic API Key</div>
        <div style={{color:'var(--text-muted)',fontSize:12,lineHeight:1.5,marginBottom:12}}>Required to run chart analysis. Your key is stored only on this device — never sent anywhere except directly to Anthropic's API.</div>
        <input type="password" value={key} onChange={e=>setKey(e.target.value)} placeholder="sk-ant-..."
          style={{width:'100%',padding:'11px 13px',background:'var(--bg-page)',border:'1.5px solid var(--border-gold)',borderRadius:10,color:'var(--text-hi)',fontFamily:'var(--font-mono)',fontSize:13,marginBottom:10,boxSizing:'border-box'}}/>
        <div style={{display:'flex',gap:8}}>
          <button onClick={()=>setStatus('Saved ✓')} style={{flex:1,padding:'11px 14px',background:'var(--accent-primary)',border:'none',borderRadius:10,color:'#0a0800',fontWeight:700,fontSize:13,cursor:'pointer'}}>💾 Save Key</button>
          <button onClick={()=>{setKey('');setStatus('Cleared');}} style={{padding:'11px 14px',background:'var(--bg-surface)',border:'1.5px solid var(--border-default)',borderRadius:10,color:'var(--text-muted)',fontWeight:700,fontSize:13,cursor:'pointer'}}>🗑️ Clear</button>
        </div>
        {status && <div style={{marginTop:10,fontSize:12,fontWeight:600,color:'var(--accent-success)'}}>{status}</div>}
      </div>
      <div style={{color:'var(--text-muted)',fontSize:11,lineHeight:1.6,padding:'0 4px',marginBottom:20}}>
        Don't have a key? Create one at <span style={{color:'var(--accent-primary)'}}>console.anthropic.com</span> under API Keys.
      </div>
      <div style={{background:'var(--bg-surface-alt)',border:'1px solid var(--border-red)',borderRadius:12,padding:16}}>
        <div style={{color:'var(--text-hi)',fontSize:14,fontWeight:700,marginBottom:6}}>Reset App Data</div>
        <div style={{color:'var(--text-muted)',fontSize:12,lineHeight:1.5,marginBottom:12}}>Clears checklist state, journal entries, chat history, narrative notes and analysis progress.</div>
        {!confirmReset
          ? <button onClick={()=>setConfirmReset(true)} style={{width:'100%',padding:'11px 14px',background:'transparent',border:'1.5px solid var(--accent-danger)',borderRadius:10,color:'var(--accent-danger)',fontWeight:700,fontSize:13,cursor:'pointer'}}>🗑️ Reset All App Data</button>
          : (
            <div style={{display:'flex',gap:8}}>
              <button onClick={()=>{resetAll();setConfirmReset(false);}} style={{flex:1,padding:'11px 14px',background:'var(--accent-danger)',border:'none',borderRadius:10,color:'#fff',fontWeight:700,fontSize:13,cursor:'pointer'}}>Confirm Reset</button>
              <button onClick={()=>setConfirmReset(false)} style={{padding:'11px 14px',background:'var(--bg-surface)',border:'1.5px solid var(--border-default)',borderRadius:10,color:'var(--text-muted)',fontWeight:700,fontSize:13,cursor:'pointer'}}>Cancel</button>
            </div>
          )}
      </div>
    </div>
  );
}
window.SettingsScreen = SettingsScreen;
